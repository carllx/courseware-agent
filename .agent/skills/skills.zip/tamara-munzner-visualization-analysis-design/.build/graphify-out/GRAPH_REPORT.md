# Graph Report - .  (2026-06-08)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 393 nodes · 985 edges · 15 communities
- Extraction: 0% EXTRACTED · 0% INFERRED · 0% AMBIGUOUS
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `05b6fd77`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Community 0|Community 0]]
- [[_COMMUNITY_Community 1|Community 1]]
- [[_COMMUNITY_Community 2|Community 2]]
- [[_COMMUNITY_Community 3|Community 3]]
- [[_COMMUNITY_Community 4|Community 4]]
- [[_COMMUNITY_Community 5|Community 5]]
- [[_COMMUNITY_Community 6|Community 6]]
- [[_COMMUNITY_Community 7|Community 7]]
- [[_COMMUNITY_Community 8|Community 8]]
- [[_COMMUNITY_Community 9|Community 9]]
- [[_COMMUNITY_Community 10|Community 10]]
- [[_COMMUNITY_Community 11|Community 11]]
- [[_COMMUNITY_Community 12|Community 12]]
- [[_COMMUNITY_Community 13|Community 13]]
- [[_COMMUNITY_Community 14|Community 14]]

## God Nodes (most connected - your core abstractions)
1. `Attributes` - 122 edges
2. `SUPPORT` - 82 edges
3. `Search` - 61 edges
4. `Actions` - 51 edges
5. `Reduce` - 49 edges
6. `Datasets` - 44 edges
7. `Analyze` - 36 edges
8. `Spatial Data` - 35 edges
9. `Further Reading` - 25 edges
10. `Preface xv` - 23 edges

## Surprising Connections (you probably didn't know these)
- `Processed Document` --follows--> `Contents`  [AST]
  chapter_00_Front_Matter.md → chapter_01_Contents.md
- `Angles of Attack` --follows--> `4.5 Threats to Validity`  [AST]
  chapter_08_Chapter_4_chunk_007_Angles_of_Attack.md → chapter_08_Chapter_4_chunk_008_4_5_Threats_to_Validity.md
- `4.7.6 Sizing the Horizon` --follows--> `4.8 Further Reading`  [AST]
  chapter_08_Chapter_4_chunk_022_4_7_6_Sizing_the_Horizon.md → chapter_08_Chapter_4_chunk_023_4_8_Further_Reading.md
- `6.10 Function First, Form Next` --follows--> `6.11 Further Reading`  [AST]
  chapter_10_Chapter_6_chunk_026_6_10_Function_First__Form_Next.md → chapter_10_Chapter_6_chunk_027_6_11_Further_Reading.md
- `6.11 Further Reading` --follows--> `$\textcircled{ \div}$ Express Values`  [AST]
  chapter_10_Chapter_6_chunk_027_6_11_Further_Reading.md → chapter_10_Chapter_6_chunk_028___textcircled___div___Express_.md

## Import Cycles
- None detected.

## Communities (15 total, 0 thin omitted)

### Community 0 - "Community 0"
Cohesion: 0.05
Nodes (66): 1.4 Why Use an External Representation?, Example: Cluster–Calendar Time-Series Vis, chapter 20 Bibliography chunk 000 Bibliography 10, chapter 20 Bibliography chunk 000 Bibliography 3, Search, 3.4 Actions, 1.3 Why Have a Computer in the Loop?, 6.3.9 Empirical Evidence (+58 more)

### Community 1 - "Community 1"
Cohesion: 0.06
Nodes (60): 5.4.1 Expressiveness and Effectiveness, 13.4.2 Spatial Aggregation, 2.6.1.4 Scalar Fields, 2.5.1 Categorical, 7.4 Express: Quantitative Values, 10.3.2 Ordered Colormaps, What?, Marks as Links (+52 more)

### Community 2 - "Community 2"
Cohesion: 0.07
Nodes (45): 4.3.2 Task and Data Abstraction, 1.10 Why Focus on Effectiveness?, 4.3.4 Algorithm, Example: Topographic Terrain Maps, Example: LineUp, On your Kindle Fire, 11.4.2 Highlighting, SUPPORT (+37 more)

### Community 3 - "Community 3"
Cohesion: 0.08
Nodes (39): 15.7 InterRing, Reduce, 15.8 Constellation, Example: Cartographic Layering, 14.4 Superimpose, 13.3 Filter, Example: Nonlinear Magnification Fields, 14.7 Further Reading (+31 more)

### Community 4 - "Community 4"
Cohesion: 0.10
Nodes (37): 8.2 Why Use Given?, 7.5.2 Matrix Alignment: Two Keys, 2.4.3 Fields, Data Types, 2.4.3.2 Grid Types, 2.4.5 Other Combinations, 2.4.3.1 Spatial Fields, 2.1 The Big Picture (+29 more)

### Community 5 - "Community 5"
Cohesion: 0.15
Nodes (30): 1.1 The Big Picture, 2.7 Further Reading, 8.7 Further Reading, Bibliography, $\textcircled{7}$ Analyze, Analyze, Preface, Arrange Networks and Trees (+22 more)

### Community 6 - "Community 6"
Cohesion: 0.09
Nodes (27): 4.7.2 MatrixExplorer, Query, 3.4.1.3 Enjoy, 4.2 Why Validate?, Domain situation, 4.6.3 Idiom Validation, 4.3 Four Levels of Design, 3.4.1.2 Present (+19 more)

### Community 7 - "Community 7"
Cohesion: 0.10
Nodes (24): 3.7.2 Deriving One Attribute, 5.2 Why Marks and Channels?, 3.6 How: A Preview, Marks as I tems/Nodes, Example: GrouseFlocks, Example: sfdp, Example: Adjacency Matrix View, 5.4 Using Marks and Channels (+16 more)

### Community 8 - "Community 8"
Cohesion: 0.11
Nodes (18): 6.3.5 Other Depth Cues, 6.3 No Unjustified 3D, 6.3.1 The Power of the Plane, 5.5.3 Separability, 6.3.6 Tilted Text Isn’t Legibile, 5.5.2 Discriminability, 6.1 The Big Picture, 5.5 Channel Effectiveness (+10 more)

### Community 9 - "Community 9"
Cohesion: 0.18
Nodes (11): 7.6.1 Rectilinear Layouts, 7.7.1 Dense, Example: Dense Software Overviews, 7.6.3 Radial Layouts, Example: Parallel Coordinates, 7.7 Spatial Layout Density, Example: Pie Charts, Example: Radial Bar Charts (+3 more)

### Community 10 - "Community 10"
Cohesion: 0.22
Nodes (9): Example: Multidimensional Transfer Functions, Example: Ellipsoid Tensor Glyphs, 8.5.3 Texture Flow, 8.5 Vector Fields: Multiple Values, 8.5.4 Feature Flow, Example: Similarity-Clustered Streamlines, 8.6 Tensor Fields: Many Values, 8.5.1 Flow Glyphs (+1 more)

### Community 11 - "Community 11"
Cohesion: 0.25
Nodes (8): 10.4 Other Channels, 10.4.4 Shape Channel, 10.3.4 Colorblind-Safe Colormap Design, 10.4.1 Size Channels, 10.4.6 Texture and Stippling, 10.4.5 Motion Channels, 10.4.3 Curvature Channel, 10.4.2 Angle Channel

### Community 12 - "Community 12"
Cohesion: 0.25
Nodes (8): 10.2.2 Color Spaces, 10.2.1 Color Vision, 10.1 The Big Picture, Color, Encode Map, 10.2 Color Theory, 10.2.3 Luminance, Saturation, and Hue, 10.2.4 Transparency

### Community 13 - "Community 13"
Cohesion: 0.33
Nodes (6): 12.3.4 Combinations, Example: Bird’s-Eye Maps, Example: Improvise, Example: Multiform Overview–Detail Microarrays, Example: Cerebral, 12.3.3 Share Navigation: Synchronize

### Community 14 - "Community 14"
Cohesion: 0.40
Nodes (5): $\textcircled{ \div}$ Separate, Order, Align Regions, $\textcircled{2}$ Axis Orientation, $\textcircled{ \div}$ Express Values, 7.1 The Big Picture, $\textcircled{3}$ Layout Density

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `SUPPORT` connect `Community 2` to `Community 5`?**
  _High betweenness centrality (0.652) - this node is a cross-community bridge._
- **Why does `index chunk 000 Table of Contents 2` connect `Community 5` to `Community 0`, `Community 1`, `Community 3`, `Community 4`, `Community 6`?**
  _High betweenness centrality (0.647) - this node is a cross-community bridge._
- **Should `Community 0` be split into smaller, more focused modules?**
  _Cohesion score 0.05454545454545454 - nodes in this community are weakly interconnected._
- **Should `Community 1` be split into smaller, more focused modules?**
  _Cohesion score 0.05536723163841808 - nodes in this community are weakly interconnected._
- **Should `Community 2` be split into smaller, more focused modules?**
  _Cohesion score 0.06565656565656566 - nodes in this community are weakly interconnected._
- **Should `Community 3` be split into smaller, more focused modules?**
  _Cohesion score 0.07827260458839407 - nodes in this community are weakly interconnected._
- **Should `Community 4` be split into smaller, more focused modules?**
  _Cohesion score 0.1006006006006006 - nodes in this community are weakly interconnected._