# Example: Improvise

Figure 12.7 shows a vis of census data that uses many views. In addition to geographic information, the demographic information for each county includes population, density, genders, median age, percentage change since 1990, and proportions of major ethnic groups. The system is multiform with geographic, scatterplot, parallel coordinate, tabular, and matrix views. These multiform views all share the same bivariate sequential– sequential color encoding, documented with a legend in the bottom middle. A set of small-multiple views appears in the lower left in the form of a scatterplot matrix, where each scatterplot shows a different pair of attributes. All of the views are linked by highlighting: the blue selected items are close together in some views and spread out in others. A set of small-multiple reorderable list views result from partitioning the data by

Bivariate colormaps are covered in Section 10.3.3.

![](images/6321452c0101802169644b6bc9d04e8e597852a773dd775201d79e6aa77d96f3.jpg)  
Figure 12.7. The Improvise toolkit [Weaver 04] was used to create this census vis that has many forms of coordination between views. It has many multiform views, some of which use small multiples, and some of which provide additional detail information. From http://www.cs.ou.edu/~weaver/improvise/examples/census.

attribute. The list views allow direct sorting by and selection within an attribute of interest. The map in the upper left view is a small overview, with linked navigation to the large geographic detail view in the top middle.

<table><tr><td>System</td><td>Improvise</td></tr><tr><td>What: Data</td><td>Geographic and multidimensional table (census data): one key attribute (county), many quantitative attributes (demographic information).</td></tr><tr><td>How: Encode</td><td>Scatterplot matrix, parallel coordinates, choropleth map with size-coded city points, bird&#x27;s-eye map overview, scatterplot, reorderable text lists, text matrix. Bivariate sequential–sequential colormap.</td></tr><tr><td>How: Facet</td><td>Partition: small-multiple, multiform, overview–detail views; linked highlighting.</td></tr></table>