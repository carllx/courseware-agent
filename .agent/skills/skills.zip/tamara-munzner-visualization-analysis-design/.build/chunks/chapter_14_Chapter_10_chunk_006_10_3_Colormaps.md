# 10.3 Colormaps

A colormap specifies a mapping between colors and data values; that is, a visual encoding with color.* Using color to encode data is a powerful and flexible design choice, but colormap design has many pitfalls for the unwary.

Figure 10.6 shows the taxonomy of colormaps; it is no coincidence that it mirrors the taxonomy of data types. Colormaps can be categorical or ordered, and ordered colormaps can be either sequential or diverging. Of course, it is important to match colormap to data type characteristics, following the expressiveness principle. Colormaps for ordered data should use the magnitude channels of luminance and saturation, since the identity channel of hue does not have an implicit ordering.

Colormaps can either be a continuous range of values, or segmented into discrete bins of color.* Continuous colormaps are heavily used for showing quantitative attributes, especially those associated with inherently spatial fields. Segmented colormaps are suitable for categorical data. For ordinal data, segmented colormaps would emphasize its discrete nature, while continuous would emphasize its ordered nature. Bivariate colormaps encode two attributes simultaneously. While bivariate colormaps are straightforward to understand when the second attribute is binary, with only two levels, they are more difficult for people to interpret when both attributes have multiple levels.

Superimposing layers is covered in Section 12.5.

* Colormapping is also called pseudocoloring, especially in earlier literature. Another synonym for colormap is color ramp.   
The principle of expressivness is covered in Section 5.4.1.   
* There are many synonyms for segmented colormap: quantized colormap, stepped colormap, binned colormap, discretized colormap, and discrete colormap.   
Continuous versus discrete data semantics is discussed in Section 2.4.3.

<!-- Chunk 5 End -->

<!-- Chunk 6 Start -->

![](images/a8335449ac65b5785aac43f3b6370866e2a3594d2281df1047c61743239af373.jpg)  
Figure 10.6. The colormap categorization partially mirrors the data types: categorical versus ordered, and sequential and diverging within ordered. Bivariate encodings of two separate attributes at once is safe if one has only two levels, but they can be difficult to interpret when both attributes have multiple levels. After [Brewer 99].