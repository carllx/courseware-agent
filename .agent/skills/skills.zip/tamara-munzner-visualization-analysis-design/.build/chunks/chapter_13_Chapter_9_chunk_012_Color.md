# Color

Color Encoding

![](images/39eb33f6596656888ed7e6751f0d7f408bf9d735e7e358bba3bd8bfe8dc164ae.jpg)

Saturation

![](images/b23276abfc45abf9d8a0916ef58a7843510bf5ef6425a959c81175f93c4112d3.jpg)

![](images/de9648fc7e75e6d7f9a9b280990a3e0148bdd29201d37c0e2d5dc623fd1da6ba.jpg)

![](images/416f52359f01f435e19e4f54003aef552836400b9b6d4bf3f1ff4479749b79e8.jpg)

![](images/11ac60a97748b73f07c2a094348c6ea1363654e8833fa792f97c4c9d97dcec92.jpg)

Color Map

Categorical

![](images/4bbba39f14f6afbd785b15718e76953d02f8fd0f9e1ed6e48cfbc3cc4007a17f.jpg)

Ordered

S equential

Diverging

![](images/d747bf26f3489755b4416aad5fcb55f0a8cbc23fb70412c4ab5525b7adfcba4c.jpg)

![](images/f7069de8f2ef1763c4ff8ae13c2ce9a5166ff608485eca97f97f6551fa1fb039.jpg)

Bivariate

![](images/c5ce3aa23c0a6b2e4c6caa66a58cdf6f89e82d01515e2a8b2b76b51da540bfc2.jpg)

$\textcircled{7}$ Size, Angle, Cur vature, ...

Length

![](images/c9f4cccb4f28236e2f4a3e46499b57b5eb74a6b5b719e4c31b648b0ba073e5e5.jpg)

Angle

![](images/e004471bcfd5886540bad3a7b7763db1b4cd741df7122f8339f7c708596fdd72.jpg)

Area

![](images/b9773dd0649a43245027b6267a0378617e1b538a3416f7340f2e934d9fe6093c.jpg)

Cur vature

![](images/d657fc4690da4400b35f2a644d0e8df8c679b6e8bf20ef4c96c968cb209777d6.jpg)

Volume

![](images/b079c303de710ffc933063902595fcb86394ea5b623099dc8970f1262d41f89f.jpg)

Shape

![](images/d7fa2175c4db2f5900ba07c130cfe02885e1695634f4c2cee373b2e9341dd75e.jpg)

![](images/a82c030b01a4e2a21d53abce34e99807d378a712d90e45efe191cd5811c1c754.jpg)

Motion

Motion

Direction, Rate, Frequenc y, ...

![](images/cc036d3d76add7fe42a47f82451201c8325ef3abd814470e73a836a9641823c3.jpg)  
Figure 10.1. Design choices for mapping color and other visual encoding channels.