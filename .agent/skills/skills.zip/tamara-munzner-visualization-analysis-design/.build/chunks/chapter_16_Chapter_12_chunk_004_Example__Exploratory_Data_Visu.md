# Example: Exploratory Data Visualizer (EDV)

The EDV system features the idiom of linked highlighting between views [Wills 95]. Figure 12.2 shows a baseball statistics dataset with linked bar charts, scatterplots, and a histogram [Wills 95]. In Figure 12.2(a), the viewer has selected players with high salaries in the smoothed histogram view on the upper right. The distribution of these players is very different in the other plots. In the Years played view bar chart on the upper left, there are no rookie players. The Assists-PutOuts scatterplot does not show much correlation with salary. Comparing the CHits/Years plot showing batting ability in terms of career home runs with average career hits shows that the hits per year is more correlated with salary than the home runs

![](images/946fd125b453cebbe254f8323811ef27730ed0ff66428b6396489028fefbdd82.jpg)  
(a)

![](images/f3d5ca882a32f71e428bd999f3c80371f9be1cbe042f59d94cb86a29686fa4c4.jpg)  
(b)   
Figure 12.2. Linked highlighting between views shows how regions that are contiguous in one view are distributed within another. (a) Selecting the high salaries in the upper right window shows different distributions in the other views. (b) Selecting the bottom group in the Assists-PutOuts window shows that the clump corresponds to specific positions played. From [Wills 95, Figures 4 and 5].

per year. The bottom Position window shows a loose relationship between salary and the player’s position in the field. The Assists-PutOuts window shows a clustering into two major groups. Figure 12.2(b) shows the result of selecting the bottom clump. The bottom Position window shows that this clump corresponds to specific positions played, whereas these players are fairly evenly distributed in the other windows.

<table><tr><td>System</td><td>Exploratory Data Visualizer (EDV)</td></tr><tr><td>What: Data</td><td>Tables.</td></tr><tr><td>How: Encode</td><td>Bar charts, scatterplots, and histograms.</td></tr><tr><td>How: Facet</td><td>Partition: multiform views. Coordinate: linked high-lighting.</td></tr></table>