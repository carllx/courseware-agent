# Why?

![](images/1eae5748e5ac19b975e747224759f51e734ff480e8eb31aa5054ad0df57bc015.jpg)  
Derive

![](images/5d7ea3b53379fe92881738fe6fd0713250116082472c1aa3c3c5a8fcc9e635ab.jpg)  
Task 2   
I n   
Spatial field

![](images/88315431532501860acb5bfa8ab5c172473a148c8e766c7f38b71dc0755508ea.jpg)  
I n   
$^ +$ M any quantitative attributes

![](images/c5b40fbd082a74ff1173bf91f8bde721bdab3a98c47357ee015605d22728bce6.jpg)

![](images/d5e7e6e8524ad0294b668242be04799c394f5702e5da6bb3388e9850b21a983e.jpg)

![](images/c50d5b36b4ccef6bfbe12e4ab7ba4d76194e56558bf5666344520c0b34c0d198.jpg)  
Figure 3.13. Analyzing a chained sequence, where many attributes are derived and visually encoded.

taposed attribute plots with ed coloring