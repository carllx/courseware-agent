# $\textcircled{7}$ Search

<table><tr><td></td><td>Target known</td><td>Target unknown</td></tr><tr><td>Location known</td><td>Lookup</td><td>Browse</td></tr><tr><td>Location unknown</td><td>&lt;LOC&gt;Locate</td><td>Explore</td></tr></table>