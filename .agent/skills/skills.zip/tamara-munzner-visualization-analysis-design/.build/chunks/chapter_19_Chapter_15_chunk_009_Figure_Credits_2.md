Figure 7.18 Courtesy of Michael Bostock, made with D3 [Bostock et al. 11]. From http://bl.ocks. org/mbostock/3887235, http://bl.ocks.org/mbostock/3886208, and http://bl.ocks.org/ mbostock/3886394.   
Figure 7.19 Copyright $\circledcirc$ 2012 John Wiley & Sons, Ltd.   
Figure 7.20 Courtesy of John Stasko.   
Figure 8.2 Courtesy of Michael Bostock, made with D3 [Bostock et al. 11]. From http://bl.ocks.org/ mbostock/4060606.   
Figure 8.3 Courtesy of Joe Kniss.   
Figure 8.4 Courtesy of Land Information New Zealand Data Service (CC BY 3.0 NZ). From https:// data.linz.govt.nz/layer/768-nz-mainland-contours-topo-150k.   
Figure 8.5 Copyright $\circledcirc$ 2004 by IEEE.   
Figure 8.6 Copyright $\circledcirc$ 2004 by IEEE.   
Figure 8.7 Copyright $\circledcirc$ 2005 by IEEE.   
Figure 8.8 Reprinted from Computers and Graphics, Vol. 26, No. 2, Xavier Tricoche, Thomas Wischgoll, Gerik Scheuermann, and Hans Hagen, “Topology tracking for the visualization of time-dependent two-dimensional flows,” Pages 249–257, Copyright 2002, with permission from Elsevier.   
Figure 8.9 Copyright $\circledcirc$ 2013 by IEEE.   
Figure 8.10 Copyright $\circledcirc$ 2005 by IEEE.   
Figure 8.11 Courtesy of Gordon Kindlmann. From http://www.cs.utah.edu/~gk/papers/vis99/ppt/ slide03.html.   
Figure 8.12 Copyright $\circledcirc$ 2004 by IEEE.   
Figure 8.13 Copyright $\circledcirc$ 2004 by IEEE.   
Figure 9.2(a) Springer, Graph Drawing, Lecture Notes in Computer Graphics 2528, 2002, pages 344– 353, “Improving Walkers Algorithm to Run in Linear Time,” Christoph Buchheim, Michael Junger, and Sebastien Leipert, Figure 2d, copyright $\circledcirc$ 2002 Springer. With kind permission from Springer Science and Business Media.   
Original caption: Extending the Reingold-Tilford algorithm to trees of unbounded degree.   
Figure 9.2(b) Courtesy of Michael Bostock, made with D3 [Bostock et al. 11]. From http://mbostock. github.com/d3/ex/tree.html.   
Figure 9.3 Courtesy of David Auber, made with Tulip [Auber et al. 12].   
Figure 9.4 Courtesy of Michael Bostock, made with D3 [Bostock et al. 11]. From http://bl.ocks.org/ mbostock/4062045 and http://bl.ocks.org/1062288.   
Figure 9.5 From “A Gallery of Large Graphs,” JDG Homologycis-n4c6, b14 and b4. Courtesy of Yifan Hu; see http://yifanhu.net/GALLERY/GRAPHS/citation.html.   
Figure 9.6 Reprinted by permission from Macmillan Publishers Ltd: Nature Methods [Gehlenborg and Wong 12], copyright 2012.

Figure 9.7 Courtesy of Michael McGuffin, from http://www.michaelmcguffin.com/courses/vis/ patternsInAdjacencyMatrix.png.   
Figure 9.8 Courtesy of David Auber, made with Tulip [Auber et al. 12].   
Figure 9.9 Michael J. McGuffin and Jean-Marc Robert, Information Visualization (9:2) pp. 115–140, copyright $\circledcirc$ 2010 by SAGE Publications. Reprinted by Permission of SAGE.   
Figure 9.10 Copyright $\circledcirc$ 2008 by IEEE.   
Figure 10.8 Reproduced under Creative Commons Attribution license (CC BY 2.0).   
Figure 10.9 Copyright $\circledcirc$ 2012 by IEEE.   
Figure 10.10 Copyright $\circledcirc$ 2012 by IEEE.   
Figure 10.11 Copyright $\circledcirc$ 1998 by IEEE.   
Figure 10.12 Copyright $\circledcirc$ 1995 by IEEE.   
Figure 10.13 Courtesy of Gordon Kindlmann, from http://www.cs.utah.edu/~gk/lumFace.   
Figure 11.2 Courtesy of Michael McGuffin, made using Tableau, http://tableausoftware.com.   
Figure 11.3 Copyright $\circledcirc$ 2013 by IEEE.   
Figure 11.4 Copyright $\circledcirc$ 2013 by IEEE.   
Figure 11.5 Copyright $\circledcirc$ 2003 by IEEE.   
Figure 11.6 Copyright $\circledcirc$ 2011 by IEEE.   
Figure 11.7 [McLachlan et al. 08] $\circledcirc$ 2008 Association for Computing Machinery, Inc. Reprinted by permission.   
Figure 11.8 $\circledcirc$ 2008 Christian Rieder, Felix Ritter, Matthias Raspe, and Heinz-Otto Peitgen. Computer Graphics Forum $\circledcirc$ 2008 The Eurographics Association and Blackwell Publishing Ltd.   
Figure 11.9 Copyright $\circledcirc$ 1993 by IEEE.   
Figure 12.2 Reproduced with permission from Graham Wills.   
Figure 12.4 Copyright $\circledcirc$ 2003 by IEEE.   
Figure 12.5 Copyright $\circledcirc$ 2008 by IEEE.   
Figure 12.7 Reproduced under Creative Commons Attribution-ShareAlike 4.0 International license (CC BY-SA 4.0); created by Chris Weaver of The University of Oklahoma, from http://www.cs. ou.edu/~weaver/improvise/examples/census.   
Figure 12.8 Courtesy of Michael Bostock, made with D3 [Bostock et al. 11]. From http://bl.ocks.org/ mbostock/3887051, after http://bl.ocks.org/mbostock/4679202.   
Figure 12.9 “The Visual Design and Control of Trellis Display,” Ronald A. Becker, William S. Cleveland, and Ming-Jen Shyu, Journal of Computational and Statistical Graphics 5:2 (1996), 123– 155. Reprinted by permission of the American Statistical Association (http://www.amstat. org).