# 12.4.1 Regions, Glyphs, and Views

Partitioning is an action on a dataset that separates data into groups. To connect partioning to visual encoding choices, the crucial idea is that a partitioned group can be placed within a region of space, so partitioning is an action that addresses the separate choice when arranging data in space. These regions then need to be ordered, and often aligned, to resolve the other spatial arrangement choices. For example, after space is subdivided into regions, they can be aligned and ordered within a 1D list, or 2D matrix. Recursive subdivision allows these regions to nest inside each other;

Partioning and grouping are inverse terms; the term partitioning is natural when considering starting from the top and gradually refining; the term grouping is more natural when considering a bottom-up process of gradually consolidating. The term conditioning is a synonym for partitioning that is used heavily in the statistics literature.

* Synonyms for partitioning are hierarchical partitioning and dimensional stacking.

Section 7.5 covers separation, ordering, and alignment.

* The word glyph is used very ambiguously in the vis literature. My definitions unify many ideas within a common framework but are not standard. In particular, my distinction between a mark and a glyph made of multiple marks is not universal.

* Other synonyms for view include display, window, panel, and pane.

these nested regions may be arranged using the same choices as their enclosing regions or different choices.

When a dataset has only one key attribute, then it is straightforward to use that key to separate into one region per item. When a dataset has multiple keys, there are several possibilities for separation. Given two keys, X and Y, you could first separate by X and then by Y, or you could first separate by Y and then by X. A third option is that you might separate into regions by only one of the keys and then draw something more complex within the region. The complexity of what is encoded in a region falls along a continuum. It could be just a single mark, a single geometric primitive. It could be a more complex glyph: an object with internal structure that arises from multiple marks. It could be a full view, showing a complete visual encoding of marks and attributes.

There is no strict dividing line between a region, a view, and a glyph.* A view is a contiguous region in which visually encoded data is shown on the display.* Sometimes a view is a full-blown window controlled by the computer’s operating system, sometimes it is a subcomponent such as a panel or a pane, and sometimes it simply means a region of the display that is visually distinguishable from other regions through some kind of visible boundary. A spatial region showing data visually encoded by a specific idiom might be called either a glyph or a view depending on its screen size, the amount of additional information beyond the visual encoding alone that is shown, and whether it is nested within another region. Large, stand-alone, highly detailed regions are likely to be called views, and small, nested, schematic regions are likely to be called glyphs. For example, a single bar chart that is 800 pixels wide and 400 pixels high, with axes that have labels and tick marks, confidence intervals shown for each bar, and both a legend and a title would usually be called a view. If there is a set of bar charts that are each 50 by 25 pixels, each with a few schematic bars and two thin unlabeled lines to depict the axes, where each appears within a geographic region on a map, each chart might be called a glyph.

The term glyph has been used for structures at a range of sizes. Glyphs like the schematic bar chart example just mentioned would fall into the category of macroglyphs. Another example is a glyph with a complex 3D shape that represents several aspects of local fluid flow all simultaneously. Designing these glyphs is a microcosm of vis design more generally!

In the middle of the size spectrum are simpler structures such as a single multipart bar in a stacked bar chart. At the extreme end

![](images/6fe6ae97e34df921f64c32f500752b7bd8d0e448bf71065972cd2f4881e1bbc4.jpg)  
(a)

![](images/2dcf58be307d86fe731a15fb8ebc42bf918ce2f0eb369b5f47bd536c5e3700ca.jpg)  
(b)   
Figure 12.8. Partitioning and bar charts. (a) Single bar chart with grouped bars: separated by state key into regions, using seven-mark glyphs within each region. (b) Four aligned small-multiple bar chart views: separated by group key into vertically aligned list of regions, with a full bar chart in each region. From http://bl.ocks.org/mbostock/3887051, after http://bl.ocks.org/mbostock/4679202.

of the spectrum, microglyphs can be so small that their structure is not intended to be directly distinguishable: for example, five very short connected line segments, where the angle between each pair of segments encodes a quantitative attribute, and the entire glyph fits within an 15 by 4 pixel region. Microglyphs are typically used as a dense 2D array that forms a sea of visual texture, where the hope is that noticeable boundaries will emerge where attribute values change.