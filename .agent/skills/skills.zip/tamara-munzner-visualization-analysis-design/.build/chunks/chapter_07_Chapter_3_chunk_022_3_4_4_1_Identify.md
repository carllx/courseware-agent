# 3.4.4.1 Identify

The scope of identify is a single target. If a search returns known targets, either by lookup or locate, then identify returns their characteristics. For example, a user of a static map that represents US election results by color coding each state red or blue, with the saturation level of either hue showing the proportion, can identify

the winning party and margin of victory for the state of California. Conversely, if a search returns targets matching particular characteristics, either by browse or explore, then identify returns specific references. For instance, the election map user can identify the state having the highest margin of victory.