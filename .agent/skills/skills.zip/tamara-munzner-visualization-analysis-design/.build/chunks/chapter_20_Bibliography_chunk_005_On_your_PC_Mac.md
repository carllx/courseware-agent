# On your PC/Mac

Go to http://bookshelf.vitalsource.com/ and follow the instructions to download the free VitalSource Bookshelf app to your PC or Mac and log into your Bookshelf account.