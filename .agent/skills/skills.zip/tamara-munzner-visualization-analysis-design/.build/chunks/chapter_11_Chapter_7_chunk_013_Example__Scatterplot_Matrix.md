# Example: Scatterplot Matrix

A scatterplot matrix (SPLOM) is a matrix where each cell contains an entire scatterplot chart. A SPLOM shows all possible pairwise combinations of attributes, with the original attributes as the rows and columns. Figure 15.2 shows an example. In contrast to the simple heatmap matrix where each cell shows one attribute value, a SPLOM is an example of a more complex matrix where each cell shows a complete chart.

The key is a simple derived attribute that is the same for both the rows and the columns: an index listing all the attributes in the original dataset. The matrix could be reordered according to any ordered attribute. Usually

SPLOMS are an example of small-multiple views, as discussed in Section 12.3.2.

only the lower or upper triangle of the matrix is shown, rather than the redundant full square. The diagonal cells are also typically omitted, since they would show the degenerate case of an attribute plotted against itself, so often labels for the axes are shown in those cells.

SPLOMs are heavily used for the abstract tasks of finding correlations, trends, and outliers, in keeping with the usage of their constituent scatterplot components.

Each scatterplot cell in the matrix requires enough room to plot a dot for each item discernably, so around $1 0 0 ~ \times ~ 1 0 0$ pixels is a rough lower bound. The scalability of a scatterplot matrix is thus limited to around one dozen attributes and hundreds of items.

Many extensions to SPLOMs have been proposed, including the scagnostics idiom using derived attributes described in Section 15.3 and the compact heatmap-style overview described in Section 15.5.

<table><tr><td>Idiom</td><td>Scatterplot Matrix (SPLOM)</td></tr><tr><td>What: Data</td><td>Table.</td></tr><tr><td>What: Derived</td><td>Ordered key attribute: list of original attributes.</td></tr><tr><td>How: Encode</td><td>Scatterplots in 2D matrix alignment.</td></tr><tr><td>Why: Task</td><td>Find correlation, trends, outliers.</td></tr><tr><td>Scale</td><td>Attributes: one dozen.
Items: dozens to hundreds.</td></tr></table>