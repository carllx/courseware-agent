# Dataset Types

Tables

![](images/9a61b4d4f6755a1a0049cd6388e551ee38c3a96a35f084f98cc81ba56fd61f70.jpg)

Networks

![](images/4cf962aec8fa2226f07db43d5daeb5be3ed77b79a182b89a935bdc098e9e2a8e.jpg)

Fields (Continuous)

![](images/9e50474b1322eef44d422ea6849a35828f2d78d364182ea2b43a06e3040369a1.jpg)

Multidimensional Table

![](images/7f6a87372b52785e734dc8e597c7f5fdb8ed4063b821ed895fbfb6de6a351c06.jpg)

Trees

![](images/9243e5dbbd84801a3c9d1c3caa932ad62f97ffde2d41e03e8934c41eb48b99e1.jpg)

Geometr y (Spatial)

![](images/e9df5e29c03a9a85b76112cd50472926e983ac22e031dab78917669badc0f133.jpg)

![](images/bfce3979c810f47d31c094477ce566a135835a17dff9b644cc81684c9247d30f.jpg)