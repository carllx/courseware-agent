# Example: Choropleth Maps

A choropleth map shows a quantitative attribute encoded as color over regions delimited as area marks, where the shape of each region is determined by using given geometry. The region shapes might either be provided directly as the base dataset or derived from base data based on cartographic generalization choices. The major design choices for choropleths are how to construct the colormap, and what region boundaries to use.

Figure 8.2 shows an example of US unemployment rates from 2008 with a segmented sequential colormap. The white-to-blue colormap has a sequence of nine levels with monotonically decreasing luminance. The region granularity is counties within states.

‣ Sequential colormaps are covered in Section 10.3.2.

The problem of spatial aggregation and its relationship to region boundaries is covered in Section 13.4.2.

![](images/4ac5f11c3fe0ac72695d21a390df6093e1611f592406d7f4f9d1aa52ec589b72.jpg)  
Figure 8.2. Choropleth map showing regions as area marks using given geometry, where a quantitative attribute is encoded with color. From http://bl.ocks.org/ mbostock/4060606.

<table><tr><td>Idiom</td><td>Choropleth Map</td></tr><tr><td>What: Data</td><td>Geographic geometry data. Table with one quantitative attribute per region.</td></tr><tr><td>How: Encode</td><td>Space: use given geometry for area mark boundaries. Color: sequential segmented colormap.</td></tr></table>