Figure 12.10 “The Visual Design and Control of Trellis Display,” Ronald A. Becker, William S. Cleveland, and Ming-Jen Shyu, Journal of Computational and Statistical Graphics 5:2 (1996), 123– 155. Reprinted by permission of the American Statistical Association (http://www.amstat. org).   
Figure 12.11 Copyright $\circledcirc$ 2009 by IEEE.   
Figure 12.12 Copyright $\circledcirc$ 2009 by IEEE.   
Figure 12.13 From [Stone 10], courtesy of Maureen Stone; original color image by National Park Service, http://www.nps.gov/pore/planyourvisit/upload/map pore areamap.pdf.   
Figure 12.15 Copyright $\circledcirc$ 2010 by IEEE.   
Figure 12.16 Copyright $\circledcirc$ 2006 by IEEE.   
Figure 12.17 Reproduced under Creative Commons Attribution Non-Commercial license (CC BY-NC 2.0).   
Figure 13.2 [Ahlberg and Shneiderman 94] $\circledcirc$ 1994 Association for Computing Machinery, Inc. Reprinted by permission. Courtesy of Human-Computer Interaction Lab, University of Maryland.   
Figure 13.3 Copyright $\circledcirc$ 2007 by IEEE.   
Figure 13.4 Copyright $\circledcirc$ 2003 by IEEE.   
Figure 13.6 Copyright $\circledcirc$ 2008 by IEEE.   
Figure 13.7 “40 years of boxplots,” Hadley Wickham and Lisa Stryjewski, The American Statistician. Reprinted by permission of the American Statistical Association (http://www.amstat.org).   
Figure 13.8 Copyright $\circledcirc$ 1998 by IEEE.   
Figure 13.9 Copyright $\circledcirc$ 1999 by IEEE.   
Figure 13.10 Courtesy of Adrienne Gruver, Penn State Geography.   
Figure 13.11 Copyright $\circledcirc$ 2007 by IEEE.   
Figure 13.12 Copyright $\circledcirc$ 2009 by IEEE.   
Figure 14.2 Copyright $\circledcirc$ 2004 by IEEE.   
Figure 14.3 [Bier et al. 93] $\circledcirc$ 1993 Association for Computing Machinery, Inc. Reprinted by permission.   
Figure 14.4 Copyright $\circledcirc$ 1997 by IEEE.   
Figure 14.5 Courtesy of David Auber, made with Tulip [Auber et al. 12].   
Figure 14.6 Copyright $\circledcirc$ 1998 by IEEE.   
Figure 14.7 [Munzner et al. 03] $\circledcirc$ 2003 Association for Computing Machinery, Inc. Reprinted by permission.   
Figure 14.8 Copyright $\circledcirc$ 2006 by IEEE.   
Figure 14.9 Copyright $\circledcirc$ 1998 by IEEE.   
Figure 14.10 Copyright $\circledcirc$ 2010 by IEEE.

Figure 15.2 Copyright $\circledcirc$ 2005 by IEEE.   
Figure 15.3 “Scagnostics Distributions,” Leland Wilkinson and Graham Wills, Journal of Computational and Graphical Statistics (JCGS) 17:2 (2008), 473–491. Reprinted by permission of the American Statistical Association (http://www.amstat.org).   
Figures 15.4 and 15.1(a) Copyright $\circledcirc$ 2005 by IEEE.   
Figure 15.5 Copyright $\circledcirc$ 1994 by IEEE.   
Figures 15.6 and 15.1(b) Copyright $\circledcirc$ 1994 by IEEE.   
Figure 15.7 Copyright $\circledcirc$ 1994 by IEEE.   
Figure 15.8 Copyright $\circledcirc$ 2002 by IEEE. Courtesy of Human-Computer Interaction Lab, University of Maryland.   
Figures 15.9 and 15.1(c) Copyright $\circledcirc$ 2005 by IEEE. Courtesy of Human-Computer Interaction Lab, University of Maryland.   
Figure 15.10 Copyright $\circledcirc$ 2005 by IEEE. Courtesy of Human-Computer Interaction Lab, University of Maryland.   
Figure 15.11 [Wattenberg 06] $\circledcirc$ 2006 Association for Computing Machinery, Inc. Reprinted by permission.   
Figures 15.12 and 15.1(d) [Wattenberg 06] $\circledcirc$ 2006 Association for Computing Machinery, Inc. Reprinted by permission.   
Figures 15.13 and 15.1(e) Copyright $\circledcirc$ 2002 by IEEE.   
Figure 15.14–15.20 and 15.1(f) From the PhD thesis of Tamara Munzner [Munzner 00].