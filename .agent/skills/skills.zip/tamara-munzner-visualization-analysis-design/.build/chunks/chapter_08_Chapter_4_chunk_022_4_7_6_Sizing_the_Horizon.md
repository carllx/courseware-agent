# 4.7.6 Sizing the Horizon

‣ Line charts are discussed in Section 9.2.

Heer et al. compare line charts to the more space-efficient horizon graphs [Heer et al. 09], as Figure 4.16 shows. They identify transition points at which reducing the chart height results in significantly differing drops in estimation accuracy across the compared chart types, and they find optimal positions in the speed–accuracy trade-off curve at which viewers performed quickly without attendant drops in accuracy. This paper features lab studies that are designed to validate (or invalidate) specific design choices at the

![](images/b042707e425208dbffa412301f336c6129983bb72fdd174e4f8d1abce1bc1d73.jpg)  
Figure 4.16. Experiment 2 of Sizing the Horizon compared filled line charts, one-band horizon graphs, and twoband horizon graphs of different sizes to find transition points where reducing chart height results in major drops in estimation accuracy across chart types. From [Heer et al. 09, Figure 7].

![](images/bd5367065a8b21b52180c92d08656770a3190c01b1457ac2f2a6b6aa7b8f734a.jpg)  
Figure 4.17. Lab studies as a validation method.

Lab study, measur e human time/err ors for task

visual encoding and interaction idiom level by measuring time and error rates of people carrying out abstracted tasks, as shown in Figure 4.17.