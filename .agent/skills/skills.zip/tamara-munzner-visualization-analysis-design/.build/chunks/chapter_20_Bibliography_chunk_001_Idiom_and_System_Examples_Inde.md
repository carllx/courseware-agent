# Idiom and System Examples Index

3D Perspective, 327–328

Adjacency Matrix View, 208–209

Animated Transitions, 248–249

Bar Charts, 150–151

Bird’s-Eye Maps, 270–271

Boxplot Charts, 308–310

Cartographic Layering, 289–290

Cerebral, 274–275

Choropleth Maps, 181

Cluster Heatmaps, 158–160

Cluster–Calendar Time-Series Vis, 125–127

Constellation, 360–366, 367

Context-Preserving Visual Links, 253

Continuous Scatterplots, 307–308

Dense Software Overviews, 172–174

Dimensionality Reduction for Document Collections, 316–319

DOITrees Revisited, 325

DOSFA, 304

Dot and Line Charts, 155–156

Ellipsoid Tensor Glyphs, 194–196

Exploratory Data Visualizer (EDV), 268–269

FilmFinder, 301–302

Fisheye Lens, 328–329

Flexible Isosurfaces, 185–186

Flow Maps, 85–87

Force-Directed Placement, 204–206

Genealogical Graphs, 81–83

Geographically Weighted Boxplots, 313–315

Graph-Theoretic Scagnostics, 342–346, 366

GrouseFlocks, 215–216

Hierarchical Clustering Explorer (HCE), 351–355, 367

Hierarchical Edge Bundles, 292–294

Hierarchical Parallel Coordinates, 311–312

Histograms, 306

Hyperbolic Geometry, 329–331

HyperSlice, 259–260

Improvise, 277–278

InterRing, 358–359, 367

Layer-Oriented Time-Series Vis, 128

LineUp, 246–248

Linked Derived Feature Spaces, 62–64, 65

LinLog, 89–90

LiveRAC, 87–89

MatrixExplorer, 83–84

Multidimensional Transfer Functions, 187–188

Multiform Overview–Detail Microarrays, 271–273

Multiscale Banking to $4 5 ^ { \circ }$ , 156–157

Nonlinear Magnification Fields, 333–334

Parallel Coordinates, 162–166

Pie Charts, 168–170

PivotGraph, 355–358, 367

Radial Bar Charts, 167–168

Scatterplot Matrix, 160–161

Scatterplots, 146–148

sfdp, 207–208

Similarity-Clustered Streamlines, 192–193

Sizing the Horizon, 90–91

SolarPlot, 310–311

SpaceTree, 59–60, 65

Stacked Bar Charts, 151–153

Strahler Numbers for Trees, 60–61, 65

Streamgraphs, 153–154

Stretch and Squish Navigation, 331–333

Superimposed Line Charts, 290–291

Tableau, 244–245

Toolglass and Magic Lenses, 326

Topographic Terrain Maps, 183–184

TreeJuxtaposer, 59–60, 65

Treemaps, 213–214

Trellis, 282–284

VisDB, 347–350, 367