# On your Android™ smartphone or tablet

Download the free VitalSource Bookshelf App available via Google Play and log into your Bookshelf account. You can find more information at https://support.vitalsource.com/ hc/en-us/categories/200139976-Bookshelf-for-Androidand-Kindle-Fire