The mid-level spatial layout handles a path segment: one word in the path along with all of the definitions associated with it, using containment marks to show the hierarchical relationships. Figure 15.18(a) shows an example where the box allocated to the entire segment is tan, and the path word has its own definition that is also drawn in the tan section. Figure 15.18(b) shows an example where the path word itself is not defined, but each of the other definitions assigned to it is enclosed in a green box nested within the tan segment.

The low-level spatial layout of a definition is illustrated in Figure 15.19(a). A ladder-like rectilinear structure encodes with both spatial position and line marks. Each leafword is enclosed in its own blue label box. Vertical lines show the hierarchical microstructure inside the definition and are colored white, and horizontal edges are color coded to show the link type.

![](images/0e36bef33c9650463735fc648c351cb110182854b77a46b8130787be2ff1d7fc.jpg)  
(a)

![](images/8323d0719e495991bcabd48b1784a330ae87dd9472ea232b541f460eba0328de.jpg)  
(b)

![](images/fd939de8a401d8e8f89c899f65e7f10a3af216a9eb4e90b3a81b5da59eb5ce07.jpg)  
(c)   
Figure 15.15. Resizing grid cells to increase information density. (a) Base curvilinear grid. (b) After eliminating the empty columns. (c) After eliminating empty cell rows in each column. From [Munzner 00, Figure 5.13].

![](images/c24166f00d09f8d1c8206a5897f122ab07eb20bedfc13942a7bc08d980b7feff.jpg)  
(a)

![](images/457c45c1647d184a2eb458ef7623558663acc4ff3856ac4d008406092317d290.jpg)  
(b)

![](images/203a53de36baf6225a2e5438f12670f58c7a34fddbdc44226cf3734f46198b6d.jpg)  
Figure 15.16. Constellation uses the design choice of dynamic superimposed layers. (a) Edges in the background layer are not obtrusive. (b) The newly selected foreground layer is distinguished from the background with changes of the size, luminance, and saturation channels. From [Munzner 00, Figure 5.5].   
Figure 15.17. The constellation showing all relations of type Part is highlighted. From [Munzner 00, Figure 5.16a].

![](images/821d03c8bf76e5cf140716b62c65e05393d112b730f0d81c39424e94a1a6b299.jpg)  
(a)

![](images/1938ad2b97c96655ed8b30038751bd5ba012051b6caed0d7569b5ebfe208310f.jpg)  
(b)   
Figure 15.18. Mid-level Constellation path segment layout, using containment to show hierarchical relationship between path word in tan and its associated definitions in green. (a) One of the definitions is for the path word itself. (b) Path word that is not itself defined, but only appears within other definitions. From [Munzner 00, Figure 5.9].

![](images/4bb176ba8611037a73d01cc706f7dfaa009738d0371b078e0c2dafff4911a40d.jpg)  
(a)

![](images/df6f3d708ac7d7e90e21da880804b32579368cdfa008a07419b56402b4604975.jpg)  
(b)   
Figure 15.19. Low-level Constellation definition layout, using rectilinear links and spatial position. (a) The base layout, with horizontal lines color-coded for link type. (b) Long-distance links are drawn between the master version of the word and all of its duplicated proxies. From [Munzner 00, Figure 5.10].

Each definition is drawn with all of its associated words in order to make it easy to read, so any word that appears in multiple definitions is duplicated. The master version of the word is the one on the most plausible path, and is drawn in black. All subsequent instances are proxies, which are drawn in gray and are connected to the master by a long slanted line mark, as shown in Figure 15.19(b).

Constellation is optimized for three different viewing levels: a global view for interpath relationships, a local view for reading individual definitions, and an intermediate view for associations within path segments. It uses a subtle form of semantic zooming to achieve this effect, where the amount of space devoted to different classes of words changes dynamically depending on the zoom level. Figure 15.20 shows three steps of a zoom animated transition sequence. In the first frame, the words at the top are given much more space than the rest; in the last frame, the allocation of space is nearly equal for all words.

![](images/f2802466dfb3d8d9c560458a1c6461d72556a26abd7ecbef7d14eabf2a07f02d.jpg)

![](images/f1551d3efbc5a3f67d7a7745317f12fc873ceb5cdac892adea342b4324b02c9a.jpg)

![](images/7ea8df7475bb2d33475d9b41fd672e2ddc153d533eccbb44c9458e90db6cce4f.jpg)  
Figure 15.20. Constellation uses a subtle version of the semantic zooming design choice, where the space allocated for the first word versus the rest of the definition changes according to the zoom level. From [Munzner 00, Figure 5.19].

<table><tr><td>System</td><td>Constellation</td></tr><tr><td>What: Data</td><td>Three-level network of paths, subgraphs (defi-nitions), and nodes (word senses).</td></tr><tr><td>Why: Tasks</td><td>Discover/verify: browse and locate types of paths, identify and compare.</td></tr><tr><td>How: Encode</td><td>Containment and connection link marks, hori-zontal spatial position for plausibility attribute, vertical spatial position for order within path, color links by type.</td></tr><tr><td>How: Manipulate</td><td>Navigate: semantic zooming. Change: Ani-mated transitions.</td></tr><tr><td>How: Reduce</td><td>Superimpose dynamic layers.</td></tr><tr><td>Scale</td><td>Paths: 10–50. Subgraphs: 1–30 per path. Nodes: several thousand.</td></tr></table>