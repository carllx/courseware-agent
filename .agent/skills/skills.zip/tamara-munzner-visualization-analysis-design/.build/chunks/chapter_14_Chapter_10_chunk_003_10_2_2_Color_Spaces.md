# 10.2.2 Color Spaces

The color space of what colors the human visual system can detect is three dimensional; that is, it can be adequately described using three separate axes. There are many ways to mathematically describe color as a space and to transform colors from one such space into another. Some of these are extremely convenient for computer manipulation, while others are a better match with the characteristics of human vision.

The most common color space in computer graphics is the system where colors are specified as triples of red, green, and blue values, which is called the RGB system. Although this system is computationally convenient, it is a very poor match for the mechanics of how we see. The red, green, and blue axes of the RGB color space are not useful as separable channels; they give rise to the integral perception of a color. I do not discuss them further as channels in my analysis of visual encoding.

Another color space, the hue–saturation–lightness or HSL system, is more intuitive and is heavily used by artists and designers. The hue axis captures what we normally think of as pure colors that are not mixed with white or black: red, blue, green, yellow, purple, and so on. The saturation axis is the amount of white mixed with that pure color. For instance, pink is a partially desaturated red. The lightness axis is the amount of black mixed with a color. A common design for color pickers is a disk with white at the center and the hue axis wrapped around the outside, with separate linear control for the amount of darkness versus lightness, as shown in Figure 10.2. The HSV space is very similar, where V stands for grayscale value and is linearly related to L.

![](images/4ff4a1704638bfd26639baf9aea4709d1d26a2c6268013f5ac6b254ac11c8bda.jpg)  
Figure 10.2. A common HSL/HSV colorpicker design, as in this example from Mac OS X, is to show a color wheel with fully saturated color around the outside and white at the center of the circle, and a separate control for the darkness.

Despite the popularity of the HSL space, it is only pseudoperceptual: it does not truly reflect how we perceive color. In particular, the lightness $L$ is wildly different from how we perceive luminance. Figure 10.3 shows six different hues, arranged in order of their luminance. The corresponding computed $L$ values are all identical. The true luminance is a somewhat better match with our perceptual experience: there is some variation between the boxes. However, our perception of luminance does not match what

![](images/49dbf250b38f901815366b885aabaa53a30193ce15ff46bf938d20d628d5d8b7.jpg)  
Figure 10.3. Comparing HSL lightness, true luminance, and perceptually linear luminance $L ^ { * }$ for six colors. The computed HSL lightness $L$ is the same for all of these colors, showing the limitations of that color system. The true luminance values of these same six colors, as could be measured with an instrument. The computed perceptually linear luminance $L ^ { * }$ of these colors is the best match with what we see. After [Stone 06].

![](images/3ba41be8bf798e6793e45f16887422b90d9a4dbc40b1a5360271af94c5259774.jpg)

![](images/a3efc3a5c612933383b966e645fdc0cf77fe441265e876b0ffc61d3ed5bb4c31.jpg)  
Figure 10.4. The spectral sensitivity of our eyes to luminance depends on the wavelength of the incoming light. After [Kaiser 96], http://www.yorku.ca/eye/ photopik.htm.

an instrument would measure: the amount of luminance that humans perceive depends on the wavelength. Figure 10.4 shows the roughly bell-shaped spectral sensitivity curve for daylight vision. We are much more sensitive to middle wavelengths of green and yellow than to the outer wavelengths of red and blue.

There are several color spaces that attempt to provide a perceptually uniform space, including one known as $L ^ { * } a ^ { * } b ^ { * }$ . This space has a single black and white luminance channel $L ^ { * }$ , and the two color axes $a ^ { * }$ and $b ^ { * }$ . Figure 10.3 also shows the $L ^ { * }$ values for the same six boxes, which is even a better match with what we see than true luminance. The $L ^ { * }$ axis is a nonlinear transformation of the luminance perceived by the human eye. Our perception of luminance is compressed, as shown by the exponent of $n = 0 . 5$ for the brightness power law curve in Figure 5.7. The $L ^ { * }$ axis is designed to be perceptually linear, so that equally sized steps appear equal to our visual systems, based on extensive measurement and calibration over a very large set of observers. The color axes have also been designed to be as perceptually linear as possible. The $L ^ { * } a ^ { * } b ^ { * }$ space is thus well suited for many computations, including interpolation and finding differences between colors, that should not be executed in the perceptually nonlinear RGB or HSL spaces.

‣ Accuracy of perception is discussed in Section 5.5.1.

In this book, I use the term luminance as an evocative way to describe the black and white visual channel.* I use saturation and hue for the other two chromaticity channels.*