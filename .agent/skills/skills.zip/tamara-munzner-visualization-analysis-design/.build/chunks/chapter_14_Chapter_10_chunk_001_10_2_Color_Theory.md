# 10.2 Color Theory

Color is a rich and complex topic, and here I only touch on the most crucial aspects that apply to vis.