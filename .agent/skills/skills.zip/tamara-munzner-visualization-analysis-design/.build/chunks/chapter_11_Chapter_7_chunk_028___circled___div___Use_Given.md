# $\circled{ \div}$ Use Given

Geometr y

Geographic   
O ther D erived

Spatial Fields

S calar Fields (one value per cell)

Isocontours   
Direct Volume Rendering

Vector and Tensor Fields (many values per cell)

Flow Glyphs (local)   
Geometric (sparse seeds)   
Tex tures (dense seeds)   
Features (globally derived)

![](images/b40eb504efe1f1e11ae7bf19dce5d2e90bea8df77ad35daf33a600fa2ad83fa0.jpg)

![](images/cc19596cc438d0966049bcddf050c1f2bb9fba3ba02a6b070cea57c7fa208397.jpg)  
Figure 8.1. Design choices for using given spatial data: geometry or spatial fields.

r↑↑↑ス

κ↑↑→↑   
κκ↑→↑