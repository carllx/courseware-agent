# 2.5.2 Ordered: Ordinal and Quantitative

All ordered data does have an implicit ordering, as opposed to unordered categorical data. This type can be further subdivided. With ordinal data, such as shirt size, we cannot do full-fledged arithmetic, but there is a well-defined ordering. For example, large minus medium is not a meaningful concept, but we know that medium falls between small and large. Rankings are another kind

of ordinal data; some examples of ordered data are top-ten lists of movies or initial lineups for sports tournaments depending on past performance.

A subset of ordered data is quantitative data, namely, a measurement of magnitude that supports arithmetic comparison. For example, the quantity of 68 inches minus 42 inches is a meaningful concept, and the answer of 26 inches can be calculated. Other examples of quantitative data are height, weight, temperature, stock price, number of calling functions in a program, and number of drinks sold at a coffee shop in a day. Both integers and real numbers are quantitative data.3

In this book, the ordered type is used often; the ordinal type is only occasionally mentioned, when the distinction between it and the quantitative type matters.