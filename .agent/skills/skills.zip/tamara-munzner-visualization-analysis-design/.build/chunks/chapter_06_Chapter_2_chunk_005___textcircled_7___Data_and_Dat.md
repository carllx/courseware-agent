# $\textcircled{7}$ Data and Dataset Types

![](images/c38b97fd5f3d90b27f2c046a543edf95a1ae3372e405f67785345ffaa9114fc8.jpg)  
Figure 2.3. The four basic dataset types are tables, networks, fields, and geometry; other possible collections of items are clusters, sets, and lists. These datasets are made up of five core data types: items, attributes, links, positions, and grids.

![](images/57ab6618a5ebecf7cfdc5b2ba1a9b8845fb8d21699411be139bd73f2679256c7.jpg)