# $\textcircled{ \div}$ Separate, Order, Align Regions

![](images/8dc432da71e506dbadbeed8476d5f2772f5e81bb409ae8b40eaf3ba80ff65314.jpg)

![](images/5f64d2c244a0a6844b455187eb09e2341639565abd17670bb6abb1eb373bcabe.jpg)

![](images/915f70d1a27fdcf3fcf38c29a9e9ab94ec1178746419c8b71693b086ef0c5007.jpg)  
2 Keys Matrix   
3 Keys Volume   
Many Keys Recursive Subdivision

![](images/28bf486c82c25f1b24da66dbd727e0305cbca1366f7f3b62d3e46f9e5a9efbeb.jpg)  
1 Key List

![](images/649d39b7436c1565ac8e5c45e04e168d5534c776774fb6fba5248c4c1864c64e.jpg)

![](images/3f8a7ff251b16a157ebf2f83aad080a3846c21657d275c1e304043eae78f180c.jpg)

![](images/42041f057efcefea783790cbed70cdab1717d2f433d6284276145022f5606cdf.jpg)