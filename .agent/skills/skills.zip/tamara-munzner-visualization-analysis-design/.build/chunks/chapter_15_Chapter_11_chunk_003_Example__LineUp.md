# Example: LineUp

The LineUp system is designed to support exploration of tables with many attributes through interactive reordering and realigning. In addition to sorting by any individual attribute, the user can sort by complex weighted combinations of multiple attributes. LineUp is explicitly designed to support the comparison of multiple rankings.

Figure 11.3 compares several different rankings of top universities. On the left is a customized combination of attributes and weights for the 2012 data, and in the middle is the official ranking for 2012, with colored

![](images/a729ece02ff4b1ce6aeedaa9a98fc85eb32efc708c768757a960ab3ca1e510bb.jpg)  
Figure 11.3. The LineUp system for comparing multiattribute rankings with reordering and realignment. From [Gratzl et al. 13, Figure 1].

![](images/1ae17a5fa107a80f6045ff0ba309e845083f88d41bb164a341fa903cf1d67b0d.jpg)  
(a)

![](images/cee9ba353eedf547c0176ada8bc706cc3b83cd4094598469574bcf4332d7c700.jpg)  
(b)

![](images/e8e25eaecb3ce3f8e690cd09ff38773a1d42d6ee4e424e044b3b193fb811007b.jpg)  
(c)

![](images/4afb45966048c9dcc80bd0d911d48522afcee1045f0a6ccd23d90da16eef6658.jpg)

Figure 11.4. Changing the alignment in Lineup. (a) Classical stacked bars. (b) Diverging stacked bars. (c) Ordered stacked bars. (d) Separately aligned bars: small multiple bar charts. From [Gratzl et al. 13, Figure 4].

stacked bar charts showing the contribution of the component attributes for both. The next two columns show a compressed view with a single summary bar for two more rankings, using the data for years 2011 and 2010, and the last three columns have a collapsed heatmap view with the value encoded in grayscale rather than with bar length. The uncollapsed columns are scented widgets, with histograms showing the distributions within them at the top. Between the bar chart columns are slope graphs, where connecting line marks link the same items together.* Items that do not change their ranking between neighboring columns are connected by straight lines, while highly sloped lines that cross many others show items whose ranking changed significantly.

Figure 11.4 shows the results of changing the alignment to each of the four different possibilities. In addition to classical stacked bars as in Figure 11.4(a), any of the attributes can be set as the baseline from which the alignment diverges, as in Figure 11.4(b). Figure 11.4(c) shows the bars sorted by decreasing size separately in each row, for the purpose of emphasizing which attributes contribute most to that item’s score. Figure 11.4(d) shows each attribute aligned to its own baseline, which yields a small-multiple view with one horizontal bar chart in each column. When

‣ Scented widgets are covered in Section 13.3.1.   
* Slope graphs are also known as bump charts.   
Partitioning data into small-multiple views is covered in Section 12.4.

‣ Animated transitions are discussed in the next example.

the alignment is changed, an animated transition between the two states occurs.

In contrast to many of the previous examples of using derived data, where the vis designer is the one who makes choices about deriving data, with LineUp the user decides what data to derive on the fly during an analysis session.

<table><tr><td>System</td><td>LineUp</td></tr><tr><td>What: Data</td><td>Table.</td></tr><tr><td>What: Derived</td><td>Ordered attribute: weighted combination of selected attributes.</td></tr><tr><td>How: Encode</td><td>Stacked bar charts, slope graphs.</td></tr><tr><td>How: Manipulate</td><td>Reorder, realign, animated transitions.</td></tr><tr><td>Why: Task</td><td>Compare rankings, distributions.</td></tr></table>

Design choices for reducing and increasing the data shown are discussed in Chapter 13.   
The Eyes Beat Memory rule of thumb in Section 6.5 discusses some of the strengths and weaknesses of animation.   
* The term jump cut comes from cinematography.   
Navigation is covered in Section 11.5.

Many kinds of change involve reducing or increasing the amount of data that is shown: changes to aggregation and filtering are at the heart of interactive data reduction idioms.

Many kinds of changes to a view over time fall into the general category of animation, including changes to the spatial layout. While animation has intuitive appeal to many beginning designers, it is valuable to think carefully about cognitive load and other trade-offs.