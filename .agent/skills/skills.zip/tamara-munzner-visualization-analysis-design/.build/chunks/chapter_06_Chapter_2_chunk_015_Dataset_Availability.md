# Dataset Availability

Static

![](images/e9ff84720f2b9e376107e7177fc61d1006722045a47e51f07fa5949bd228292b.jpg)

Dynamic

![](images/27c75eece0fe13591a3f7b9afbae3f8f9ebd797cc2fd931ada7846f0db884415.jpg)  
Figure 2.6. Dataset availability can be either static or dynamic, for any dataset type.

data; that is, the data abstraction. In simple cases, it may be possible to describe your data abstraction using only that set of terms. In complex cases, you may need additional description as well. If so, your goal should be to translate domain-specific terms into words that are as generic as possible.