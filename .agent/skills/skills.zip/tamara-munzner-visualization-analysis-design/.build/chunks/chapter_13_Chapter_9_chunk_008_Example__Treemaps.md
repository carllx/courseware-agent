# Example: Treemaps

The idiom of treemaps is an alternative to node–link tree drawings, where the hierarchical relationships are shown with containment rather than connection. All of the children of a tree node are enclosed within the area allocated that node, creating a nested layout. The size of the nodes is mapped to some attribute of the node. Figure 9.8 is a treemap view of the

![](images/276175e811b4fba43da756768954eb6a289ce2fb23498ed806e4eeaefcd3a91b.jpg)  
Figure 9.8. Treemap layout showing hierarchical structure with containment rather than connection, in contrast to the node–link diagrams of the same 5161-node tree in Figure 9.3.

same dataset as Figure 9.3, a 5161-node computer file system. Here, node size encodes file size. Containment marks are not as effective as the pairwise connection marks for tasks focused on topological structure, such as tracing paths through the tree, but they shine for tasks that pertain to understanding attribute values at the leaves of the tree. They are often used when hierarchies are shallow rather than deep. Treemaps are very effective for spotting the outliers of very large attribute values, in this case large files.

<table><tr><td>Idiom</td><td>Treemaps</td></tr><tr><td>What: Data</td><td>Tree.</td></tr><tr><td>How: Encode</td><td>Area marks and containment, with rectilinear layout.</td></tr><tr><td>Why: Tasks</td><td>Query attributes at leaf nodes.</td></tr><tr><td>Scale</td><td>Leaf nodes: one million. Links: one million.</td></tr></table>

Figure 9.9 shows seven different visual encoding idioms for tree data. Two of the visual encoding idioms in Figure 9.9 use containment: the treemap in Figure 9.9(f) consisting of nested rectangles, and the nested circles of Figure 9.9(e). Two use connection: the vertical node–link layout in Figure 9.9(a) and the radial node–link layout in Figure 9.9(c).

Although connection and containment marks that depict the link structure of the network explicitly are very common ways to encode networks, they are not the only way. In most of the trees in Figure 9.9, the spatial position channel is explicitly used to show

![](images/bf47d383fdeee22ad77fe9c4943bf833e35f51a95e75e16b560d1f5f34548d69.jpg)  
(a)

![](images/589d9e59ab5573e672490c0df0cb15aee9daa50d570b96cd3b500b828c09f575.jpg)  
(b)

![](images/d780f4359bdc84aa6ed0bc290055da574a46382b2da4995a776493bb7df3b0e5.jpg)  
(c)

![](images/956a708f9474b5a48ad9f3043bf1db040e2436440cda2a985356b21e870c756a.jpg)  
(d)

![](images/cda5dc6b7ac46de06d4132f688937ac97bf473d122e7f69f9ff94504f1ba18a3.jpg)

![](images/bd0d812fd2507ec5c6a73bbc94e3a86034e2243512268a0893cb1dd159761f03.jpg)

![](images/52c73367f6e779b050ddf924f941e45365e395f941403c237f986365289d4ccb.jpg)  
(g)   
Figure 9.9. Seven visual encoding idioms showing the same tree dataset, using different combinations of visual channels. (a) Rectilinear vertical node–link, using connection to show link relationships, with vertical spatial position showing tree depth and horizontal spatial position showing sibling order. (b) Icicle, with vertical spatial position and size showing tree depth, and horizontal spatial position showing link relationships and sibling order. (c) Radial node– link, using connection to show link relationships, with radial depth spatial position showing tree depth and radial angular position showing sibling order. (d) Concentric circles, with radial depth spatial position and size showing tree depth and radial angular spatial position showing link relationships and sibling order. (e) Nested circles, using radial containment, with nesting level and size showing tree depth. (f) Treemap, using rectilinear containment, with nesting level and size showing tree depth. (g) Indented outline, with horizontal spatial position showing tree depth and link relationships and vertical spatial position showing sibling order. From [McGuffin and Robert 10, Figure 1].

the tree depth of a node. However, three layouts show parent–child relationships without any connection marks at all. The rectilinear icicle tree of Figure 9.9(b) and the radial concentric circle tree of Figure 9.9(d) show tree depth with one spatial dimension and parent–child relationships with the other. Similarly, the indented outline tree of Figure 9.9(g) shows parent–child relationships with relative vertical position, in addition to tree depth with horizontal position.