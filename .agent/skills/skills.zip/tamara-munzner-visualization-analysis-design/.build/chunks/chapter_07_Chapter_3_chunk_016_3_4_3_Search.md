# 3.4.3 Search

All of the high-level analyze cases require the user to search for elements of interest within the vis as a mid-level goal.* The classification of search into four alternatives is broken down according to whether the identity and location of the search target is already known or not.