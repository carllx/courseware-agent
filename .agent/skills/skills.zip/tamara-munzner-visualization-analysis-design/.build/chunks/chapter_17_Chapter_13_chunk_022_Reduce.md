# Reduce

$\circled{ \div}$ Filter

![](images/45509cef3706172b8dd6046b15f07ff0985008f852b213e963d72694fa5f53d3.jpg)

$\circled{ \div}$ Aggregate

![](images/0dd2cc7e0c7985062745c18fc3518e3f165fd3b30b5aae74d922b252e99c222f.jpg)

$\circled{  }$ Embed

![](images/533a7c591d15141f600145074dc91398c3393cf955db3fe63e684af62183d74b.jpg)  
Figure 14.1. Design choices for embedding focus information within context.