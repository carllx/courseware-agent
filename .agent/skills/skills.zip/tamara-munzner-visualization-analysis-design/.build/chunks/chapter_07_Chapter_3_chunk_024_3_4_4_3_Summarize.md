# 3.4.4.3 Summarize

The scope of summarize task is all possible targets. A synonym for summarize is overview, a term is frequently used in the vis literature both as a verb, where it means to provide a comprehensive view of everything, and as a noun, where it means a summary display of everything. The goal of providing an overview is extremely common in visualization.