# 10.5 Further Reading

The Big Picture Ware’s textbook is an excellent resource for further detail on all of the channels covered in this chapter [Ware 13].

Color Theory Stone’s brief article [Stone 10] and longer book [Stone 03] are an excellent introduction to color.

Colormap Design The design of segmented colormaps has been extensively discussed in the cartographic literature: Brewer offers very readable color use guidelines [Brewer 99] derived from that community, in conjunction with the very useful ColorBrewer tool at http://www.colorbrewer2.org. Early guidelines on quantitative colormap creation and the reasons to avoid rainbow colormaps are in series of papers [Bergman et al. 95,Rogowitz and Treinish 96,Rogowitz and Treinish 98], with more recent work continuing the struggle against rainbows as a default [Borland and Taylor 07]. An empirical study of bivariate colormaps showed their serious limitations for encoding two categorical attributes [Wainer and Francolini 80].

Motion An empirical study investigated different kinds of motion highlighting and confirmed its effectiveness in contexts where color coding was already being used to convey other information [Ware and Bobrow 04].

Texture Ware proposes breaking down texture into orientation, scale, and constrast subchannels, as part of a thorough discussion of the use of texture for visual encoding in his textbook [Ware 13, Chapter 6].

$\circled{ \div}$ Change o ver Time

![](images/412e217c0e9339473d05571d760f97690c9bf77ecd4de4ba2310f6e3accb3863.jpg)

$\textcircled{7}$ Selec t

![](images/e83d65b383dd9678c4125e36b9aa7a2dd45d5c74afd6c8c27f74d3940bfc82af.jpg)

$\textcircled{ \div}$ Navigate

I tem Reduc tion

![](images/39eb40797da5277534ec051b2e992275a3a005dda5429acc34c2a0710d773182.jpg)

Pan/Translate

![](images/6e8b757e809b7d98d238aa72a52299d28479a119f9fc013e1edc6d2b1831f902.jpg)

Constrained

![](images/0a1aac3fd88e2850409b06e9a24307d447830af1de5f51d5188abdc6e019d182.jpg)

Attribute Reduc tion

![](images/b91093df611a7a8bdd2a49a1afb2b9320112b1d1fa4a11f6ca8815dd3e54d519.jpg)

Cut

![](images/68b9abfc8daacef0c22c8598f65c38006d361eaccf3b77383015dce90ae9092e.jpg)

Project

![](images/a0485933918abf234c0f8202b71efeada16693e20cc03fa775e3bc98c9c5fd3e.jpg)  
Figure 11.1. Design choices for idioms that change a view.