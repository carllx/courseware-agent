# 14.7 Further Reading

The Big Picture Two extensive surveys discuss a broad set of idioms that use the choices of changing the viewpoint through navigation, partitioning into multiple views, and embedding focus into context, including an assessment of the empirical evidence on the strengths and weaknesses of these three approaches and guidelines for design [Cockburn et al. 08, Lam and Munzner 10].

Early Work Early proposals for focus+context interfaces were the Bifocal Display [Spence and Apperley 82] and polyfocal cartography [Kadmon and Shlomi 78]. An early taxonomy of distortion-based interfaces introduced the unifying vocabulary of magnification and transformation functions [Leung and Apperley 94].

Fisheye Views The fundamental idea of generalized fisheye views [Furnas 82,Furnas 86] was followed up 20 years later with a paper

questioning the overwhelming emphasis on geometric distortion in the work of many others in the intervening decades [Furnas 06].

3D Perspective Influential 3D focus+context interfaces from Xerox PARC included the Perspective Wall [Mackinlay et al. 91] and Cone Trees [Robertson et al. 91].

Frameworks Two general frameworks for focus+context magnification and minimization are elastic presentation spaces [Carpendale et al. 95, Carpendale et al. 96] and nonlinear magnification fields [Keahey and Robertson 97].

Hyperbolic Geometry Hyperbolic 2D trees were proposed at Xerox PARC [Lamping et al. 95] and 3D hyperbolic networks were investigated at Stanford [Munzner 98].

Stretch and Squish Navigation The TreeJuxtaposer system proposed the guaranteed visibility idiom and presented algorithms for stretch and squish navigation of large trees [Munzner et al. 03], followed by the PRISAD framework that provided further scalability and handled several data types [Slack et al. 06].

![](images/259cc7fb0e7de191b4c2356442f663285d5afd85f85f7a169bbe271f485ee41f.jpg)

#

![](images/0e9dcad1ccf1b84beb39454ed6b99c8bbd097133e08f2884b2cafe494f685c7d.jpg)  
(a)

![](images/e9ef0992848a70616df96d45f3b2ec3445a03e5c730f9728d07a19f0a0dd699e.jpg)  
(b)

![](images/176d1b0716a9964864737a3501b7daee85ba9b7b740331ced70bfc6b56e113f4.jpg)

![](images/7153819f75ff6be1a9818ab74cb336376726a9d279f5841cb47ccecca853b597.jpg)  
(d)

![](images/b5f31e3ffeea80f7e89f6b8c3bd4862e5bad223adcf63a93cb402a800561e36c.jpg)

![](images/58c31d4791bd047cda6a36a9a7db5d33206d09e94fb34a30098a4eab7242a18c.jpg)  
(f)   
Figure 15.1. Six case studies of full vis systems. (a) Scagnostics, from [Wilkinson et al. 05, Figure 5]. (b) VisDB, from [Keim and Kriegel 94, Figure 6]. (c) Hierarchical Clustering Explorer, from [Seo and Shneiderman 05, Figure 1]. (d) PivotGraph, from [Wattenberg 06, Figure 5]. (e) InterRing, from [Yang et al. 02, Figure 4]. (f) Constellation, from [Munzner 00, Figure 5.5].