# Ordering Direc tion

Sequential

![](images/092a9f478c386fb62a13eb3b0f0c556391cd2caf956fa341c359abb0a686ed96.jpg)

Diverging

![](images/b6fb7afb077cc16ca2733cc1a1a0a4322e0e391b1045c3df0eb360aa24e01a15.jpg)

Cyclic

![](images/1abde98693cf0261bc4587133cbbf6079968b87293a2278d5e51736d9c587940.jpg)  
Figure 2.1. What can be visualized: data, datasets, and attributes.

What?

Why?

How?