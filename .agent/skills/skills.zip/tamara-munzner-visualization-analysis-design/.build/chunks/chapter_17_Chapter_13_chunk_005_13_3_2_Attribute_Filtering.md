# 13.3.2 Attribute Filtering

Attributes can also be filtered. With attribute filtering, the goal is to eliminate attributes rather than items; that is, to show the same number of items, but fewer attributes for each item.

* Many idioms for attribute filtering and aggregation use the alternative term dimension rather than attribute in their names.   
‣ For more on star plots, see Section 7.6.3.

Item filtering and attribute filtering can be combined, with the result of showing both fewer items and fewer attributes.