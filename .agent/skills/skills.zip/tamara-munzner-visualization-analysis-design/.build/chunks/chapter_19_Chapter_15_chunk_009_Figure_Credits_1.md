# Figure Credits

Any figures not listed here are released under the Creative Commons Attribution 4.0 International license (CC BY 4.0), to be credited as Tamara Munzner, with illustrations by Eamonn Maguire, Visualization Analysis and Design, A K Peters Visualization Series, CRC Press, Boca Raton, FL, 2014.

Figure 1.1 Copyright $\circledcirc$ 2013 by IEEE.

Figure 1.2 Reproduced under Creative Commons Attribution Non-Commercial license (CC BY-NC 2.0).

Figure 1.4 Copyright $\circledcirc$ 2007 by IEEE.

Figure 1.5 Courtesy of Miriah Meyer.

Figure 1.6 Michael J. McGuffin and Jean-Marc Robert, Information Visualization (9:2) pp. 115-140, copyright $\circledcirc$ 2010 by SAGE Publications. Reprinted by Permission of SAGE.

Figure 2.5 Courtesy of Miriah Meyer.

Figure 2.9 Courtesy of Miriah Meyer.

Figure 3.4 Copyright $\circledcirc$ 2008 by IEEE.

Figure 3.8(a) Courtesy of Catherine Plaisant.

Figure 3.8(b) [Munzner et al. 03] $\circledcirc$ 2003 Association for Computing Machinery, Inc. Reprinted by permission.

Figure 3.10 Courtesy of David Auber.

Figure 3.12 Copyright $\circledcirc$ 1998 by IEEE.

Figure 4.3 Copyright $\circledcirc$ 2008 by IEEE.

Figure 4.6 Copyright $\circledcirc$ 2005 by IEEE.

Figure 4.8 Copyright $\circledcirc$ 2006 by IEEE.

Figure 4.10 Copyright $\circledcirc$ 2005 by IEEE.

Figure 4.12 [McLachlan et al. 08] $\circledcirc$ 2008 Association for Computing Machinery, Inc. Reprinted by permission.

Figure 4.14 Springer, Graph Drawing, Lecture Notes in Computer Science, 2912, 2004, pages 425- 436, “An Energy Model for Visual Graph Clustering,” Andreas Noack, Figure 1, copyright $\circledcirc$ 2004 Springer. With kind permission from Springer Science and Business Media.

Original caption: Pseudo-random graph with intra-cluster edge probability 0.16 and intercluster edge probability 0.02; left: LinLog model.

Figure 4.16 [Heer et al. 09] $\circledcirc$ 2010 Association for Computing Machinery, Inc. Reprinted by permission.   
Figure 5.8 [Heer and Bostock 10] $\circledcirc$ 2010 Association for Computing Machinery, Inc. Reprinted by permission.   
Figure 5.9 Courtesy of TeleGeography, www.telegeography.com.   
Figure 5.14 Courtesy of Edward H. Adelson. $\circledcirc$ 1995 Edward H. Adelson.   
Figure 5.15 Courtesy of Dale Purves, http://www.purveslab.net/seeforyourself.   
Figure 6.3 Copyright $\circledcirc$ 1996 by IEEE.   
Figure 6.4 Courtesy of Stephen Few. An example of poor design, from http://perceptualedge.com/ files/GraphDesignIQ.html.   
Figure 6.5 Copyright $\circledcirc$ 1996 by IEEE.   
Figure 6.6 Copyright $\circledcirc$ 2007 by IEEE.   
Figure 6.7 Copyright $\circledcirc$ 1999 by IEEE.   
Figure 6.8 Copyright $\circledcirc$ 2010 by IEEE.   
Figure 6.9 Copyright $\circledcirc$ 2007 by IEEE.   
Figure 7.2 Copyright $\circledcirc$ 2008 by IEEE.   
Figure 7.3 “A layered grammar of graphics,” Hadley Wickham, Journal of Computational and Graphical Statistics 19:1 (2010), 3-28. Reprinted by permission of the American Statistical Association (http://www.amstat.org).   
Figure 7.5 Courtesy of Robert P. Bosch, Jr.   
Figure 7.6 Copyright $\circledcirc$ 2008 by IEEE.   
Figure 7.7 Copyright $\circledcirc$ 2008 by IEEE.   
Figure 7.10 Copyright $\circledcirc$ 2006 by IEEE.   
Figure 7.11 From http://en.wikipedia.org/wiki/File:Heatmap.png. Created by Miguel Andrade using the program Cluster from Michael Eisen, which is available from http://rana.lbl.gov/ EisenSoftware.htm, with data extracted from the StemBase database of gene expression data.   
Figure 7.13 “Hyperdimensional Data Analysis Using Parallel Coordinates,” Edward J. Wegman, Journal American Statistical Association 85:411 (1990), 664–675. Reprinted by permission of the American Statistical Association (http://www.amstat.org).   
Figure 7.14 Copyright $\circledcirc$ 1999 by IEEE.   
Figure 7.15(a,b) “A layered grammar of graphics,” Hadley Wickham, Journal of Computational and Graphical Statistics 19:1 (2010), 3-28. Reprinted by permission of the American Statistical Association (http://www.amstat.org).   
Figure 7.17 “A layered grammar of graphics,” Hadley Wickham, Journal of Computational and Graphical Statistics 19:1 (2010), 3-28. Reprinted by permission of the American Statistical Association (http://www.amstat.org).