# 10.2.1 Color Vision

The retina of the eye has two different kinds of receptors. The rods actively contribute to vision only in low-light settings and provide low-resolution black and white information. I will thus not discuss them further in this book. The main sensors in normal lighting conditions are the cones. There are three types of cones, each with peak sensitivities at a different wavelength within the spectrum of

* There is a type of color deficiency where the blue– yellow channel is impaired, tritanopia, but it is extremely rare and not sex linked. The two common forms of red–green color blindness are deuteranopia and protanopia; both are sex linked.

visible light. The visual system immediately processes these signals into three opponent color channels: one from red to green, one from blue to yellow, and one from black and white encoding luminance information. The luminance channel conveys highresolution edge information, while the red–green and blue–yellow channels are lower resolution. This split between luminance and chromaticity—what most people informally call would normally call color—is a central issue in visual encoding design.

The theory of opponent color channels explains what is colloquially called color blindness, which affects around $8 \%$ of men in its most common form. A more accurate term is color deficiency, since a “colorblind” person’s ability to differentiate color along the red–green channel is reduced or absent but their blue–yellow channel is still in full working order. *