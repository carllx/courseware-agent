variable, see attribute

variance, 305

vase plot, 309

vector field, 37, 187–194, 197

vectors, 27, 37

velocity, 238

verification, 75

verify, 47

vertex, see node

view, 280–281

viewpoint, 254

vis, xviii, 1

visual channel, see channel

visual encoding, 10, 71–72

visualization, 1

Weber’s Law, 112

what, 17, 21–40

what–where, see channel, identity

what–why–how, 17, 58–64

whiskers, 308

white space, 174

why, 17, 43–57

window, see view

working memory, 132

zooming, 254–256