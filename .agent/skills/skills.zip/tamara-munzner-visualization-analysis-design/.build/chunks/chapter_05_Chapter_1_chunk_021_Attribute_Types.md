# Attribute Types

Categorical

![](images/4e421ab95d900f3fcf3e6701bf853e867911f7e46a4900bfe8e6dcb6a37fa8b6.jpg)

Ordered

Ordinal

![](images/29661a6a1af7a1ca5fe6be23bf4d88993d4adffd32f7757851c5684194a2a43e.jpg)

Quantitative

![](images/1c750c8cac3d9c44be539070d3c7a4be52f3e942e2b81ae00309a6897e2c6cf9.jpg)

![](images/ce4876c85097e0225195449c377504c79f5d4e18748f0311877d523322263d05.jpg)