# $\textcircled{3}$ Layout Density

![](images/7798002cc6772722d0b85664b390b44139fce101d5bb80edd7f445ca95bb5031.jpg)  
Dense

![](images/0813c204b9f218b903cfcc91b0075a591f6e1f75753b6b5f0a4deb63c8bf05d9.jpg)  
Space-Filling   
Figure 7.1. Design choices for arranging tables.