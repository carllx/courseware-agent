# What?

$\circled{ \div}$ In Spatial field   
$\circledast$ In Many quantitative attributes   
$\circledcirc$ Out Jux taposed attribute plots with linked coloring