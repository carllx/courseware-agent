# 7.3 Arrange by Keys and Values

The distinction between key and value attributes is very relevant to visually encoding table data. A key is an independent attribute that can be used as a unique index to look up items in a table, while a value is a dependent attribute: the value of a cell in a table. Key attributes can be categorical or ordinal, whereas values can be all

A fifth arrangement choice, to use a given spatial layout, is not an option for nonspatial information; it is covered in Chapter 8.

‣ The primacy of the spatial position channels is discussed at length in Chapter 5, as are the principles of effectiveness and expressiveness.

See Section 2.6.1 for more on keys and values.

three of the types: categorical, ordinal, or quantitative. The unique values for a categorical or ordered attribute are called levels, to avoid the confusion of overloading the term value.

The core design choices for visually encoding tables directly relate to the semantics of the table’s attributes: how many keys and how many values does it have? An idiom could only show values, with no keys; scatterplots are the canonical example of showing two value attributes. An idiom could show one key and one value attribute; bar charts are the best-known example. An idiom could show two keys and one value; for example, heatmaps. Idioms that show many keys and many values often recursively subdivide space into many regions, as with scatterplot matrices.

While datasets do only have attributes with value semantics, it would be rare to visually encode a dataset that has only key attributes. Keys are typically used to define a region of space for each item in which one or more value attributes are shown.