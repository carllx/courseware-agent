# Example: Streamgraphs

Figure 7.6 shows a more complex generalized stacked graph display idiom with a dataset of music listening history, with one time series per artist counting the number of times their music was listened to each week [Byron and Wattenberg 08]. The streamgraph idiom shows derived geometry that emphasizes the continuity of the horizontal layers that represent the artists, rather than showing individual vertical glyphs that would emphasize listening behavior at a specific point in time.1 The derived geometry is the result of a global computation, whereas individual glyphs can be constructed using only calculations about their own local region. The streamgraph idiom emphasizes the legibility of the individual streams with a deliberately organic silhouette, rather than using the horizontal axis as

![](images/60927791453e2f0fd8606a5b62047d7c8c73927dc7bc534046fe919309f7627c.jpg)  
Figure 7.6. Streamgraph of music listening history. From [Byron and Wattenberg 08, Figure 0].

![](images/f338c8c269b54554c3975af9ac1c75171ff9b26b8922d67de2fca022a6b81f87.jpg)  
(a)

![](images/84f2112f4beb242e7dfc2aff1a45e922fab039e7816830ac4593d4618e569d24.jpg)  
(b)   
Figure 7.7. Streamgraphs with layers ordered by different derived attributes. (a) Volatility of artist’s popularity. (b) Onset time when artist’s music of first gained attention. From [Byron and Wattenberg 08, Figure 15].

the baseline. The shape of the layout is optimized as a trade-off between multiple factors, including the external silhouette of the entire shape, the deviation of each layer from the baseline, and the amount of wiggle in the baseline. The order of the layers is computed with an algorithm that emphasizes a derived value; Figure 7.7 shows the difference between sorting by the volatility of the artist’s popularity, as shown in Figure 7.7(a), and the onset time when they begin to gain attention, as shown in Figure 7.7(b).

Streamgraphs scale to a larger number of categories than stacked bar charts, because most layers do not extend across the entire length of the timeline.

<table><tr><td>Idiom</td><td>Streamgraphs</td></tr><tr><td>What: Data</td><td>Multidimensional table: one quantitative value attribute (counts), one ordered key attribute (time), one categorical key attribute (artist).</td></tr><tr><td>What: Derived</td><td>One quantitative attribute (for layer ordering).</td></tr><tr><td>How: Encode</td><td>Use derived geometry showing artist layers across time, layer height encodes counts.</td></tr><tr><td>Scale</td><td>Key attributes (time, main axis): hundreds of time points. Key attributes (artists, short axis): dozens to hundreds</td></tr></table>