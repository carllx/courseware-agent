# Example: 3D Perspective

Several early idioms used 3D perspective to provide a global distortion region with a single focus point. The interaction metaphor was constrained geometric navigation. The perspective distortion arising from

![](images/2a57e3a8a199f1ab41bf697de3f01c59bb72e947e1d7b0a44dc393a218fbb55c.jpg)  
Figure 14.4. The Cone Tree system used 3D perspective for focus+context, providing a global distortion region with a single focus point, and using standard geometric navigation for interaction. From [Card and Mackinlay 99, Figure 10].

The costs and benefits of 3D are discussed in Section 6.3.

the standard 3D computer graphics transformations is a very intuitive and familiar effect. It was used with the explicit intention of providing a distortion-based focus+context user experience in many early vis systems, such as the influential Cone Tree system shown in Figure 14.4 [Robertson et al. 91].

Although many people found it compelling and expressed a strong preference for it on their first encounter, this approach lost popularity as the trade-offs between the costs and benefits of 3D spatial layout for abstract information became more understood.

<table><tr><td>System</td><td>Cone Trees</td></tr><tr><td>What: Data</td><td>Tree.</td></tr><tr><td>How: Encode</td><td>3D node–link layout.</td></tr><tr><td>How: Reduce</td><td>Embed: distort with 3D perspective; single global focus region.</td></tr><tr><td>Scale</td><td>Nodes: thousands.</td></tr></table>