# Concept Index

abstract data, see nonspatial data

abstraction, 70–71, 78, 92

accuracy, 103

actions, 45

adjacency matrix, 83, 208, 210–213, 216

advection, 190

affine invariant, 320

aggregate, 305–316

aggregation, 305, 320, 324, 351, 355

algorithm, 72–73, 80–81, 92

alpha sliders, 301

analyze, 45

animated transitions, 248, 257, 261

animation, 132–133, 141, 248

anisotropic, 195

annotate, 49

anomalies, see outliers

arrange, 145–217

array, see list

aspect ratio, 156

attribute, 23, 25, 40

categorical, 32

cyclic, 33

dependent, 40

dimension, 40

diverging, 33

independent, 40

interval, 33

key, 40, 145–161

measure, 40

ordered, 32

ordinal, 32

quantitative, 33

ratio, 33

sequential, 33

temporal, 38, 40

value, 40, 145–149

attribute aggregation, see dimensionality reduction (DR)

attribute filtering, 303–305

attribute ordering, 305

attribute reduction, 321

attribute synthesis, see dimensionality reduction (DR)

bag of words, 316

banking to $4 5 ^ { \circ }$ , 157, 175

bar charts, 149–153, 167–170, 175

benchmarks, 80

biclustering, see matrix reordering

bifocal displays, see also focus+context, 337

binary, 234

binned colormap, see colormap, segmented

bins, 106

bivariate, see colormap, bivariate

block, 68

box-and-whisker diagrams, see boxplots

boxplots, 308–310, 313–315, 320

brightness, 223

Bring and Go, 337

browse, 54

brushing, see linked highlighting

bubble plots, 148

bump charts, see slope graphs

cartogram, 98

cartographic generalization, 180

cell, 25, 27

centrality metrics, 60

change, 244–249, 261

change blindness, 15, 19, 133–134, 142

channel, 95–99

aligned spatial position, 101

angle, 101, 236–237

area, 101

curvature, 101, 237–238

depth, 101

hue, see also hue, 101

identity, 99

channel (continued)

length, 101

luminance, see also

luminance, 101

magnitude, 99

motion, 101, 238–239

region, 101

saturation, see also

saturation, 101

shape, 238

size, 236

tilt, 237

unaligned spatial

position, 101

volume, 101

chart, 26

choropleth, 181

chromaticity, 220

clipping plane, see cutting plane

clique, 211

cluster heatmap, 160, 351

cluster hierarchy, 160

clusters, 30, 89

co-clustering, see matrix reordering

coarsening, 206

cognitive load, 132

color, 223

color blindness, 220, 235

color constancy, 114

color deficiency, see color blindness

color ramp, see colormap

color space, 220

HSL, 220

$L ^ { * } a ^ { * } b ^ { * }$ , 222

RGB, 220

colormap, 225

bivariate, 234

categorical, 225, 226

continuous, 225

diverging, 225, 231

monotonically increasing

luminance, 232

ordered, 225, 229–234

segmented, 225

sequential, 225, 229

compare, 54, 55

compound network, 30, 215, 292

conditioning, see partitioning

cones, 219

connection, 99, 201–210, 212–213

constrained navigation, 257, 262, 327

consume, 45

containment, 99, 213–216

context, 323

continuous, 27

contour lines, see isolines

contour plot, 129, 183

contour tree, 185

coordinate, 267–278, 296

coordinated multiple views, see linked views

coordinated views, see linked views

correlation, 57

coupled views, see linked views

coxcomb plot, see polar area chart

critical points, 189

cross-filtering, see linked highlighting

cross-hatching, see stippling

curvature, 238

cut, 260

cutting plane, 260

data, see also dataset, 24

data abstraction, 21–40, 70–71

data dimension, see attribute

data types, 23

data–ink ratio, see information density

dataset, 24

dataset types, 24

degree of interest (DOI), 324

degree-of-interest models, see focus+context

dendrogram, 160

dense, 171–174, 176, 347

dependency, 57

dependent attribute, see attribute, value

depth cues, 118

derive, 50–53, 60–65

derived attributes, 51

design study, 73, 91

detail in context, see focus+context

detail-on-demand, 271

deterministic, 205

deuteranopia, 220

deviants, see outliers

dimension, see also attribute; attribute, key, 304

0D, 95

1D, 95

2D, 95

3D, 95

dimensional filtering, 261

dimensional ordering, see attribute ordering

dimensional stacking, see partitioning

dimensionality reduction (DR), 315–321

direct volume rendering, 183, 185–187, 197

direction, 238

discover, 47

discrete, 28

discrete colormap, see colormap, segmented

discretized colormap, see colormap, segmented

discriminability, 106

display, see view

distortion viewing, see focus+context

distortion-oriented presentations, see focus+context

dollying, 254

domain, 69

domain situation, 69–70, 77–78

dot chart, 155

dot plot, 155

downstream, 76

dual slider, 301

dynamic, 40

dynamic layers, 294, 362

dynamic queries, 300

dynamic streams, 31

edge, see link

effectiveness principle, 101

elastic presentation spaces, see also focus+context, 338

element, 299

elision, 324

embed, 323–338

enclosure, see containment

energy minimization, see force-directed placement enjoy, 48

evaluation, see validation explain, see present

explore, see also discover, 54

expressiveness principle, 100

external representations, 6, 18

facet, 265–297

feature flow, 193

feature tensor flow, 197

feature vector, 316

features, 55, 317

field, 27–29, 40

field study, 77, 79, 92

filter, 300–305

filtering, 300, 320, 324, 348, 351

find, see search

fisheye lens, see also focus+context

fisheye lens, 328, 335, 337

flat table, 25, 34

flow glyph, 191

flow maps, 85

focus, see also sinks, 323

focus+context, 323–338, 358

force-directed placement, 89, 204–208, 216

foreshortening, see perspective distortion

frame, 254

frequency, 238

generalized fisheye views, see also focus+context

generalized fisheye views, 337

generate, 47

geographic, 180

geometric flow, 191

geometric tensor flow, 196

geometric zooming, 255

geometry, 29–30, 180–182

geowigs, 313

gerrymandering, 313

glyph, 146, 280–281, 296, 347

graphic density, see information density

graphs, see networks

grid, 24, 29

grid geometry, 29

grid topology, 29

grouped bar chart, 281

grouping, see also partitioning, 279

guaranteed visibility, 331

gw-boxplot, 315

gw-mean, 315

hairball, 206

hatching, see stippling

heatmaps, 158, 176

height field, see information landscape

hierarchical aggregation, 311

hierarchical edge bundles, 292

hierarchical parallel coordinates, 311

hierarchical partitioning, see partitioning

highlighting, 239, 251

histograms, 306, 351

hops, 203

horizon graphs, 90

hover, 250

how, 17, 57–58

how much, see channel, magnitude

HSL, see color space, HSL

hue, 220, 223–224

human-centered design, see user-centered design