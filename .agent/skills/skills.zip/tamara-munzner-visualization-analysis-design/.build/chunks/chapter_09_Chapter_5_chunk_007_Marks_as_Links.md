# Marks as Links

![](images/5b223557ed77bc119805da4af06c50648eebdecafc03f5aa597fb3f8582fe79b.jpg)  
$\textcircled{ \div}$ Containment

![](images/264407726afd96d74ba4affc9b27faa062a2161d1cbc415c50ce1aad306bc266.jpg)  
$\textcircled{ \div}$ Connec tion   
Figure 5.5. Marks can represent individual items, or links between them.

content in our heads after it has passed through the perceptual and cognitive processing pathways of the human visual system.

The use of marks and channels in vis idiom design should be guided by the principles of expressiveness and effectiveness. These ideas can be combined to create a ranking of channels according to the type of data that is being visually encoded. If you have identified the most important attributes as part of developing your task and data abstraction, you can ensure that they are encoded with the highest ranked channels.