# Example: Multidimensional Transfer Functions

The Simian system [Kniss 02, Kniss et al. 05] uses a derived space and a set of interactive widgets for specifying regions within it to help the user construct multidimensional transfer functions. The horizontal axis of this space corresponds to the data value of the scalar function. The vertical axis corresponds to the magnitude of the gradient,1 the direction of fastest change, so that regions of high change can be distinguished from homogeneous regions. Figure 8.7(a) shows the information that can be considered part of a standard 1D transfer function: the histogram of the data values. The histogram shows both the linear scale values in black, and the log scale values in gray. In this view, only the basic three materials can be distinguished from each other: (A) air, (B) soft tissue, and (C) bone. Figure 8.7(b) shows that more information can be seen in the 2D joint histogram of the full derived space, where the vertial axis shows the gradient magnitude. This view is like a heatmap with very small area marks of one pixel each, where each cell shows a count of how many values occur within it using a grayscale colormap. In this view, boundaries between the basic surfaces also form distinguishable structures. Figure 8.7(c) presents a volume rendering of a head dataset using the resulting 2D transfer function, showing examples of the base materials and these three boundaries: (D) air–tissue, (E) tissue–bone, and (F) air–bone. A cutting plane has been positioned to show the internal structure of the head.

The histogram visual encoding idiom is covered in Section 13.4.1.

Cutting planes are covered in Section 11.6.2.

<table><tr><td>Idiom</td><td>Multidimensional Transfer Functions</td></tr><tr><td>What: Data</td><td>3D spatial field.</td></tr><tr><td>What: Derived</td><td>3D spatial field: gradient of original field.</td></tr><tr><td>What: Derived</td><td>Table: two key attributes, values binned from min to max for both data and derived data. One derived quantitative value attribute (item count per bin).</td></tr><tr><td>How: Encode</td><td>3D view: use given spatial field data, color and opacity from multidimensional transfer function. Joint histogram view: area marks in 2D matrix alignment, grayscale sequential colormap.</td></tr></table>

![](images/911fa6d657381ca69f52c03da3d557cc012996d869457ab105016b16796459df.jpg)  
(a)

![](images/3716d163c9fc73fe4a7f5b6d3f362379b1d6f80ac6fd40410155d79d29eae77c.jpg)  
(b)

![](images/7d13d0cd37f3c94f17f5fe622c1aad373c06531d77f132a4c1fce746e6eafec0.jpg)  
(c)   
Figure 8.6. Simian allows users to construct multidimensional transfer functions for direct volume rendering using a derived space. (a) The standard 1D histogram can show the three basic materials: (A) air, (B) soft tissue, and (C) bone. (b) The full 2D derived space allows material boundaries to be distinguished as well. (c) Volume rendering of head dataset using the resulting 2D transfer function, showing material boundaries of (D) air–tissue, (E) tissue– bone, and (F) air–bone. From [Kniss et al. 05, Figure 9.1].

![](images/f5e4ddda684bfad6016bccb13424c8c5c765fab251975702178444a9a51d5c25.jpg)  
Figure 8.7. The main types of critical points in a flow field: saddle, circulating sinks, circulating sources, noncirculating sinks, and noncirculating sources. From [Tricoche et al. 02, Figure 1].