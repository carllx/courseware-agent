# 3.5 Targets

Figure 3.6 shows four kinds of abstract targets. The actions discussed above refer to a target, meaning some aspect of the data that is of interest to the user. Targets are nouns, whereas actions are verbs. The idea of a target is explicit with search and query actions. It is more implicit with the use actions, but still relevant: for example, the thing that the user presents or discovers.

Three high-level targets are very broadly relevant, for all kinds of data: trends, outliers, and features. A trend is a high-level characterization of a pattern in the data.* Simple examples of trends include increases, decreases, peaks, troughs, and plateaus. Almost inevitably, some data doesn’t fit well with that backdrop; those elements are the outliers.* The exact definition of features is task dependent, meaning any particular structures of interest.

Attributes are specific properties that are visually encoded. The lowest-level target for an attribute is to find an individual value. Another frequent target of interest is to find the extremes: the minimum or maximum value across the range. A very common

Section 6.7 discusses the question of how and when to provide overviews.

* Indeed, a synonym for trend is simply pattern.   
* There are many other synonyms for outliers, including anomalies, novelties, deviants, and surprises.   
Attributes are discussed in detail in Chapter 2.

![](images/c06e5416889462171602e0bb05ee392465a2be63288edf6eb3de281bf961409a.jpg)