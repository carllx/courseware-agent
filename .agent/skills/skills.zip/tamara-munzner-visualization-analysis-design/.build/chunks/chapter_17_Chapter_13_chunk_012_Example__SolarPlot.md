# Example: SolarPlot

Figure 13.8 shows the example of SolarPlot, a radial histogram with an interactively controllable aggregation level [Chuah 98]. The user directly manipulates the size of the base circle that is the radial axis of the chart. This change of radius indirectly changes the number of available histogram bins, and thus the aggregation level. Like all histograms, the SolarPlot aggregation operator is count: the height of the bar represents the number of items in the set. The dataset shown is ticket sales over time, starting from the base of the circle and progressing counterclockwise to cover 30 years in total. The small circle in Figure 13.8(a) is heavily aggregated. It does show an increase in ticket sales over the years. The larger circle in Figure 13.8(b) is less aggregated, and seasonal patterns within each year can be distinguished.

<table><tr><td>Idiom</td><td>SolarPlot</td></tr><tr><td>What: Data</td><td>Table: one quantitative attribute.</td></tr><tr><td>What: Derived</td><td>Derived table: one derived ordered key attribute (bin), one derived quantitative value attribute (item</td></tr></table>

![](images/00381a64b2f36f469cf6baa282539002c81d516cf778938737fb1c63ebe9a4cc.jpg)  
(a)

![](images/c5303ecd0bcc1114024ac4b10609b2ab75b2e4b1e4cdc5cb57fc1848237c4f71.jpg)

Figure 13.8. The SolarPlot circular histogram idiom provides indirect control of aggregation level by changing the circle size. (a) The small circle shows the increase in ticket sales over time. (b) Enlarging the circle shows seasonal patterns in addition to the gradual increase. From [Chuah 98, Figures 1 and 2].

<table><tr><td></td><td>count per bin). Number of bins interactively controlled.</td></tr><tr><td>How: Encode</td><td>Radial layout, line marks. Line length: express derived value attribute; angle: key attribute.</td></tr><tr><td>How: Reduce</td><td>Item aggregation.</td></tr><tr><td>Scale</td><td>Original items: unlimited. Derived bins: proportional to screen space allocated.</td></tr></table>

The general design choice of hierarchical aggregation is to construct the derived data of a hierarchical clustering of items in the original dataset and allow the user to interactively control the level of detail to show based on this hierarchy. There are many specific examples of idioms that use variants of this design choice. The cluster–calendar system in Figure 6.7 is one example of hierarchical aggregation. Another is hierarchical parallel coordinates.