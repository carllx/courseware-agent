# Data Types

Items

Attributes

Links

Positions

Grids

* Synonyms for attribute are variable and data dimension, or just dimension for short. Since dimension has many meanings, in this book it is reserved for the visual channels of spatial position as discussed in Section 6.3.

in a network. For example, items may be people, stocks, coffee shops, genes, or cities. A link is a relationship between items, typically within a network. A grid specifies the strategy for sampling continuous data in terms of both geometric and topological relationships between its cells. A position is spatial data, providing a location in two-dimensional (2D) or three-dimensional (3D) space. For example, a position might be a latitude–longitude pair describing a location on the Earth’s surface or three numbers specifying a location within the region of space measured by a medical scanner.