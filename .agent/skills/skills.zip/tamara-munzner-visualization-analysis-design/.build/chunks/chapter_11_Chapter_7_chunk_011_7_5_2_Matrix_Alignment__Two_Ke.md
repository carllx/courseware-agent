# 7.5.2 Matrix Alignment: Two Keys

Datasets with two keys are often arranged in a two-dimensional matrix alignment where one key is distributed along the rows and

![](images/8b3ede83258035c6a37a39da6ef08616019b162d0517cd6ad40db35b985db183.jpg)  
(a)

![](images/647afda8cdc8b5264c43479a074033b50dc8dd7349ac3e22fd2fbe4b68f40710.jpg)  
(b)   
Figure 7.10. Sunspot cycles. The multiscale banking to $4 5 ^ { \circ }$ idiom exploits our orientation resolution accuracy at the diagonal. (a) An aspect ratio close to 4 emphasizes low-frequency structure. (b) An aspect ratio close to 22 shows higherfrequency structure: cycle onset is mostly steeper than the decay. From [Heer and Agrawala 06, Figure 5].

the other along the columns, so a rectangular cell in the matrix is the region for showing the item values.