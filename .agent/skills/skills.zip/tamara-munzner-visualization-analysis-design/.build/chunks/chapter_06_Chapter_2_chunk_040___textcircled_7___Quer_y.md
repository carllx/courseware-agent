# $\textcircled{7}$ Quer y

Identify

![](images/8885e474aec78869dc3fdfe70da71693032de288ef3e0a1c268a6ab076f043f9.jpg)

Compare

![](images/0ee301384150c8b16a79eb0f8af22f7838946f65836615eafef72e23c621a75a.jpg)

Summarize

![](images/e2e1e9cfb126505daead8388d88caff12fe64ecefd713be9ff6fb95660a1607f.jpg)