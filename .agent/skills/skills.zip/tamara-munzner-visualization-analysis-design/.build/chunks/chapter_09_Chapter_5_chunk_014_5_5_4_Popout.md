# 5.5.4 Popout

Many visual channels provide visual popout, where a distinct item stands out from many others immediately.* Figure 5.11 shows two examples of popout: spotting a red object from a sea of blue ones, or spotting one circle from a sea of squares. The great value of popout is that the time it takes us to spot the different object does not depend on the number of distractor objects. Our low-level visual system does massively parallel processing on these visual channels, without the need for the viewer to consciously directly attention to items one by one. The time it takes for the red circle to pop out of the sea of blue ones is roughly equal when there are 15 blue ones as in Figure 5.11(a) or 50 as in Figure 5.11(b).

Popout is not an all-or-nothing phenomenon. It depends on both the channel itself and how different the target item is from its surroundings. While the red circle pops out from the seas of 15 and 50 red squares in Figures 5.11(c) and 5.11(d) at roughly

* Visual popout is often called preattentive processing or tunable detection.

![](images/8907137bc803689791357c5f88b7c421f36f65bfb77d81081a8aecd0f0833107.jpg)  
(a)

![](images/aa089bd51b56121c3e01292360f633b4e3fc690305d0f01d0c3ab0ff88c9d98d.jpg)  
(b)

![](images/e85d5fd3909ebddee46e591384178133e57ea3deecc25a1b6a31f70eb6c729d9.jpg)  
(c)

![](images/755aee6cbb4655414c2812bae7db6bcdb3e41ad7bb47586e10d247cb2a340619.jpg)  
(d)

![](images/37fca9242bbec853684dc7dc65c6e955d0755502c3de539ffb97dbb8f377ad6d.jpg)  
(e)

![](images/404e062e1b81b67c30e699c21eff023d8c0143c45244e66b543cb6c4f00e32c1.jpg)  
(f)   
Figure 5.11. Visual popout. (a) The red circle pops out from a small set of blue circles. (b) The red circle pops out from a large set of blue circles just as quickly. (c) The red circle also pops out from a small set of square shapes, although a bit slower than with color. (d) The red circle also pops out of a large set of red squares. (e) The red circle does not take long to find from a small set of mixed shapes and colors. (f) The red circle does not pop out from a large set of red squares and blue circles, and it can only be found by searching one by one through all the objects. After http://www.csc.ncsu.edu/faculty/healey/PP by Christopher G. Healey.

![](images/be41c98ab22c653f36feaa346f144d98cc06ca6dce5385a4fe0f5990c979ad93.jpg)  
(a)

![](images/7122811b101b8111e6237cf3667abc98c663b5f5c5231615d58acdbf5e71f6a0.jpg)  
(b)

![](images/88a8e2cbe01bb79b1cfa6d4a1f3c7a888d84bfb15f1f4ffc9c294f52274e0977.jpg)

![](images/cb5a040d5ca29c648746a1df03a45a4d8313096381d63f35b0247113dcf985cd.jpg)  
(d)

![](images/aaf194f001b94dab7eec49840cd05a4ca5821a8325294c0772ac1b8c5a354ba0.jpg)  
(e)

![](images/c90741fb775cd0b1a8e92f3cd41f3e8644fd39dbab16cead0def4c33c02e549e.jpg)

Figure 5.12. Many channels support visual popout, including (a) tilt, (b) size, (c) shape, (d) proximity, and (e) shadow direction. (f) However, parallel line pairs do not pop out from a sea of slightly tilted distractor object pairs and can only be detected through serial search. After http://www.csc.ncsu.edu/faculty/healey/PP by Christopher G. Healey.

the same time, this popout effect is slower than with the color difference versions in Figures 5.11(a) and 5.11(b). The difference between red and blue on the color hue channel is larger than the difference in shape between filled-in circles and filled-in squares.

Although many different visual channels provide popout on their own, they cannot simply be combined. A red circle does not pop out automatically from a sea of objects that can be red or blue and circles or squares: the speed of finding the red circle is much faster in Figures 5.11(e) with few distracting objects than in Figure 5.11(f) with many distractors. The red circle can only be detected with serial search: checking each item, one by one. The amount of time it takes to find the target depends linearly on the number of distractor objects.

Most pairs of channels do not support popout, but a few pairs do: one example is space and color, and another is motion and shape. Popout is definitely not possible with three or more channels. As a general rule, vis designers should only count on using popout for a single channel at a time.

Popout occurs for many channels, not just color hue and shape. Figures 5.12(a) through 5.12(e) show several examples: tilt, size, shape, proximity, and even shadow direction. Many other channels support popout, including several different kinds of motion such as flicker, motion direction, and motion velocity. All of the major channels commonly used in visual encoding that are shown in Figure 5.6 do support popout individually, although not in combination with each other. However, a small number of potential channels do not support popout. Figure 5.12(f) shows that parallelism is not preattentively detected; the exactly parallel pair of lines does not pop out from the slightly angled pairs but requires serial search to detect.