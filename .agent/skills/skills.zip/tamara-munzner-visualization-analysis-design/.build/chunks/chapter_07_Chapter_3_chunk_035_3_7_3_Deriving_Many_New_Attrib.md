# 3.7.3 Deriving Many New Attributes

Data transformations can shed light into spatial data as well. In an example from computational fluid dynamics, linked derived spaces are used for feature detection [Henze 98]. The vis system shown in Figure 3.12 allows the user to quickly create plots of any two original or derived variables from the palette of variables shown in the upper left derived fields pane. The views are linked together with color highlighting. The power of this idiom lies in seeing where regions that are contiguous in one view fall in the other views.

The original dataset is a time-varying spatial field with measurements along a curvilinear mesh fitted to an airfoil. The plot in the physical space pane on the upper right of Figure 3.12 shows the data in this physical space, using the two spatial field variables. Undisturbed airflow enters the physical space from the left, and the back tip of the airfoil is on the right. Two important regions in back of the airfoil are distinguished with color: a red recirculation region and a yellow wake region. While these regions are not easy to distinguish in this physical view, they can be understood and selected more easily by interaction with the four other derived views. For example, in the derived space of vorticity vs enthalpy in the upper middle of Figure 3.12, the recirculation zone is distinguishable as a coherent spatial structure at the top, with the yellow wake also distinguishable beneath it. As the white box shows, the

Multiple views are discussed further in Chapter 12.

![](images/89217d59f7c7d088fb838a0c22a0a8790c9cd172cde09f9c3776948c5068f688.jpg)

![](images/154516125ef2537f03217097e8b7afe8a3f55359c3b90f10580ce679918f44eb.jpg)

![](images/2ca169c22e28bb43a5337af42531ccc969c8ad5849b956b4e020a7efe48d7b5a.jpg)

![](images/bc87c31dd59d99ecaca748b1e021947c78357dfcc606b4efbf576c8e51ddf985.jpg)

![](images/2a6816fbb98c9343547690afa4a7a20297f23c5d0f405f698427debc7e1540c9.jpg)

![](images/ce375f12b8d5f3a18390cfa03cb39f58a09d24bf9c7715df349a92c49430ebd1.jpg)  
Figure 3.12. Computational fluid dynamics vis showing the list of many derived attributes (top left), one view of the original spatial field (top right), and four other views showing pairs of selected derived attributes. The multiple juxtaposed views are coordinated with shared colored highlights. From [Henze 98, Figure 5].

recirculation zone can easily be selected in this view. The pressure vs temperature pane in the bottom middle of Figure 3.12 shows another derived space made by plotting the pressure versus the temperature. In this view, the red recirculation zone and the yellow wake appear where both the pressure and temperature variables are high, in the upper right. Without getting into the exact technical meaning of the derived variables as used in fluid dynamics (vorticity, entropy, enthalpy, and so on), the point of this example is that many structures of interest in fluid dynamics can be seen more easily from layouts in the derived spaces.

![](images/c71de7b98f515daae1034e11ea6d70e19dd3eb71520fc85a2be8d39e013c498c.jpg)  
Task 1

Spatial field

![](images/bfff1accb52ca5c7ce12b3b56a7fd8865a05725ee6e8d58f3dac9b5602fde5e2.jpg)

Many quantitative attributes

![](images/207aac39c4b0a21cb09ab9d23d039ce8a2862f5df069e2955bbfe00d19e67fbc.jpg)