# Data and Dataset Types

Tables

I tems

Attributes

Net works & Trees

I tems (nodes)

Links

Attributes

Fields

Grids

Positions

Attributes

Geometr y

I tems

Positions

Clusters, Sets, Lists

I tems

![](images/ceae0b06865fee7611eaf4dfa1da22cc7cb3e258fd365416756063bcc974d679.jpg)