# Network Data

Topology

![](images/c8b9f59f0ea96cdf7303941ff29b0011d775e019d3e9ca935bb6425342ff802b.jpg)

![](images/0cd44456df73147f52c529eb0fed3d246940dd875890f14a309752ea8f2d5d80.jpg)

Paths

![](images/2ced12035c61e582051c206fe80e3f5f9e7d85df477f1d228dedfa5ee896432e.jpg)