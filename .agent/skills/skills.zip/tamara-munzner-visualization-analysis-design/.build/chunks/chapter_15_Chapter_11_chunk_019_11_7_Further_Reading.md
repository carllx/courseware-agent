# 11.7 Further Reading

Change An early paper argues for adding interaction support to previously static visual encoding idioms as a good starting point for thinking about views that change [Dix and Ellis 98].

* The term dimensional filtering, common when working with abstract data, is essentially a synonym for orthographic projection, more commonly used when working with spatial data.

Animated Transitions A taxonomy of animated transition types includes design guidelines for constructing transitions, and an empirical study showing strong evidence that properly designed transitions can improve graphical perception of changes [Heer and Robertson 07].

Select The entertainingly named Selection: 524,288 Ways to Say “This Is Interesting” contains nicely reasoned arguments for narrowing selection operations across linked views to a small set of combinations [Wills 96].

Semantic Zooming The $\mathrm { P a d } { + + }$ system was an early exploration into semanic zooming [Bederson and Hollan 94]; LiveRAC is a more recent system using that idiom [McLachlan et al. 08].

Constrained Navigation Early work evangelized the idea of constrained navigation in 3D [Mackinlay et al. 90]; later work provides a framework for calculating smooth and efficient 2D panning and zooming trajectories [van Wijk and Nuij 03].

![](images/02ac39474a1451ce30a56bc250d835989794e8542544560541d033e537a0d20e.jpg)

#

$\circledast$ Jux tapose and Coordinate Multiple Side-by-Side Views

→Share Encoding: Same/Different   
Linked Highlighting

![](images/e2a1dd7f1719f665f343af0c621d2c00f3adc72213a6a401bd4298cabf82edf7.jpg)

![](images/ffad0214d6c3d6b55e9e26e97cc0b36b71232b1525dc1d68886c8d59daae3f9c.jpg)

Share Data: All/Subset/None

![](images/983ac9fe26d433e528a07822127c1f63d28db971c9e83a38e8d44fa10a653227.jpg)

![](images/37d27495e1539ee1cebf3c770a248836b322b03e2e6bfa91a9286dab50d34cfb.jpg)

![](images/867b28e276de33f230feadc4707462852f424e641f1c166d244d858b83d52576.jpg)

Share Navigation

![](images/33e483f7deb7acd323f2e80c3babe8ad46cc03aec662311d7bd95a1645655ae5.jpg)

![](images/cb55446989a9b27d26bb0a04a09a22b4076236b6cdd03dd2e8f3b5f6358fa88c.jpg)

![](images/9903d10fa3717f96e96eef8f5d89329acb6313697c3f5c6e53020a4c45fbea73.jpg)

$\circled{  }$ Par tition into Side-by-Side Views

![](images/c64d157c342c6f395f3efb8c6d223ea639d5d7da16f475cf9bffc02b6cb4e778.jpg)

![](images/d905b82462030698f27ff91eb1a6bc5450ef3f436f7d4c1e4c287a80aacf1b0b.jpg)

$\circledcirc$ Superimpose Layers

![](images/d5702f18594f3bfdf8db9c463021d75b985c5b9a5af0af114faa8b96c9abf9f5.jpg)

![](images/f037bedf423b5684a57eca13596bad0cc0b41f4f50509462c667b3bc59f0abfe.jpg)

![](images/ceed01b4da01a0e7a71d5c14dc2b76678c6b483f90ce8376a10d3c2bf55b817b.jpg)  
Figure 12.1. Design choices of how to facet information between multiple views.