# 13.4.1 Item Aggregation

The most straightforward use of item aggregation is within static visual encoding idioms; its full power and flexibility can be harnessed by interactive idioms where the view dynamically changes.

* A synonym for attribute ordering is dimensional ordering.

* A synonym for similarity measure is similarity metric. Although I am combining the ideas of measure and metric here for the purposes of this discussion, in many specialized contexts such as mathematics and business analysis they are carefully distinguished with different definitions.

‣ An example of a complex combination of both aggregation and filtering is cartographic generalization, discussed in Section 8.3.1.