# 3.4.1 Analyze

At the highest level, the framework distinguishes between two possible goals of people who want to analyze data using a vis tool: users might want only to consume existing information or also to actively produce new information.

The most common use case for vis is for the user to consume information that has already been generated as data stored in a

![](images/8338b3ad2ca06daea679c7d9deb0bee57a3b7eb45d2e7cd3b49bad11d916f37d.jpg)