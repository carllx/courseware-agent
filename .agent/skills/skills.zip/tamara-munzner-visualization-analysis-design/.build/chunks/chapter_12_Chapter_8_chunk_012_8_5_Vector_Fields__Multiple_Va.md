# 8.5 Vector Fields: Multiple Values

Vector field datasets are often associated with the application domain of computational fluid dynamics (CFD), as the outcome of flow simulations or measurements. Flow vis in particular deals with a specific kind of vector field, a velocity field, that contains information about both direction and magnitude at each cell. The three common cases are purely 2D spatial fields, purely 3D spatial fields, and the intermediate case of flow on a 2D surface embedded within 3D space. Time-varying flow datasets are called unsteady, as opposed to steady flows where the behavior does not change over time.

One of the features of interest in flows are the critical points, the points in a flow field where the velocity vanishes. They are classified by the behavior of the flow in their neighborhoods: the three main types are attracting sources, repelling sinks, and saddle points that attract from one direction and repel from another.2 Also, sources and sinks may or may not have circulation around them.* Figure 8.7 shows these five types of critical points.

There are four major families of vector field spatial visual encoding idioms. The flow glyph idioms show local information at each cell. There are two major methods based on the derived data of tracing particle trajectories, either the geometric flow approach using a sparse set of seed points or the texture flow approach with a dense set of seeds. The feature flow approach uses global computation across the entire field to explicitly detect features, and these derived features are usually visually encoded with glyphs or geometry. Finally, a vector field can be reduced to a scalar field,

* In flow vis, a source or sink with no circulation around it is called a node, and one with circulation is called a focus. I avoid these overloaded terms; in this book, I reserve node and link for network data and focus+context for the family of idioms that embed such information together in a single view.

![](images/bb33a6e18361125cd65dbb471a33606fbfd6bce28b79c40db73145e67bd38fcb.jpg)  
(a)

![](images/74ebcba27f0af62e10e692fe4bd00a22525779dfee057f74c64c0896d42bceca.jpg)  
(b)

![](images/3dbe7101106dd562a278f8a2aea507ca4b88b17415f6ffdb6ccd3ae2d7282ce8.jpg)  
(c)

![](images/7d56e899975f5b17587174eabc1329cb3bbc96118a4a5ffd9d90ac6e4f7238ce.jpg)

![](images/5205c13ec05e141687ef1a4d6d1146ff15c817a509461116c6cedc552ab5056b.jpg)

![](images/fc6bd61d22c164a8cede9eef78b9414fa3e8df7303bd7f6db78339b895c1b575.jpg)  
(f)   
Figure 8.8. An empirical study compared human response to six different 2D flow vis idioms. (a) arrow glyphs on a regular grid. (b) arrow glyphs on a jittered grid. (c) triangular wedge glyphs inspired by oil painting strokes. (d) dense texturebased Line Integral Convolution (LIC). (e) curved arrow glyphs with image-guided streamline seeding. (f) curved arrow glyphs with regular grid streamline seeding. From [Laidlaw et al. 05, Figure 1].

allowing any of the scalar field idioms covered in the previous section to be used, such as direct volume rendering or isocontouring.

Laidlaw et al. conducted an empirical study comparing six visual encoding idioms for 2D vector fields [Laidlaw et al. 05]. Figures 8.8(a), 8.8(b), and 8.8(c) show local glyph idioms, Figure 8.8(d) shows a dense texture idiom, and Figures 8.8(e) and 8.8(f) show geometric idioms. The three tasks considered were finding all of the critical points and identifying their types; identifying what type of critical point is at a specific location; and predicting where a particle starting at a specified point will end up being transported.* While none of the idioms outperformed all of the others for all tasks, the two local glyph idioms using arrows fared worst.

* The technical term for the transport of a particle within a fluid is advection.