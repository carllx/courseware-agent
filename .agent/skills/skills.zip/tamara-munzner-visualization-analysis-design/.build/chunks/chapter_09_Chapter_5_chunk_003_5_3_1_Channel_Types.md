# 5.3.1 Channel Types

The human perceptual system has two fundamentally different kinds of sensory modalities. The identity channels tell us information about what something is or where it is. In contrast, the magnitude channels tell us how much of something there is.*

For instance, we can tell what shape we see: a circle, a triangle, or a cross. It does not make much sense to ask magnitude questions for shape. Other what visual channels are shape, the color channel of hue, and motion pattern. We can tell what spatial region marks are within, and where the region is.

In contrast, we can ask about magnitudes with line length: how much longer is this line than that line? And identity is not a productive question, since both objects are lines. Similarly, we can ask luminance questions about how much darker one mark is than another, or angle questions about how much space is between a pair of lines, or size questions about how much bigger one mark is than another. Many channels give us magnitude information, including the size channels of length, area, and volume; two of the three color channels, namely, luminance and saturation; and tilt.