# Example: Animated Transitions

One of the best-justified uses of animation is the idiom of animated transition, where a series of frames is generated to smoothly transition from one state to another. Animated transitions are thus an alternative to a jump cut, where the display simply changes abruptly from one state to the next.* This idiom is often used for navigation, in which case the two states are different camera viewpoints. More generally, they can be constructed to bridge between the start and end state of any kind of change, including reordering items, filtering by adding or removing items from the view, changing the visual encoding, or updating item values as they change over time.

The benefit of animated transitions is that they help users maintain a sense of context between the two states by explicitly showing how an item in the first state moves to its new position in the second state, rather than forcing users to do item tracking on their own using internal cognitive and memory resources. These transitions are most useful when the amount of change is limited, because people cannot track everything that occurs

![](images/389b64855e96ccd1c6c1e0ee99ec9735725cd15dcde5084b812540d9dd22f0bc.jpg)

![](images/19af32fdb3c4fd72e1e1877c5caff55417a4aa25797f1728942b06a70773506c.jpg)

![](images/8c9518eeb62178ca9f715071e838470cdfa3ccb71e913ece75708dbe6045d2f5.jpg)

![](images/6308896a2cc3ea94b008f021a81c93581673b6ae83f9ea0d3a430e68b809f6f1.jpg)

![](images/e837c5ed57929beeb8aa4893f04ea43532db7edfe1e68b4bee404be9a873d529.jpg)  
Figure 11.5. Frames from an animated transition showing zoom between levels in a compound network arranged as an adjacency matrix. From [van Ham 03, Figure 4].

if many items change in different ways all over the frame. They work well when either a small number of objects change while the rest stay the same, or when groups of objects move together in similar ways. Transitions can also be broken down into a small number of stages. An empirical study showed that carefully designed animated transitions do indeed support better graphical perception of change [Heer and Robertson 07].

Figure 11.5 shows an example of five frames from an animated transition of a network shown as an adjacency matrix. The data type shown is a compound network, where there is a cluster hierarchy associated with the base network. The transition shows a change from one level of hierarchical aggregation to the next, providing more detail. Accordingly, the scope of what is shown narrows down to show only a subset of what is visible in the first frame. The middle block gradually stretches out to fill all of the available space, and additional structure appears within it; the other blocks gradually squish down to nothing, with their structure gradually becoming more aggregated as the amount of available screen space decreases.

Visually encoding a network as an adjacency matrix is covered in Section 9.3.   
Compound networks are discussed in Section 9.5.   
Hierarchical aggregation is covered in Section 13.4.1.

<table><tr><td>Idiom</td><td>Animated Transitions</td></tr><tr><td>What: Data</td><td>Compound network.</td></tr><tr><td>How: Manipulate</td><td>Change with animated transition. Navigate between aggregation levels.</td></tr></table>