# Using the VitalSource® ebook

Access to the VitalBookTM ebook accompanying this book is via VitalSource® Bookshelf – an ebook reader which allows you to make and share notes and highlights on your ebooks and search across all of the ebooks that you hold on your VitalSource Bookshelf. You can access the ebook online or offline on your smartphone, tablet or PC/Mac and your notes and highlights will automatically stay in sync no matter where you make them.

1. Create a VitalSource Bookshelf account at https://online.vitalsource.com/user/new or log into your existing account if you already have one.   
2. Redeem the code provided in the panel below to get online access to the ebook. Log in to Bookshelf and click the Account menu at the top right of the screen. Select Redeem and enter the redemption code shown on the scratch-off panel below in the Code To Redeem box. Press Redeem. Once the code has been redeemed your ebook will download and appear in your librar y.