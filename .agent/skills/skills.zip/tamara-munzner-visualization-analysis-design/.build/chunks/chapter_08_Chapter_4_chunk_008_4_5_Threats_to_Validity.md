# 4.5 Threats to Validity

Section 1.12 presented many questions to consider when validating a vis design.

Validating the effectiveness of a vis design is difficult because there are so many possible questions on the table. Considering the validity of your decisions at each level of the nested model separately

![](images/012079474f18ae9f0a3cbf9e4dc7b536558fbe8125104dd98d247c3b180dfef9.jpg)  
Figure 4.4. The four nested levels of vis design have different threats to validity at each level.

can help you find your way through this thicket of questions about validating your decisions, in the same way that the levels also constrain the decision-making process itself.

Each of the four levels has a different set of threats to validity: that is, different fundamental reasons why you might have made the wrong choices.* Figure 4.4 summarizes the four classes of threats, where they means the target users and you means the vis designer:

. Wrong problem: You misunderstood their needs.   
. Wrong abstraction: You’re showing them the wrong thing.   
. Wrong idiom: The way you show it doesn’t work.   
. Wrong algorithm: Your code is too slow.