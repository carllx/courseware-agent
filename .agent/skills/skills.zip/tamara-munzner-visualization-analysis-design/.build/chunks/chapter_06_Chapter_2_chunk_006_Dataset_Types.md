# Dataset Types

![](images/9ac995dea3d8dfced8be0f5e5b264b0ffbbe3370801a3043b3669c5383d40589.jpg)  
Tables

![](images/911c7a3b1644585d4f407ca5b13f861312a6bd0cf10bdcec4eb302a5e56fe513.jpg)  
Net works

![](images/706cea01d11eb9490ef18d2d682ad47fb6cde34b1e4992e88d5b807244bc77c8.jpg)  
Fields (Continuous)

![](images/ab55219725b195262880b49049e5a23219e852b82b6578633a4ccd492b4a4a2e.jpg)  
Geometr y (Spatial)

![](images/f6465d6c40ec588b7f1da29fb59a62550efb740b55ebcde9120609217968444b.jpg)  
Multidimensional Table

![](images/b6cedccd478d9866ddede7d69aa0f9569face981469b3f47919ba098c9ad21b3.jpg)  
Trees   
Figure 2.4. The detailed structure of the four basic dataset types.