# Attribute Types

![](images/a316b9dce44e21cb8852c4e8dbe9c51a219c011ff93155071cd0e1b20d55462b.jpg)

Categorical

![](images/1f92e2b25c8c8576edab66d249c101c6851bc75f05033b18fa70f14d142c86c3.jpg)

![](images/5496c9cdc27a1f06a2fd684c72e352190c288d8a969c7478e4516d07d9197044.jpg)

Ordered

Ordinal

![](images/07818af464cdd9bbfb0061d0e0abf57618784181795cef07a3f336e6e815522a.jpg)

Quantitative

![](images/df190ff4a72c4dc712d72454d0a723d43b95397a2e905a3bcb7f62fdcbcd4f6b.jpg)

![](images/d72a8f1133056fa3c8be9ba3a431210bac281ffce7f66dd9bf001c0b11e101c3.jpg)