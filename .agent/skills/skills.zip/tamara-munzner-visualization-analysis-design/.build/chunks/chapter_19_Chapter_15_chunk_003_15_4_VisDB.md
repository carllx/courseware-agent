# 15.4 VisDB

The VisDB system for database vis [Keim and Kriegel 94] treats an entire database as a very large table of data. The system shows that table with respect to a specific query that matches some subset of the items in it. VisDB computes a set of derived attributes that measure the relevance of the query with respect to the original attributes and items, as shown in Figure 15.5(a). Each item is given a relevance score for the query for each original attribute. An overall relevance score is computed that combines these individual scores, adding an additional derived attribute column to the original table.

VisDB supports two different layout idioms that are dense, spacefilling, and use square color-coded area marks. Figure 15.5 shows schematic views of the layouts, and Figure 15.6 shows the corresponding screenshots.

The spatial ordering of regions within VisDB views is not a standard aligned rectilinear or radial layout; it follows a spiral pattern emanating from the center, as shown in Figure 15.7(a). The sequential colormap, shown in Figure 15.7(b), uses multiple hues ordered with monotonically increasing luminance to support both categorical and ordered perception of the encoded data. At the bottom is dark red, the mid-range has purple and blue, it continues with cyan and then even brighter green, and there is a very bright yellow at the high end to emphasize the top of the range.

One of the two layouts partitions the dataset by attribute into small multiple views shown side by side, with one view for each attribute. Figure 15.5(a) illustrates the idiom schematically, and Figure 15.6(a) shows an example with a dataset of 1000 items. The items are placed in the same order across all views but colored according to relevance score for that view’s attribute. They are ordered by the derived overall relevance attribute, which is also the coloring attribute in the upper left view; spatial position and color provide redundant information in this view. In the other views with coloring by each other attribute, there are different visual patterns of color. The user can inspect the patterns within the individual views to carry out the abstract task of characterizing distributions and finding groups of similar values within individual attributes and per-attribute outlier detection. Comparing between the patterns in different views corresponds to the abstract task of looking for correlations between attributes.

![](images/710b761fafc3e860263c295693745650edb56a6324153e5cb54fa175f8147d67.jpg)  
(a)

![](images/8d946a8b18bbbde28b08ab418e724eca7f48ab79784f76580d5f17d48dbe268d.jpg)  
(b)   
Figure 15.5. VisDB layouts schematically, for a dataset with five attributes. (a) Each attribute is shown in a separate small-multiple view. (b) In an alternate VisDB layout, each item is shown with a glyph with per-attribute sections in a single combined view. From [Keim and Kriegel 94, Figures 2 and 4].

The second layout uses a single view where the space has been partitioned into one region for each item, containing a glyph that shows all of the attributes for that item. Figure 15.5(b) shows the schematic diagram, and Figure 15.6(b) shows a screenshot. This item-based partition supports the abstract task of comparison across items and finding groups of similar items, rather than comparison across attributes.

![](images/40364c791a9fbd08b4487f9620c9d216ecde04a4d24fda35f0c4e2551c24b0a9.jpg)  
(a)

![](images/cd9157009a3901ed9782f3c9be5ea2040d7788d0c10e46513de2e2d5c35a1292.jpg)  
(b)   
Figure 15.6. VisDB screenshots with a dataset of eight attributes and 1000 items. (a) Attribute-based grouping with one small-multiple view for each attribute. (b) Item-based grouping has a single combined view with multiattribute glyph. From [Keim and Kriegel 94, Figure 6].

Both of these layouts use filtering for data reduction. When the number of items is greater than the available room for the view, items are filtered according to the relevance values. The total table size handled by the system thus can be up to several million, even though only one million items can be shown at once in a single screen of one million pixels.

The small-multiples layout is effective for up to 10–12 attributes, where each per-attribute view shows around 100,000 items, and one million items are shown across all the views. In contrast, the layout idiom using a single large glyph-based view only can handle up to around 100,000 visible items, an order of magnitude fewer than the other idiom. The elements within the glyph need to be boxes larger than a single pixel in order to be salient, and glyphs need borders around them in order to be distinguished from neighboring ones.

VisDB is an early example of a very information-dense design that tests the upper limits of useful information density. It is also a very clear example of how different strategies for partitioning space can be used to support different tasks.

![](images/b4a44d7b2a33cc1226f6d63aa3ba43193cd7188ddc8e5594b53954ca54b6bfe2.jpg)  
(a)

![](images/6b73e3c666b5d74743a006c12678c609d5aa3c25b71e3277e8f6c5c67c7459e1.jpg)  
(b)   
Figure 15.7. VisDB layout orientation and colors. (a) Layouts are are ordered internally in a spiral emanating from the center. (b) The VisDB sequential colormap uses multiple hues with monotonically increasing luminance. From [Keim and Kriegel 94, Figures 2 and 3].

<table><tr><td>System</td><td>VisDB</td></tr><tr><td>What: Data</td><td>Table (database) with k attributes; query return-ing table subset (database query).</td></tr><tr><td>What: Derived</td><td>k + 1 quantitative attributes per original item: query relevance for the k original attributes plus overall relevance.</td></tr><tr><td>Why: Tasks</td><td>Characterize distribution within attribute, find groups of similar values within attribute, find outliers within attribute, find correlation be-tween attributes, find similar items.</td></tr><tr><td>How: Encode</td><td>Dense, space-filling; area marks in spiral lay-out; colormap: categorical hues and ordered luminance.</td></tr><tr><td>How: Facet</td><td>Layout 1: partition by attribute into per-attribute views, small multiples. Layout 2: partition by items into per-item glyphs.</td></tr><tr><td>How: Reduce</td><td>Filtering</td></tr><tr><td>Scale</td><td>Attributes: one dozen. Total items: several mil- lion. Visible items (using multiple views, in to-tal): one million. Visible items (using glyphs): 100,000</td></tr></table>