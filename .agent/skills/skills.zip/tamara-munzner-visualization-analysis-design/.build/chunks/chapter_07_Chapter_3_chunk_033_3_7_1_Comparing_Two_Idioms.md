# 3.7.1 Comparing Two Idioms

The what–why–how analysis framework is useful for comparative analysis, for example, to examine two different vis tools that have different answers for the question of how the idiom is designed when used for exactly the same context of why and what at the abstraction level.

SpaceTree [Plaisant et al. 02], shown in Figure 3.8(a), and Tree-Juxtaposer [Munzner et al. 03], shown in Figure 3.8(b), are tree vis

![](images/96c857db4516a4f05d74b218e5023a20fcc9451532eda261e1fb9db7fcaacc46.jpg)  
(a)

![](images/532f3951d1f74c5414fdf9b1fd8dfc0ebb37374303cb56157b01b259e265c776.jpg)  
(b)   
Figure 3.8. Comparing two idioms. (a) SpaceTree [Plaisant et al. 02]. (b) TreeJuxtaposer. From http://www.cs.umd. edu/hcil/spacetree and [Munzner et al. 03, Figure 1].

What?

$\textcircled{ \div}$ Tree

![](images/12ea4cebea11af9d34acc1e874adc09fe97cafa21f701e7c75adec5ce155feef.jpg)

Why?

$\circledast$ Ac tions

Present

Locate

Identify

![](images/b944bb2d5e53a98bc5d7ae6f852768e029b8c885e7fc104546bc1f7b7e8ac640.jpg)

![](images/b8b1c61c94883c6dfbe1fc5ab02a29281a618f4196e4d2a9277e43b676045dab.jpg)

![](images/5ba8d216d69dff604f601c282917846c3038cc9adfe36220be20f6b8eb3cbe31.jpg)

How?

$\textcircled{ \div}$ SpaceTree

Encode

Navigate

![](images/99cdc52a1b4283376c8cd12d83ed39aa4e75f624119ad481b074121c8d4f1bbc.jpg)

Selec t

![](images/c5a12c2cb0a975636082ed0837398d031d3788db40cc6d06310ace99796dd890.jpg)

Filter

![](images/ec0de4bb026529fb1f71f569711aed9d2c18e3c853a4d91faefd6b70ea157b88.jpg)

Aggregate

![](images/46f1332029c7d05391152989df5fb503a774aa362e816c50d7879e1df68addf6.jpg)

$\circled{ \div}$ Targets

Path bet ween t wo nodes

![](images/0f7d197510f0fc8808481d126df046064561397726e2c88fbe0e892a1fec7225.jpg)

$\circled{ \div}$ TreeJux taposer

Encode

Navigate

Selec t

Arrange

![](images/3558cb4c8ce6b6c645cf6ca5d03484cc33dbb17580a8967d085186b0f8bf716f.jpg)

![](images/7cae1151640d575c60d4fb85c9dcd4e108319fd7f399ea741324d55cf12a5670.jpg)

![](images/5438da97d074666fb2a93eff70854e670a0c828e688058c48681d1466a7f1d4e.jpg)

![](images/3a8642c83402d19ec68ad94abaf7658071dc423908d0fe897c95b2470e83128d.jpg)  
Figure 3.9. Analyzing what–why–how comparatively for the SpaceTree and TreeJuxtaposer idioms.

tools that use somewhat different idioms. What these tools take as input data is the same: a large tree composed of nodes and links. Why these tools are being used is for the same goal in this scenario: to present a path traced between two nodes of interest to a colleague. In more detail, both tools can be used to locate paths between nodes and identify them.

Some aspects of idioms are the same: both systems allow the user to navigate and to select a path, with the result that it’s encoded differently from the nonselected paths through highlighting. The systems differ in how elements of the visualization are manipulated and arranged. SpaceTree ties the act of selection to a change of what is shown by automatically aggregating and filtering the unselected items. In contrast, TreeJuxtaposer allows the user to arrange areas of the tree to ensure visibility for areas of interest. Figure 3.9 summarizes this what–why–how analyis.