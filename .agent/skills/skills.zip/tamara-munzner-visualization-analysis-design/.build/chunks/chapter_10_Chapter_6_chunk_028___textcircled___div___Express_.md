# $\textcircled{ \div}$ Express Values

![](images/fd2f01085622b0f8b3d2aa2d1e6dfe84cd4bd8e08e85017d477f16c83141c82a.jpg)