# Example: Nonlinear Magnification Fields

The nonlinear magnification fields idiom relies on a general computational framework featuring multiple foci of arbitrary magnification levels and shapes, whose scope can be constrained to affect only local regions. The underlying mathematical framework supports calculations of the implicit

![](images/723d1b503c82b528ede7a7670ab06fd9646202f73d3484c16e86e6a516d12a2b.jpg)

![](images/0b54a07512a0eea1b403a6df31746826455bf5b33db30b5253d9d4bbad00877f.jpg)

![](images/15e2676a9de6f3a85a8ba22370ef9d1929950b95c166e70e4b1a039793b96fdb.jpg)  
(a)

![](images/dbf6142e2868bd92b263405cafd5e29804c6d3866a6c743720c426fe9377e3aa.jpg)

![](images/d8a200d0d233267e3707c4070ceb1af7b7e25013a585b4e1f5e7023e4629b685.jpg)

![](images/cbb4424d7b932d54a2ee8e44d44bf97bb9fcfab0fe17a2ba228613c5257b077d.jpg)  
(b)   
Figure 14.9. General frameworks calculate the magnification and minimization fields needed to achieve desired transformations in the image. (a) Desired transformations. (b) Calculated magnification fields. From [Keahey 98, Figure 3].

magnification field required to achieve a desired transformation effect, as shown in Figure 14.9(a). The framework supports many possible interaction metaphors including lenses and stretchable surfaces. It can also expose the magnification fields shown in Figure 14.9(b) directly to the user, for example, to support data-driven magnification trails of moving objects.

<table><tr><td>Idiom</td><td>Nonlinear Magnification Fields</td></tr><tr><td>What: Data</td><td>Any data.</td></tr><tr><td>How: Encode</td><td>Any layout.</td></tr><tr><td>How: Reduce</td><td>Embed: distort with magnification fields; multiple foci, local arbitrary regions, lens or stretch or data-driven interaction metaphors.</td></tr></table>