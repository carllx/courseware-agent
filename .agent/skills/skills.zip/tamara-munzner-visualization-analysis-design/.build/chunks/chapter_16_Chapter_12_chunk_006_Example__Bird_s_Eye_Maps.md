# Example: Bird’s-Eye Maps

Interactive online geographic maps are a widely used idiom that combines the shared encoding and overview–detail choices for geographic data, with a large map exploration view augmented by a small “bird’s-eye” view providing an orienting overview, as shown in Figure 12.3. A small rectangle

![](images/7de45697e7959738daa65b41654391fd0a61964cd94b955a3ad13db52adc01ab.jpg)  
Figure 12.3. Overview–detail example with geographic maps, where the views have the same encoding and dataset; they differ in viewpoint and size. Made with Google Maps, http://maps.google.com.

within the overview shows the region viewable within the detail view. The minimum navigational linkage is unidirectional, where position and size of the rectangle in the overview updates as the user pans and zooms within the large detail view. With bidirectionally linked views, the rectangle can also be moved within the small view to update the region shown in the large one.

<table><tr><td>Idiom</td><td>Bird&#x27;s-Eye Maps</td></tr><tr><td>What: Data</td><td>Geographic.</td></tr><tr><td>How: Encode</td><td>Use given.</td></tr><tr><td>How: Facet</td><td>Partition into two views with same encoding, overview-detail.</td></tr><tr><td>(How: Reduce)</td><td>Navigate.</td></tr></table>

Another common approach is to combine the choices of overview– detail for data sharing with multiform views, where the detail view has a different visual encoding than the overview. A detail view that shows additional information about one or more items selected in a central main view is sometimes called a detail-on-demand view. This view might be a popup window near the cursor or a fixed window in another part of the display.