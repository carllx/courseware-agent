# Dataset Availability

Static

![](images/4e62d3ddced052cbdd681c67ea63e13d2678256b4051e59362ecf783b0bf031e.jpg)

D ynamic

![](images/1a754faa37c7b06bdd5217a758aa401e5878f032aee1773d3eaac3bd979c764f.jpg)