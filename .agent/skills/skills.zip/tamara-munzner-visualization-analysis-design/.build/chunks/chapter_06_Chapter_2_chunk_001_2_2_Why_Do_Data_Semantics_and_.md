# 2.2 Why Do Data Semantics and Types Matter?

Many aspects of vis design are driven by the kind of data that you have at your disposal. What kind of data are you given? What information can you figure out from the data, versus the meanings that you must be told explicitly? What high-level concepts will allow you to split datasets apart into general and useful pieces?

Suppose that you see the following data:

14, 2.6, 30, 30, 15, 100001

What does this sequence of six numbers mean? You can’t possibly know yet, without more information about how to interpret each number. Is it locations for two points far from each other in three-dimensional space, 14, 2.6, 30 and 30, 15, 100001? Is it two points closer to each other in two-dimensional space, 14, 2.6 and

30, 30, with the fifth number meaning that there are 15 links between these two points, and the sixth number assigning the weight of ‘100001’ to that link?

Similarly, suppose that you see the following data:

Basil, 7, S, Pear

These numbers and words could have many possible meanings. Maybe a food shipment of produce has arrived in satisfactory condition on the 7th day of the month, containing basil and pears. Maybe the Basil Point neighborhood of the city has had 7 inches of snow cleared by the Pear Creek Limited snow removal service. Maybe the lab rat named Basil has made seven attempts to find his way through the south section of the maze, lured by scent of the reward food for this trial, a pear.

To move beyond guesses, you need to know two crosscutting pieces of information about these terms: their semantics and their types. The semantics of the data is its real-world meaning. For instance, does a word represent a human first name, or is it the shortened version of a company name where the full name can be looked up in an external list, or is it a city, or is it a fruit? Does a number represent a day of the month, or an age, or a measurement of height, or a unique code for a specific person, or a postal code for a neighborhood, or a position in space?

The type of the data is its structural or mathematical interpretation. At the data level, what kind of thing is it: an item, a link, an attribute? At the dataset level, how are these data types combined into a larger structure: a table, a tree, a field of sampled values? At the attribute level, what kinds of mathematical operations are meaningful for it? For example, if a number represents a count of boxes of detergent, then its type is a quantity, and adding two such numbers together makes sense. If the number represents a postal code, then its type is a code rather than a quantity—it is simply the name for a category that happens to be a number rather than a textual name. Adding two of these numbers together does not make sense.

Table 2.1 shows several more lines of the same dataset. This simple example table is tiny, with only nine rows and four columns. The exact semantics should be provided by the creator of the dataset; I give it with the column titles. In this case, each person has a unique identifier, a name, an age, a shirt size, and a favorite fruit.

Sometimes types and semantics can be correctly inferred simply by observing the syntax of a data file or the names of variables

Table 2.1. A full table with column titles that provide the intended semantics of the attributes.

<table><tr><td>ID</td><td>Name</td><td>Age</td><td>Shirt Size</td><td>Favorite Fruit</td></tr><tr><td>1</td><td>Amy</td><td>8</td><td>S</td><td>Apple</td></tr><tr><td>2</td><td>Basil</td><td>7</td><td>S</td><td>Pear</td></tr><tr><td>3</td><td>Clara</td><td>9</td><td>M</td><td>Durian</td></tr><tr><td>4</td><td>Desmond</td><td>13</td><td>L</td><td>Elderberry</td></tr><tr><td>5</td><td>Ernest</td><td>12</td><td>L</td><td>Peach</td></tr><tr><td>6</td><td>Fanny</td><td>10</td><td>S</td><td>Lychee</td></tr><tr><td>7</td><td>George</td><td>9</td><td>M</td><td>Orange</td></tr><tr><td>8</td><td>Hector</td><td>8</td><td>L</td><td>Loquat</td></tr><tr><td>9</td><td>Ida</td><td>10</td><td>M</td><td>Pear</td></tr><tr><td>10</td><td>Amy</td><td>12</td><td>M</td><td>Orange</td></tr></table>

within it, but often they must be provided along with the dataset in order for it to be interpreted correctly. Sometimes this kind of additional information is called metadata; the line between data and metadata is not clear, especially given that the original data is often derived and transformed. In this book, I don’t distinguish between them, and refer to everything as data.

The classification below presents a way to think about dataset and attribute types and semantics in a way that is general enough to cover the cases interesting in vis, yet specific enough to be helpful for guiding design choices at the abstraction and idiom levels.

Deriving data is discussed in Section 3.4.2.3.