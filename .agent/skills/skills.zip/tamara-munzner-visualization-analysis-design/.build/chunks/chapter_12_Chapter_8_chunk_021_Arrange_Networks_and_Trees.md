# Arrange Networks and Trees

$\textcircled{3}$ Node –Link Diagrams Connec tion Marks

![](images/b6f7f04b1a5e74e0aae2b00b6f6359f41b7956e8a0e3e8eaaf04fc9ecb121fb5.jpg)

NE T WORKS

![](images/c67edbadab73de1370849a2612ec40a0252ee0054d3c2b8caa035be966422e53.jpg)

![](images/7fa3c3d40ff67eaef8d5e0969d11670d905b8a91b1381380f744649540bd8703.jpg)

$\circled{ \div}$ Adjacenc y Matrix Derived Table

![](images/9604ebe1cac78dcab8c65ecbe876bcde6efe84dcc399f5a169ab62685f644a09.jpg)

NE T WORKS

![](images/fddcadd884e9e1d53f1051ef2cf5acde0b93fa5c622787245cfcde4f4772cd8e.jpg)

TREES

![](images/9328358859de84d18695a40f233a900e70faa0d1476b46ba2ed1c9233489b950.jpg)

$\circled{ \div}$ Enclosure

Containment Marks

![](images/c4311510efa39dddf6325ffbbc420859c3fb08d40dde6e8183580dd7c7b85b0d.jpg)

NE T WORKS

![](images/03cf27ba9b4d54954364af78f56c5eae2950298d89ef605ea5252cf54d22c3d9.jpg)

TREES

![](images/b11ecbd440d3588bf86d489df0b897aeaaa4c14ce90f082906ebb6c4a70e0eb3.jpg)  
Figure 9.1. Design choices for arranging networks.