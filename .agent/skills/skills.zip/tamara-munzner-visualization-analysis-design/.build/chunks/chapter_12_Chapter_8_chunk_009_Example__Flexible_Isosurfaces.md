# Example: Flexible Isosurfaces

The flexible isosurfaces idiom uses one more level of derived data, the simplified contour tree, to help users find structure that would be hidden with the standard single-level approach. There may be multiple disconnected isosurfaces for a given value: as the value changes, individual components could appear, join or split, or disappear. The contour tree tracks this evolution explicitly, showing how the connected isosurface components change their nesting structure. The full tree is very complex, as shown in Figure 8.5; there are over 1.5 million edges for the head dataset. Careful simplification of the tree yields a manageable result of under 100 edges, as shown in Figure 8.6. Using this structure for filtering and coloring via multiple coordiated views supports interactive exploration. Figure 8.6 shows several meaningful structures within the head that have been identified through this kind of exploration; seeing them all within the same 3D view allows users to understand both their shape and their relative position to each other.

Filtering is discussed in Section 13.3.2 and coordinating multiple views is discussed in Section 12.3.

![](images/850d5b03e6819e00c1647d88fc8f2b7b5c6dd9734ca9e463083faf86edfa06b7.jpg)  
Figure 8.5. A full contour tree with over 1.5 million edges does not help the user explore isosurfaces. From [Carr et al. 04, Figure 1].

![](images/584d9d8dd93473b7dd0735b7772059239694daa554b7ad560752f06129e5e7e4.jpg)  
Figure 8.6. The flexible isosurfaces idiom uses the simplified contour tree of under 100 edges to help users identify meaningful structure. From [Carr et al. 04, Figure 1].

<table><tr><td>Idiom</td><td>Flexible Isosurfaces</td></tr><tr><td>What: Data</td><td>Spatial field.</td></tr><tr><td>What: Derived</td><td>Geometry: surfaces. Tree: simplified contour tree.</td></tr><tr><td>How: Encode</td><td>Surfaces: use given. Tree: line marks, vertical spa-tial position encodes isovalue.</td></tr><tr><td>Why: Tasks</td><td>Query shape.</td></tr><tr><td>Scale</td><td>One dozen contour levels.</td></tr></table>