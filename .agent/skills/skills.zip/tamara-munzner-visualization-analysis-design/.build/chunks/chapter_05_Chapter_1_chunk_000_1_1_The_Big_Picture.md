# 1.1 The Big Picture

This book is built around the following definition of visualization— vis, for short:

Computer-based visualization systems provide visual representations of datasets designed to help people carry out tasks more effectively.

Visualization is suitable when there is a need to augment human capabilities rather than replace people with computational decision-making methods. The design space of possible vis idioms is huge, and includes the considerations of both how to create and how to interact with visual representations. Vis design is full of trade-offs, and most possibilities in the design space are ineffective for a particular task, so validating the effectiveness of a design is both necessary and difficult. Vis designers must take into account three very different kinds of resource limitations: those of computers, of humans, and of displays. Vis usage can be analyzed in terms of why the user needs it, what data is shown, and how the idiom is designed.

I’ll discuss the rationale behind many aspects of this definition as a way of getting you to think about the scope of this book, and about visualization itself:

. Why have a human in the decision-making loop?   
. Why have a computer in the loop?   
. Why use an external representation?   
. Why depend on vision?

* The field of machine learning is a branch of artificial intelligence where computers can handle a wide variety of new situations in response to datadriven training, rather than by being programmed with explicit instructions in advance.

. Why show the data in detail?   
. Why use interactivity?   
. Why is the vis idiom design space huge?   
. Why focus on tasks?   
. Why are most designs ineffective?   
. Why care about effectiveness?   
. Why is validation difficult?   
. Why are there resource limitations?   
. Why analyze vis?