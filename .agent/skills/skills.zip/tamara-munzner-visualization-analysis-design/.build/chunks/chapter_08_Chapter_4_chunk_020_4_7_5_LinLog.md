# 4.7.5 LinLog

Noack’s LinLog paper introduces an energy model for graph drawing designed to reveal clusters in the data, where clusters are defined as a set of nodes with many internal edges and few edges to nodes outside the set [Noack 03]. Energy-based and force-directed methods are related approaches to network layout and have been heavily used in information visualization. Previous models strove to enforce a layout metric of uniform edge lengths, but Noack points out that creating visually distinguishable clusters requires long edges between them. Figure 4.14(a) shows the success of this approach, in contrast to the indifferentiated blob created by a previously proposed method shown in Figure 4.14(b).

Although a quick glance might lead to an assumption that this graph drawing paper has a focus on algorithms, the primary contribution is in fact at the visual encoding idiom level. The two validation methods used in the paper are qualitative and quantitative result image analysis, shown in Figure 4.15.

Noack clearly distinguishes between the two aspects of energybased methods for force-directed graph layout: the energy model itself versus the algorithm that searches for a state with minimum total energy. In the vocabulary of my model, his LinLog energy model is a visual encoding idiom. Requiring that the edges between clusters are longer than those within clusters is a visual encoding

![](images/684bf1f3a71021abebdedb97556c6f3cb73fbd49c313c710126ff0e411bc5cf2.jpg)

![](images/d8184dbb411bf8d8c441d148b97bad3cf6ae47704ea7374c941655bfe9b3d775.jpg)  
(b)   
Figure 4.14. The LinLog energy model reveals clusters in node–link graphs. (a) LinLog clearly shows clusters with spatial separation. (b) The popular Fructerman-Reingold model for force-directed placement does not separate the clusters. From [Noack 03, Figure 1].

‣ Force-directed placement is discussed in Section 9.2.

![](images/835cb5a986be6e8878c3ab8e7c4a7600354479374dcc0ba17f8c10f97270fe88.jpg)  
Figure 4.15. LinLog [Noack 03] validation methods.