# 15.7 InterRing

The InterRing system [Yang et al. 02] for tree exploration uses a space-filling, radial layout for visually encoding the hierarchy. The interaction is built around a multifocus focus+context distortion approach to change the amount of room allocated to different parts of the hierarchy. Figure 15.13(a) shows the undisorted base layout. Figure 15.13(b) shows that the result of enlarging the blue subtree is shrinking the room allocated to its siblings. Figure 15.13(c) shows a subsequent use of interactive distortion, where the tan region is also enlarged for emphasis.

The proposed structure-based coloring redundantly emphasizes the hierarchical information encoded spatially. Structure-based coloring could be eliminated if InterRing is used as the only view, in order to show a different attribute with color coding. Structurebased coloring is particularly useful when shared color coding is used to coordinate between multiple views, so that items are colored by the tree hierarchy in other linked views with different spatial layouts.

The scalability of InterRing is moderate; it handles hundreds of nodes easily, where the leaf labels are large enough to read. The space-filling geometric configuration yields about three times

![](images/e352dc5ca5a8e55bd5cad26a251cf6487fd9959eb5970be50f6316a77a9ac61a.jpg)  
(a)

![](images/7926d50693d9aa59f6def6f578bf4de6f97cf8bce2dd2a436934ededf23ddf82.jpg)  
(b)

![](images/961752ea98ee3635ba0c0d0930c7f4968f807d4e68cc2a23cc9815f95067a7c8.jpg)  
(c)   
Figure 15.13. The InterRing hierarchy vis idiom uses a space-filling radial visual encoding and distortion-based focus+context interaction. (a) The hierarchy before distortion. (b) The blue selected subtree is enlarged. (c) A second tan region is enlarged. From [Yang et al. 02, Figure 4].

as many legible labels as with a classical node–link layout using labels of the same size. In the extreme case, where each leaf is encoded with a single pixel and the idiom uses the entire screen, InterRing could scale to several thousand nodes. The number of edges in a tree is the same as the number of nodes, so there is no need to separately analyze that aspect. Another useful factor to consider with trees is the maximum tree depth supported by the encoding; that is, the number of levels between the root and the farthest away leaves. InterRing can handle up to several dozen levels, whereas hundreds would be overwhelming.

In addition to being a viable single-view approach when tree exploration is the only task, InterRing is designed to work well with other views where a hierarchy view should support selection, navigation, and roll-up/drill-down operations. It also supports directly editing the hierarchy itself. In contrast, many tree browsing systems do not support modification of the hierarchy.

<table><tr><td>System</td><td>InterRing</td></tr><tr><td>What: Data</td><td>Tree.</td></tr><tr><td>Why: Tasks</td><td>Selection, rollup/drilldown, hierarchy editing.</td></tr><tr><td>How: Encode</td><td>Radial, space-filling layout. Color by tree struc-ture.</td></tr><tr><td>How: Facet</td><td>Linked coloring and highlighting.</td></tr><tr><td>How: Reduce</td><td>Embed: distort; multiple foci.</td></tr><tr><td>Scale</td><td>Nodes: hundreds if labeled, thousands if dense. Levels in tree: dozens.</td></tr></table>