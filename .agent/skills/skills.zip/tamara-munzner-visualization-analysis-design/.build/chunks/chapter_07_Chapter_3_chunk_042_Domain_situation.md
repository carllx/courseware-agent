# Domain situation

Obser ve target users using existing tools

![](images/3e61542445b078a6687e5c2457d01c13a231d8d1cff932d589bb30219eab2909.jpg)