# D a ta / task a bst r a c tio n

![](images/3eada9a9635254c7ba3bbdb4bbf614be74273143d5a8924f07325b7ce7faee84.jpg)