# Query

Identify

![](images/3f61e6ff15436f33f73faf5d1131e1208ece69aa9b03d8ccd26cf6e18871a261.jpg)

Compare

![](images/f918b8641bbcdcd2b86e2e45fbc81e14103acbc6b30974bf2985a297bf569ac4.jpg)

Summarize

![](images/2df91f7765755916794ea6bae0bf3e78a175b867adf61816dd785d6d326afe7b.jpg)  
Figure 3.2. Three levels of actions: analyze, search, and query.

format amenable to computation. The framework has three further distinctions within that case: whether the goal is to present something that the user already understands to a third party, or for the user to discover something new or analyze information that

is not already completely understood, or for users to enjoy a vis to indulge their casual interests in a topic.