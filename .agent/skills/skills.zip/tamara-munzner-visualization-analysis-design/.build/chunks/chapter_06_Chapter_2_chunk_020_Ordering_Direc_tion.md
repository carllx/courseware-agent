# Ordering Direc tion

Sequential

![](images/fd5d0eafaecca0c0d2e35ff263ae4205f501ce7c14242b345fb25071598fc93a.jpg)

Diverging

![](images/62bba646f43448d207bc2f73f9459f669fe9e858314c065f7c46122504dcc2bf.jpg)

Cyclic

![](images/53d553fd1ecb7a894a3d63e5b9b2c0bd228f1d2dbb2a36a607e086ee97468934.jpg)  
Figure 2.7. Attribute types are categorical, ordinal, or quantitative. The direction of attribute ordering can be sequential, diverging, or cyclic.