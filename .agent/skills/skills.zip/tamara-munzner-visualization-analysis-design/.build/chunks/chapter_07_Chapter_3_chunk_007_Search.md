# Search

<table><tr><td></td><td>Target known</td><td>Target unknown</td></tr><tr><td>Location known</td><td>••••Lookup</td><td>••••Browse</td></tr><tr><td>Location unknown</td><td>&lt;••••Locate</td><td>&lt;••••Explore</td></tr></table>

![](images/aa55201b8c36beacd945f7b435f5c6cbc179a67e62f541273dd8bba67a481e88.jpg)