# On your iPhone/iPod Touch/iPad

Download the free VitalSource Bookshelf App available via the iTunes App Store and log into your Bookshelf account. You can find more information at https://support. vitalsource.com/hc/en-us/categories/200134217- Bookshelf-for-iOS