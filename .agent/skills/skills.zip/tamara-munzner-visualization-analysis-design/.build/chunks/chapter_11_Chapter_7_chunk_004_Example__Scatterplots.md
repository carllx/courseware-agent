# Example: Scatterplots

The idiom of scatterplots encodes two quantitative value variables using both the vertical and horizontal spatial position channels, and the mark type is necessarily a point.

Scatterplots are effective for the abstract tasks of providing overviews and characterizing distributions, and specifically for finding outliers and extreme values. Scatterplots are also highly effective for the abstract task of judging the correlation between two attributes. With this visual encoding, that task corresponds the easy perceptual judgement of noticing

Glyphs and views are discussed further in Section 12.4.

![](images/08d4171ca2449cce16ad856196246bf5bf62fb2a903b75330c64e3ec27f6d6de.jpg)  
Figure 7.2. Scatterplot. Each point mark represents a country, with horizontal and vertical spatial position encoding the primary quantitative attributes of life expectancy and infant mortality. The color channel is used for the categorical country attribute and the size channel for quantitative population attribute. From [Robertson et al. 08, Figure 1c].

whether the points form a line along the diagonal. The stronger the correlation, the closer the points fall along a perfect diagonal line; positive correlation is an upward slope, and negative is downward. Figure 7.2 shows a highly negatively correlated dataset.

Additional transformations can also be used to shed more light on the data. Figure 7.3(a) shows the relationship between diamond price and weight. Figure 7.3(b) shows a scatterplot of derived attributes created by logarithmically scaling the originals; the transformed attributes are strongly positively correlated.

![](images/7a4d97e3793773deb11225557769f71f491e5590826f3a5ea229c6395c538aac.jpg)  
(a)

![](images/1a7e3e95f41d440be8380dcd79a281a08280dcc25146568241793b0a5986659a.jpg)  
(b)   
Figure 7.3. Scatterplots. (a) Original diamond price/carat data. (b) Derived log-scale attributes are highly positively correlated. From [Wickham 10, Figure 10].

When judging correlation is the primary intended task, the derived data of a calculated regression line is often superimposed on the raw scatterplot of points, as in Figures 7.3(b) and 1.3.

Scatterplots are often augmented with color coding to show an additional attribute. Size coding can also portray yet another attribute; sizecoded scatterplots are sometimes called bubble plots. Figure 7.2 shows an example of demographic data, plotting infant mortality on the vertical axis against life expectancy on the horizontal axis.

The scalability of a scatterplot is limited by the need to distinguish points from each other, so it is well suited for dozens or hundreds of items.

The table below summarizes this discussion in terms of a what–why– how analysis instance. All of the subsequent examples will end with a similar summary table.

<table><tr><td>Idiom</td><td>Scatterplots</td></tr><tr><td>What: Data</td><td>Table: two quantitative value attributes.</td></tr><tr><td>How: Encode</td><td>Express values with horizontal and vertical spatial position and point marks.</td></tr><tr><td>Why: Task</td><td>Find trends, outliers, distribution, correlation; locate clusters.</td></tr><tr><td>Scale</td><td>Items: hundreds.</td></tr></table>