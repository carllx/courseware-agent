# 5.4 Using Marks and Channels

All channels are not equal: the same data attribute encoded with two different visual channels will result in different information

* In the psychophysics literature, the identity channels are called metathetic or what–where, and the magnitude channels are called prothetic or how much.

* Synonyms for containment are enclosure and nesting.