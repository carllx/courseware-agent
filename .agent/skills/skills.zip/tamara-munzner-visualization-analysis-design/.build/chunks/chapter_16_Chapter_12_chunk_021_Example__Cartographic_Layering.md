# Example: Cartographic Layering

Figure 12.13 shows an example that lets the viewer easily shift attention between layers. In Figure 12.13(a), area marks form a background layer, with three different unsaturated colors distinguishing water, parks, and other land. Line marks form a foreground layer for the road network, with main roads encoded by wide lines in a fully saturated red color and small roads with thinner black lines. This layering works well because of the luminance contrast between the elements on different layers, as seen in Figure 12.13(b) [Stone 10].

Checking luminance contrast explicitly is an example of the slogan Get It Right in Black and White discussed in Section 6.9.

![](images/37f82dc0fe25e3a76e6e11d1834455d6a25efb675ef5dcb5640fc0c7683b3290.jpg)

![](images/0a83e7fb3449c5d1ed42cfe220a8b033d3123bf2f75f4bf6c320af861092a16a.jpg)  
(b)   
Figure 12.13. Static visual layering in maps. (a) The map layers are created by differences in the hue, saturation, luminance, and size channels on both area and line marks. (b) The grayscale view shows that each layer uses a different range in the luminance channel, providing luminance contrast. From [Stone 10].

<table><tr><td>Idiom</td><td>Cartographic Layering</td></tr><tr><td>What: Data</td><td>Geographic</td></tr><tr><td>How: Encode</td><td>Area marks for regions (water, parks, other land), line marks for roads, categorical colormap.</td></tr><tr><td>How: Facet</td><td>Superimpose: static layers distinguished with color saturation, color luminance, and size channels.</td></tr></table>