# 2.4.5 Other Combinations

Beyond tables, there are many ways to group multiple items together, including sets, lists, and clusters. A set is simply an unordered group of items. A group of items with a specified ordering could be called a list.* A cluster is a grouping based on attribute similarity, where items within a cluster are more similar to each other than to ones in another cluster.

There are also more complex structures built on top of the basic network type. A path through a network is an ordered set of segments formed by links connecting nodes. A compound network is a network with an associated tree: all of the nodes in the network are the leaves of the tree, and interior nodes in the tree provide a hierarchical structure for the nodes that is different from network links between them.

Many other kinds of data either fit into one of the previous categories or do so after transformations to create derived attributes. Complex and hybrid combinations, where the complete dataset contains multiple basic types, are common in real-world applications.

The set of basic types presented above is a starting point for describing the what part of an analysis instance that pertains to

![](images/294bcebd305e1801ab508d03e1dc6e2aef6b42be347085f3c91022126140e08f.jpg)