# 6.8 Responsiveness Is Required

The latency of interaction, namely, how much time it takes for the system to respond to the user action, matters immensely for interaction design. Our reaction to latency does not simply occur on a continuum, where our irritation level gradually rises as things take longer and longer. Human reaction to phenomena is best modeled in terms of a series of discrete categories, with a different time constant associated with each one. A system will feel responsive if these latency classes are taken into account by providing feedback to the user within the relevant time scale. The three categories most relevant for vis designers are shown in Table 6.1.

The perceptual processing time constant of one-tenth of a second is relevant for operations such as screen updates. The immediate response time constant of one second is relevant for operations such as visual feedback showing what item that user has selected with a mouse click, or the length of time for an animated transition from one layout to another. The brief task time constant of ten

Table 6.1. Human response to interaction latency changes dramatically at these time thresholds. After [Card et al. 91, Table 3].

<table><tr><td>Time Constant</td><td>Value (in seconds)</td></tr><tr><td>perceptual processing</td><td>0.1</td></tr><tr><td>immediate response</td><td>1</td></tr><tr><td>brief tasks</td><td>10</td></tr></table>

Chapter 12 covers multiple views.   
Chapter 13 covers approaches to data reduction.   
Chapter 14 covers focus+context idioms.

seconds is relevant for breaking down complex tasks into simpler pieces; a good granularity for the smallest pieces is this brief task time.