# 6.1 The Big Picture

This chapter contains rules of thumb: advice and guidelines. Each of them has a catchy title in hopes that you’ll remember it as a slogan. Figure 6.1 lists these eight rules of thumb.