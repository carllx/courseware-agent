# 10.4.1 Size Channels

Size is a magnitude channel suitable for ordered data. It interacts with most other channels: when marks are too small, encodings in another channel such as shape or orientation simply cannot be seen. Size interacts particularly strongly with color hue and color saturation.

Length is one-dimensional (1D) size; more specifically, height is vertical size and width is horizontal size. Area is two-dimensional (2D) size, and volume is three-dimensional (3D) size. The accuracy of our perceptual judgements across these three channels varies considerably.

Our judgements of length are extremely accurate. Length judgements are very similar to unaligned planar position judgements: the only channel that is more accurate is aligned planar position.

In contrast, our judgement of area is significantly less accurate. Stevens assigns a power law exponent of 0.7 for area, as shown in Figure 5.7. The area channel is in the midde of the rankings, below angle but above 3D depth.

The volume channel is quite inaccurate. The volume channel is at the bottom of the rankings, in an equivalence class with curvature. Encoding with volume is rarely the right choice.

A larger-dimensional size coding clearly subsumes a smallerdimensional one: length and area cannot be simultaneously used to encode different dimensions. Similarly, the combination of smaller-dimensional sizes is usually integral rather than separable, as illustrated in Figure 5.10 where the combination of small width, large width, small height, and large height yielded three groups rather than four: small areas, large areas, and flattened areas. It is possible that people asked to make area judgements might take the shortcut of simply making length judgements.

![](images/8eb2f4c74f5e8ca142b108052b705794243c5cb935fe9dda7008450b6f6212e8.jpg)

Sequential orderedSequential ordered line mark or arrow glyphline mark or arrow glyph

![](images/cd235b06acf699424c0c69619b3e6fa7b20138c72913e3698f3f071b5ec19a52.jpg)

Diverging ordered arrow glyph

![](images/ae1b964ce4a97af05cf86415fd49c3255dfbeed87b36325ad8e80d20d64e3aaf.jpg)  
Figure 10.14. Tiltmaps using the angle channel to show three different types of ordered data. (a) A sequential attribute can be shown with either a line mark or an arrow glyph in one quadrant. (b) A diverging attribute can be shown with two quadrants and an arrow glyph. (c) A cyclic attribute can be shown with all four quadrants and arrow glyphs.

Cyclic ordered arrow glyph

(a)

(b)