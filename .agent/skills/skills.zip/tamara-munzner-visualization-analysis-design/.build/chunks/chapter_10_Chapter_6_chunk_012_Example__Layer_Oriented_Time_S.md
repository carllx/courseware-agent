# Example: Layer-Oriented Time-Series Vis

Figure 6.8 shows an example that is similar on the surface to the previous one, but in this case 3D is used with care and the design is well justified [Lopez-Hernandez et al. 10]. In this system for visualizing oscilloscope time-series data, the user starts by viewing the data using the traditional eye diagram where the signal is wrapped around in time and shown as many overlapping traces. Users can spread the traces apart using the metaphor of opening a drawer, as shown in Figure 6.8(a). This drawer interface does use 3D, but with many constraints. Layers are orthographically projected and always face the viewer. Navigation complexity is controlled by automatically zooming and framing as the user adjusts the drawer’s orientation, as shown in Figure 6.8(b).

![](images/b07283cb8386e1b7a89416548ff6d1fd27e0777c8a005c6cb60a2fb54bc6c738.jpg)

![](images/733fdf7867eff35abf98bb4d82efeac3decbe8ce324c2d684f82600675ce3249.jpg)  
(a)

![](images/9be2ac325856faf44cde2cf96b3408b5725f109b45179f95bc821cdae95c183c.jpg)

![](images/a3b9779f1109d268418f7c2e83180b4e7561ff7744ed3820dfdc8cf4338e4859.jpg)  
(b)   
Figure 6.8. Careful use of 3D. (a) The user can evolve the view from the traditional overlapping eye diagram with the metaphor of opening a drawer. (b) The interaction is carefully designed to avoid the difficulties of unconstrained 3D navigation. From [Lopez-Hernandez et al. 10, Figures 3 and 7].