# Attributes

One

Distribution

![](images/b9da6ad87b8ed5b866c9ec1a8e96dac6f05def2fd720899dfcf525dce628fedf.jpg)

Extremes

Many

Dependency

![](images/0683c03637bbfe0d26c5485d9ba31fe04fa69f02bbde25e379f992b38a2de6b5.jpg)

Correlation

![](images/5a61efa5699d1d3577daa31c2b7fa3b9ebbcbfdd08f9f4cc2cd4534488b6b12e.jpg)

Similarity

![](images/2ecd01868861865fcbf8fdb5901d4d0b4e74818f54a808369837c5f0552d87f2.jpg)