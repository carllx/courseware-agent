# A lg o rit h m

Measure system time/memor y

Analyze computational complexity

Analyze results qualitatively

Measure human time with lab experiment (lab study)

Obser ve target users af ter deployment ( )

Measure adoption