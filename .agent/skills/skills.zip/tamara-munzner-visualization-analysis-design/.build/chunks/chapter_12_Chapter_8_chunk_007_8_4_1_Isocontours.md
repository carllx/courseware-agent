# 8.4.1 Isocontours

A set of isolines, namely, lines that represent the contours of a particular level of the scalar value, can be derived from a scalar spatial field.* The isolines will occur far apart in regions of slow change and close together in regions of fast change but will never overlap; thus, contours for many different values can be shown simultaneously without excessive visual clutter. Color coding the regions between the contours with a sequential colormap yields a contour plot, as shown in Figure 6.9(c).

* Synonyms for isolines are contour lines and isopleths.