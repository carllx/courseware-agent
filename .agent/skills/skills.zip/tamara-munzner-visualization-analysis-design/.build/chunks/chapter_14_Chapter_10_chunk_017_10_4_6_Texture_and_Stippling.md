# 10.4.6 Texture and Stippling

The term texture refers to very small-scale patterns. Texture is also a complex perceptual phenomenon that can be simplified by considering it as the combination of three perceptual dimensions: orientation, scale, and contrast. The first two pertain to the individual texture elements and have obvious mappings to the angle

Section 11.4.2 covers highlighting.

* The terms hatching and cross-hatching are synonyms for stippling in twodimensional areas.

and size channels, respectively. Contrast refers to luminance constrast, which is related to the density of the texture elements; it maps to the luminance channel.

Texture can be used to show categorical attributes, in which case the goal is to create patterns that are distinguishable from each other using the combination of all three channels. In this case, with sufficient care it is possible to create at least one or two dozen distingishable bins.

Texture can also be used to show ordered attributes, for example, by mapping separate attributes to each of the three channels. In this case, no more than three or four bins can be distinguished for each. Another possibility is to use all three channels in combination to encode more bins of a single attribute; with careful design, around a dozen bins can be distinguishable.

The term stippling means to fill in regions of drawing with short strokes. It is a special case of texture. Stippling is still in regular use for lines; a familiar example is the use of dotted or dashed lines. Stippling was heavily used for area marks with older printing technology because it allows shades of gray to be approximated using only black ink; now that color and grayscale printing are cheap and pervasive, area stippling is less popular than in the past.*