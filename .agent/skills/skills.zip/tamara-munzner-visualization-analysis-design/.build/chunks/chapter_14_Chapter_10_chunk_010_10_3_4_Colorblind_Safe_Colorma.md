# 10.3.4 Colorblind-Safe Colormap Design

Designers using color should take the common problem of red– green color blindness into account. It is a sex-linked inherited trait that affects $8 \%$ of males and a much smaller proportion of females, $0 . 5 \%$ . In the common forms of color blindness the ability to sense along the red–green opponent color axis is limited or absent. The problem is not limited to simply telling red apart from green; many pairs that are discriminable to people with normal color vision are confused, including red from black, blue from purple, light green from white, and brown from green.

On the theoretical side, the safest strategy is to avoid using only the hue channel to encode information: design categorical colormaps that vary in luminance or saturation, in addition to hue. Clearly, avoiding colormaps that emphasize red–green, especially divergent red–green ramps, would be wise. In some domains there are strong conventions with the use of red and green, so those user expectations can be accommodated by ensuring luminance differences between reds and greens.

On the practical side, an excellent way to ensure that a design uses colors that are distinguishable for most users is to check it with a color blindness simulator. This capability is built into many desktop software tools including Adobe Illustrator and Photoshop, and also available through web sites such as http://www.rehue. net, http://www.color-blindness.com, and http://www.etre.com/ tools/colourblindsimulator.

Opponent color is discussed in Section 10.2.

‣ For example, the historical and technical reasons behind red–green usage in bioinformatics domain are discussed in Section 7.5.2.