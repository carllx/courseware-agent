# $\textcircled{ \div}$ Embed

Elide Data

![](images/7ba617344d6d180f1bd152a759ccaf625ef880b8d7208fae1d4090780dcf587a.jpg)

Superimpose Layer

![](images/6cf98a1e42ff4571ab68e889ec7058cf10b4d8e2e108f443e2b3ad8d76312ba7.jpg)

Distor t Geometr y

![](images/be7cc56dff48887d45b07b1e3f6e27d94e8579f92ebb9745713412ad695c3ea1.jpg)