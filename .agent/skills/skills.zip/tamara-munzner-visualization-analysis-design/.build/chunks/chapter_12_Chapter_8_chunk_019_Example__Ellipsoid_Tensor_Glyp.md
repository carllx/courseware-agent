# Example: Ellipsoid Tensor Glyphs

Tensor quantities can be naturally decomposed into orientation and shape information; these quantities can be visually encoded with a 3D glyph.4 A

![](images/3863efe7c9d09974572738a8780780bcfdfaa80a1c4f7689c981cba0beb2f89f.jpg)  
(a)

![](images/a656cb2eec9b0b72afee039efdbdd33c1e43c1b6c762ae5bab0dd4e84c97c3ce.jpg)  
(b)   
2D diffusion illustrated with ink and paper. (a) Isotropic Kleenex. Figure 8.10.(b) Anisotropic newspaper.

shape may be , where each direction is the same, or , isotropic anisotropicwhere there is a directional asymmetry. For diffusion in biological tissue, anisotropy occurs when the water moves through tissue faster in some directions than in others; Figure 8.10 shows a physical example of the 2D case where two different kinds of paper are stained with ink. There is isotropic diffusion through Kleenex, where the ink spreads at the same rate in all directions as shown in Figure 8.10(a), whereas the newspaper has a preferred direction where the ink moves faster with anisotropic diffusion as shown in Figure 8.10(b).

Figure 8.11 shows the three basic shapes that are possible in 3D. The fully isotropic case is a perfect sphere, as in Figure 8.11(a); the partially anisotropic planar case is a sphere flattened in only one direction, as in

![](images/246a024398e085fe447133a1d0114f10520989da431c3011a9db7f1bd54be482.jpg)  
(a)

![](images/157b132b3c5044c9d64e6b37a41649994e67990076e3c9960abd839a760568e4.jpg)  
(b)

![](images/81dba164eb8e358da2956fa2835672b3aefdcb28442598ae6dc832cc84a8ad7e.jpg)  
(c)   
Ellipsoid glyphs can show three basic shapes. (a) Isotropic: sphere. Figure 8.11.(b) Partially anisotropic: planar. (c) Fully anisotropic: linear. From [Kindlmann 04, Figure 1].

![](images/a0bf13838f65b6a72423d9d9a87b027af16f03a85a3b3130f1984be5f5b11b73.jpg)  
(a)

![](images/0e0e8563eddd65ad2bea5a11378661a207020fbf5088d6154eb9d34e7fb892e9.jpg)  
(b)   
Figure 8.12. Ellipsoid glyphs show shape and orientation of tensors at each cell in a field. (a) 2D slice. (b) 3D field, with isotropic glyphs filtered out. From [Kindlmann 04, Figures 10a and 11a].

Figure 8.11(b); and the completely anisotropic linear case is flattened differently each of two directions to become a cigar-shaped ellipsoid, as in Figure 8.11(c). One way to encode this shape information in a 3D glyph is with an ellipsoid, where the direction that it points is an intuitive way to encode the orientation. Figure 8.12(a) shows using ellipsoid glyphs to inspect a 2D slice of a tensor field with the orientation attributes also used for coloring. In the 3D case shown in Figure 8.12(b), the isotropic glyphs are filtered out so that the anisotropic regions are visible.

Ellipsoid tensor glyphs have the weakness that different glyphs cannot be disambiguated from a single viewpoint; superquadric tensor glyphs are a more sophisticated approach that resolve this ambiguity [Kindlmann 04].

<table><tr><td>Idiom</td><td>Ellipsoid Tensor Glyphs</td></tr><tr><td>What: Data</td><td>Spatial field: 3D tensor field.</td></tr><tr><td>What: Derived</td><td>Three quantitative attributes: tensor shape. Three vectors: tensor orientation.</td></tr><tr><td>How: Encode</td><td>Glyph showing six derived attributes, color and opacity according to cluster.</td></tr></table>

The geometric tensor flow visual encoding idioms are based on similar intuitions as in the vector case, by computing sparse de-

rived geometry such as hyperstreamlines or tensorlines; the same situation holds for the texture tensor flow idioms. Similarly, feature tensor flow idioms explicitly detect features in tensor fields, where simpler cases that occur in vector fields are generalized to the more complex possibilities of tensor fields.