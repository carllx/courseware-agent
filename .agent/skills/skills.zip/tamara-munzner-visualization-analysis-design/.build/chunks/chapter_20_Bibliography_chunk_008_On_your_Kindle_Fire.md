# On your Kindle Fire

Download the free VitalSource Bookshelf App available from Amazon and log into your Bookshelf account. You can find more information at https://support.vitalsource.com/ hc/en-us/categories/200139976-Bookshelf-for-Androidand-Kindle-Fire

N.B. The code in the scratch-off panel can only be used once. When you have created a Bookshelf account and redeemed the code you will be able to access the ebook online or offline on your smartphone, tablet or PC/Mac.