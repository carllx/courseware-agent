# Example: DOITrees Revisited

The DOITrees Revisited system shown in Figure 14.2 uses multiple foci to show an elided version of a 600,000 node tree. The shaded triangles provide an aggregate representation showing the size of the elided subtrees. The context in which to show them is computed using tree traversal from the many focus nodes up toward their common ancestors and the tree root. In this case, distance is computed topologically based on hops through the tree, rather than geometrically through Euclidean space. The focus nodes can be chosen explicitly by clicking, or indirectly through searching.

![](images/792bbb12fcad28c208b80bbd2d360e0038851be5cd1021c51bcf3fa0eb50a010.jpg)  
Figure 14.2. DOITrees Revisited uses elision to show multiple focus nodes within context in a 600,000 node tree. From [Heer and Card 04, Figure 1].

<table><tr><td>System</td><td>DOITrees Revisited</td></tr><tr><td>What: Data</td><td>Tree.</td></tr><tr><td>How: Encode</td><td>Node-link layout.</td></tr><tr><td>How: Reduce</td><td>Embed: elide, multiple foci.</td></tr><tr><td>Scale</td><td>Nodes: hundreds of thousands.</td></tr></table>

<!-- Chunk 7 End -->

<!-- Chunk 8 Start -->