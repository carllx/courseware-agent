# Example: Radial Bar Charts

The same five-attribute dataset is encoded with a rectilinear bar chart in Figure 7.16(a) and with a radial alternative in Figure 7.16(b). In both cases, line marks are used to encode a quantitative attribute with the length channel, and the only difference is the radial versus the rectilinear orientation of the axes.

![](images/3e00cf249c52c1217625c0626f41ba223674d6bafa15fdea58c64f887296a531.jpg)

![](images/3fd1c23a365217a7cf5badd1e7f77c4505f04ec4b930862ed8ba9dc07fd7226d.jpg)

Figure 7.16. Radial versus rectilinear layouts. (a) Rectilinear bar chart. (b) Radial bar chart. After [Booshehrian et al. 11, Figure 4].

<table><tr><td>Idiom</td><td>Radial Bar Charts</td></tr><tr><td>What: Data</td><td>Table: one quantitative attribute, one categorical attribute.</td></tr><tr><td>How: Encode</td><td>Length coding of line marks; radial layout.</td></tr></table>