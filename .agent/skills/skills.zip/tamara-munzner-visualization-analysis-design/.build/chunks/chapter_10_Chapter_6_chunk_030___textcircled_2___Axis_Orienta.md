# $\textcircled{2}$ Axis Orientation

![](images/e8ea9972596f36d0a7408710c7a403521914ca7a4b8a1bf9b84288f663b870dc.jpg)  
Rectilinear

![](images/acdf74b911fb0a070d6df70539835c5f08209dcdfc06cd8dc2987d3037139618.jpg)  
Parallel

![](images/32841050868494441a115ee6ce639bea8d6794a6c7e78965fefff450f64df978.jpg)  
Radial