# Reduce

![](images/824722dcd36d8db0758cf18505cff730779d4f3b42cae661bcaf325c8e200661.jpg)  
$\circled{ \div}$ Filter   
Items

![](images/442221661d5d3ce58e40ed62ceab02d6b4b6660d2891bac26bb3cb4c7d4c63f7.jpg)  
Attributes   
$\textcircled{ \div}$ Aggregate

![](images/bc799be4d03a581b36f23b8a9d133d50fc75b6d30205601e02116bde98a86b0d.jpg)  
Items

![](images/d48861764b8dd77abd3a193488170c2d7fd922e0d2e405cfd36baa310ed05531.jpg)  
Attributes

![](images/94fec6ab79cc13c728169ce7a780dbcab21b57fed8b40226e33f013645ad27d2.jpg)  
$\circled{ \div}$ Filter

![](images/8d702b7c661d7760d7f418d8991752e2a53fbafb25f2e9b1be0b8578e2837bc0.jpg)  
Aggregate

![](images/8131fb9986657f2a2bf7c5b9b6f133f061e788a22039659e2ebac77eb7df56e2.jpg)  
Embed   
Figure 13.1. Design choices for reducing (or increasing) the amount of data items and attributes to show.