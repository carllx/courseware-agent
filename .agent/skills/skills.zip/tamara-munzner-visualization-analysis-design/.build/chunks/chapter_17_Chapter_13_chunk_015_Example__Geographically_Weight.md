# Example: Geographically Weighted Boxplots

The geowigs family of idioms, namely, geographically weighted interactive graphics, provides sophisticated support for spatial aggregation using geographically weighted regression and geographically weighted summary statistics [Dykes and Brunsdon 07]. Figure 13.11 shows a multivariate geographic dataset used to explore social issues in 19th century France. The six quantitative attributes are population per crime against persons $( x l )$ , population per crime against property $( x 2 )$ , percentage who can read

![](images/c9af486dcb0a3b30b5276d6d5e4d1ce5e01d8dea0bbde1f6a2e019ad1f6a059e.jpg)  
(a)

![](images/caee5784af551bb4b7d558654e9af01c55854a2c4e62a154f33d58ec0fc49ecd.jpg)

![](images/3616bed1f9e3342c141f73db16ca1cb9ab727365a874bf95430ec249764b3a1d.jpg)  
(b)

![](images/7555f7ebb5949f043eb7d86e393fa0e76bc4c9fa3fa28ee7e0776f55433f0824.jpg)

![](images/517ac69ee306f9613e10f0baa46c290bc8c4b299ed555bc9a7d6e5ff9491b2b7.jpg)  
(c)

![](images/74cc9476f016d7eb3eb9f09ce2e3732cbb233578833527ababc8f6918ae7b019.jpg)  
(d)   
Figure 13.11. Geowigs are geographically weighted interactive graphics. (a) A choropleth map showing attribute x1. (b) The set of gw-boxplots for all six attributes at two scales. (c) Weighting maps showing the scales: local and larger. (d) A gw-mean map at the larger scale. From [Dykes and Brunsdon 07, Figures 7a and 2].

and write $( x 3 )$ , donations to the poor $( x 4 )$ , population per illegitimate birth $( x 5 )$ , and population per suicide $( x 6 )$ .

Figure 13.11(a) shows a standard choropleth map colored by personal crime attribute $x l$ , with the interactively selected region Creuse (23) highlighted. Figure 13.11(b) shows gw-boxplots for all six attributes, at two scales. The gw-boxplot, a geographically weighted boxplot geowig, supports comparison between the global distribution and the currently chosen spatial scale using the design choice of superimposed layers. The global statistical distribution is encoded by the gray boxplot in the background, and the local statistics for the interactively chosen scale are encoded by a foreground boxplot in green. Figure 13.11(c) shows the weighting maps for the currently chosen scale of each gw-boxplot set: very local on top, and a larger scale on the bottom. Figure 13.11(d) shows a gw-mean map, a geographically weighted mean geowig, weighted according to the same larger scale.

At the local level, the first $x l$ attribute is clearly an outlier in the gwboxplot, matching that region’s pale color in the choropleth map. When weighted according to a larger scale, that attribute’s distribution is close to the global one in both the boxplot, matching the mid-range color in the gw-mean map geowig in Figure 13.11(d).

<table><tr><td>Idiom</td><td>Geographically Weighted Boxplots</td></tr><tr><td>What: Data</td><td>Geographic geometry with area boundaries. Table: Key attribute (area), several quantitative value attributes. Table: Five-number statistical summary distributions for each original attribute.</td></tr><tr><td>What: Derived</td><td>Multidimensional table: key attribute (area), key attribute (scale), quantitative value attributes (geographically weighted statistical summaries for each area at multiple scales).</td></tr><tr><td>How: Encode</td><td>Boxplot.</td></tr><tr><td>How: Facet</td><td>Superimposed layers: global boxplot as gray background, current-scale boxplot as green foreground.</td></tr><tr><td>How: Reduce</td><td>Spatial aggregation.</td></tr></table>