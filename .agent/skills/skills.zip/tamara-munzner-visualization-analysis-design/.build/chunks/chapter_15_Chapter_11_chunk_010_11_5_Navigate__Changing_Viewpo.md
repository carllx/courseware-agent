# 11.5 Navigate: Changing Viewpoint

Large and complex datasets often cannot be understood from only a single point of view. Many interactive vis systems support a metaphor of navigation, analogous to navigation through the physical world. In these, the spatial layout is fixed and navigation acts as a change of the viewpoint.

The term navigation refers to changing the point of view from which things are drawn. The underlying metaphor is a virtual camera located in a particular spot and aimed in a particular direction. When that camera viewpoint is changed, the set of items visible in the camera frame also changes.

Navigation can be broken down into three components. The action of zooming moves the camera closer to or farther from the plane. Zooming the camera in close will show fewer items, which appear to be larger. Zooming out so that the camera is far away will show more items, and they will appear smaller. The action of panning the camera moves it parallel to the plane of the image, either up and down or from side to side.* In 3D navigation, the general term translating is more commonly used for any motion that changes camera position.* The action of rotating spins the camera around its own axis. Rotation is rare in two-dimensional navigation, but it is much more important with 3D motion.

Since changing the viewpoint changes the visible set of items, the outcome of navigation could be some combination of filtering and aggregation. Zooming in or panning with a zoomed-in camera

filters based on the spatial layout; zooming out can act as aggregation that creates an overview.

Navigation by panning or translating is straightfoward; zooming is the more complex case that requires further discussion.