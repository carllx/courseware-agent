# $\textcircled{7}$ Analyze

Consume

Discover

![](images/3399c6a93ddedf97faf87f64ddac2f11d22121d960c146b8e7f787bbb6ed28f2.jpg)

Present

![](images/401f00d8e382cfbd9f35be696bca492a1d4e3f1496aecf9d232bc86deff769a6.jpg)

Enjoy

![](images/6effa18294bf4732e950325ac0b9523f614ec43314909c3f5bbbe6a1a7a1cb40.jpg)

Produce

Annotate

![](images/305738805e1eb5c50da94bbaf7a0f1eed2cb8d24a6c64f07f82a56bc77a0b22f.jpg)

Record

![](images/76f1c5eb58244f86eccf3726089602f16cfb2952034fee1c829c1bfc22f713b1.jpg)

Derive

![](images/febb68854a6502135b7d18c3f84377cb60661422782241c3829fb078c571b1b2.jpg)