# 13.4.3 Attribute Aggregation: Dimensionality Reduction

Just as attributes can be filtered, attributes can also be aggregated, where a new attribute is synthesized to take the place of multiple original attributes. A very simple approach to aggregating attributes is to group them by some kind of similarity measure, and

Choropleth maps are covered in Section 8.3.1.   
Boxplots are covered in Section 13.4.1.

* The words attribute aggregation, attribute synthesis, and dimensionality reduction (DR) are all synonyms. The term dimensionality reduction is very common in the literature. I use attribute aggregation as a name to show where this design choice fits into the taxonomy of the book; it is not a typical usage by other authors. Although the term dimensionality reduction might logically seem to include attribute filtering, it is more typically used to mean attribute synthesis through aggregation.

‣ Deriving new data is discussed in Section 3.4.2.3.

then synthesize the new attribute by calculate an average across that similar set. A more complex approach to aggregation is dimensionality reduction (DR), where the goal is to preserve the meaningful structure of a dataset while using fewer attributes to represent the items.