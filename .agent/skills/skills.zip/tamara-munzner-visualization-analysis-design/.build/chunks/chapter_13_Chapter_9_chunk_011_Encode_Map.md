# Encode Map

![](images/19e7001ca8c7ddc57580baa2497bca3e60a829dd10b24464cf21322625a39bb2.jpg)