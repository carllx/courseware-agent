# 9.3 Matrix Views

Network data can also be encoded with a matrix view by deriving a table from the original network data.