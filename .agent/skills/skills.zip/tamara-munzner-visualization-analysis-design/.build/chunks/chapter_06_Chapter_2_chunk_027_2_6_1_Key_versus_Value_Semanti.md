# 2.6.1 Key versus Value Semantics

* A synonym for key attribute is independent attribute. A synonym for value attribute is dependent attribute. The language of independent and dependent is common in statistics. In the language of data warehouses, a synonym for independent is dimension, and a synonym for dependent is measure.

A key attribute acts as an index that is used to look up value attributes.* The distinction between key and value attributes is important for the dataset types of tables and fields, as shown in Figure 2.8.