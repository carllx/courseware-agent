# Toolglass and Magic Lenses

Spatial, quantitative curvature attribute across surface.

How: Encode

Use given, color by curvature.

How: Reduce

Embed: superimpose.