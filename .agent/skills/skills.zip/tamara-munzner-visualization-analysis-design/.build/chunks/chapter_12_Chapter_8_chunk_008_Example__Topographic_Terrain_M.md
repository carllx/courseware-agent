# Example: Topographic Terrain Maps

Topographic terrain maps are a familiar example of isolines in widespread use by the general public. They show the contours of equal elevation above sea level layered on top of the spatial substrate of a geographic map. Figure 8.4 shows contours every 10 meters, with nearly 80 levels in total. Small closed contours indicate mountain peaks, and the flat regions near sea level have no lines at all.

<table><tr><td>Idiom</td><td>Topographic Terrain Map</td></tr><tr><td>What: Data</td><td>2D spatial field; geographic data.</td></tr><tr><td>What: Derived</td><td>Geometry: set of isolines computed from field.</td></tr><tr><td>How: Encode</td><td>Use given geographic data geometry of points, lines, and region marks. Use derived geometry as line marks (blue).</td></tr><tr><td>Why: Tasks</td><td>Query shape.</td></tr><tr><td>Scale</td><td>Dozens of contour levels.</td></tr></table>

![](images/246c9d1919e94106997d61eee7755c95a1e2cdd49c9f9c6e5442ccb2a80ca1f8.jpg)  
Figure 8.4. Topographic terrain map, with isolines in blue. From https://data.linz.govt.nz/layer/768-nz-mainland -contours-topo-150k.

Spatial navigation is discussed further in Section 11.5.

The idiom of isosurfaces transforms a 3D scalar spatial field into one or more derived 2D surfaces that represent the contours of a particular level of the scalar value. The resulting surface is usually shown with interactive 3D navigation controls for changing the viewpoint using rotation, zooming, and translation.

In the 3D case, simply showing all of the contour surfaces for dozens of values at once is not feasible, because the outer contour surfaces would occlude all of the inner ones. Thus, one crucial question is how to determine which level will produce the most useful result. Exploration is frequently supported by providing dynamic controls for changing the chosen level on the fly, for example, with a slider that allows the user to quickly change the contour value from the minimum to the maximum value within the dataset.

With careful use of colors and transparency, several isosurfaces can be shown at once. Figure 8.3(c) shows a 3D spatial field of a human tooth with five distinguishable isosurfaces.