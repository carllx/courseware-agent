hyperbolic geometry, see also focus+context, 338

hyperplane, 259

identify, 54

identity, see channel, identity

idiom, 9–11, 71–72, 78–80

image plane, 119

image-space compositing, see superimpose

immediate, 76

immersion, 134

importance, 332

independent attribute, see attribute, key

information density, 15, 19

information landscape, 129

information scent, 303

information visualization, 29

infovis, 29

input, 17

instance, 17

integral, 106

integration-based flow, see geometric flow

interaction, 9–10, 71

interpolation, 28, 258

isocontours, 182

isolines, 183

isopleths, see isolines

isosurfaces, 184–185, 197

isotropic, 195

item, 23, 25

item aggregation, 305–313

item filtering, 301–303

jump cut, 248

key, 34, 145

$L ^ { * } a ^ { * } b ^ { * }$ , see color space, $L ^ { * } a ^ { * } b ^ { * }$

lab study, 79, 90, 92

latency, 137, 142

layer, 288

levels, 146, 250, 279

lightness, 220

line charts, 90, 155–157, 175

line-of-sight ambiguity, 119

link, 24, 26

link density, 210

linked highlighting, 267, 296, 331, 351

linked navigation, 276

linked views, 267

list, 30

list alignment, 149–157, 354

local minimum, 206

locate, 53

lookup, 53

luminance, 221–223, 229–233

machine learning, 2

macroglyphs, 280

magnitude, see channel, magnitude

main-effects ordering, 282

map projections, 261

mark, 95–99, 280

matrix alignment, 157–161, 308, 354

matrix permutation, see matrix reordering

matrix reordering, 160, 176

measure, see attribute, value

memory, 131–132, 141

mental model, 102

metadata, 23

metathetic, see channel, identity

microglyphs, 281

modifiable areal unit problem (MAUP), 313

motion parallax, 120

multidimensional, 37

multidimensional scaling (MDS), 316

multidimensional table, 25, 36

multifocal displays, see focus+context

multiform, 351

multiform views, 266, 267

multilevel network, 206–208, see also compound network, 216, 360

multimodal, 309

multiple views, see linked views; multiform

multivariate, 37

navigate, 254–261

navigation, 254

nested model, 67–93

nesting, see containment

networks, 25–27, 201–217, 355, 360

node, 26, see also sinks

node–link diagrams, 83, 201, 216

nominal, see attribute, categorical

nondeterministic, 205

nonlinear magnification fields, see also focus+context, 338

nonlinear optimization, see force-directed placement

nonmonotonic, 166

nonspatial data, 28

normalized stacked bar chart, 169

novelties, see outliers

object constancy, 335

occlusion, 120

offline, see static file

online, see dynamic

opponent color channels, 220

optimize, 12

ordination, see matrix reordering

orientation, see also channel, angle, 237

orthographic projection, see also dimensional filtering, 261

outliers, 55

output, 17

overview, 55, 135, 142

overview–detail, 269, 351

pane, see view

panel, see view

panning, 254

parallel coordinates, 162–166, 176, 311–313

partition, 278–288

partitioning, 279, 296

path, 30, 57

path surfaces, 191

pathline, 191

pattern, see trend

perception, 19, 103–114

perspective distortion, 121, 261, 327

perspective projection, 261

pixel-oriented, see dense

pliable surfaces, see focus+context

polar area chart, 168

polar coordinates, 166

polyfocal display, 337

polyfocal projections, see focus+context

polyline, 162

popout, 109

position, 24

preattentive processing, see popout

present, 47

problem-driven, 73

produce, 49

project, 261

pronouns

I, xviii

they, xviii, 75

we, xviii

you, xviii, 75

protanopia, 220

prothetic, see channel, magnitude

proximity, 111

pseudocoloring, see colormap

psychophysics, 103

qualitative, see colormap, categorical

quality metrics, 79

quantized colormap, see colormap, segmented

query, 54

radial, 166–171, 176, 358

rank-by-feature, 353

reconstruct, 28

record, 49

rectilinear, 162

rectilinear grid, 29

reduce, 299–321

region, 149, 279–280

rendering, 139

resolution, 134

RGB, see color space, RGB

rods, 219

roll-up, 355

rose plot, see polar area chart

rotating, 254

rubber sheet navigation, see focus+context

rules of thumb, 117–142

saddle points, 189

salience, 101

sampling, 27, 258

satisfy, 12

saturation, 220, 223–224

scagnostics, 344

scalability, 14

scalar field, 37, 182–187

scalars, 27, 37

scatterplot matrix (SPLOM), 160, 342, 354

scatterplots, 146, 306–308, 342, 351

scented widgets, 303, 320

scientific visualization, 29

scivis, 29

scrolling, see panning

search, 53

select, 249–254, 262

semantic zooming, 87, 255–256, 262, 365

semantics, 22

separable, 106

serial search, 110

seriation, see matrix reordering

set, 30

shape, 57, 101, 238

shared data, 269

shared encoding views, 267

similarity, 57, 111

similarity measure, 305

similarity metric, see similarity measure

sinks, 189

skew, 309

slice, 258

slicing, 183

slope graphs, 247

small multiples, 266, 269–276, 347, 351

sorting, 245

sources, 189

space-filling, 174–175, 308, 328, 347, 358

sparklines, 255

sparse, 316

spatial aggregation, 313, 321

spatial field, 28, 182–197

spectral sensitivity, 222

splines, 202

spread, 309

spring embedding, see force-directed placement

stacked bar chart, 151, 169

static file, 31

static layers, 289

steady, 189

stepped colormap, see colormap, segmented

stippling, 240

streak surfaces, 191

streakline, 191

stream surfaces, 191

streamgraphs, 153, 175

streamline, 191

stretch and squish navigation, 87, see also focus+context, 331, 338

structured grid, 29

summarize, 54, 55

superimpose, 266, 288–294, 296, 337

surprises, see outliers

tables, 24–25, 145–176, 347, 351

target, 55

tasks, 11, 43–57, 70, 71

technique-driven, 73

tensor field, 37, 38, 194–198

tensor glyphs, 194

tensors, 27, 37

terrain, see information landscape

texture, 193, 239

texture flow, 193

texture tensor flow, 197

thematic cartography, 180

threats to validity, 75

tiltmap, 237

time series, 87, 291–292

time surfaces, 191

time-series, 39, 125–128

time-varying, 39

timeline, 191

topological flow, see feature-based flow

topology, 57, 203

transfer function, 185

transform, see derive

translating, 254

transparency, 225

tree depth, 359

treemaps, 213–214, 217

trees, 27, 201–202, 213–216, 358

trend, 55

tritanopia, 220

trucking, 254

tunable detection, see popout

two-mode clustering, see matrix reordering

type, 22

unconstrained navigation, 256

uniform grid, 29

unimodal, 309

univariate, 234

unsteady, 189

unstructured grids, 29

user study, 79

user-centered design, 69

validation, 13–14, 74–81, 92

downstream, 68

upstream, 68

value, 25, 34, 145