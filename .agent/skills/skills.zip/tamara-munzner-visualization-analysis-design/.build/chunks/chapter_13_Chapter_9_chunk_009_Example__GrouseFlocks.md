# Example: GrouseFlocks

The containment design choice is usually only used if there is a hierarchical structure; that is, a tree. The obvious case is when the network is simply a tree, as above. The other case is with a compound network, which is the combination of a network and tree; that is, in addition to a base network with links that are pairwise relations between the network nodes, there is also a cluster hierarchy that groups the nodes hierarchically.* In other words, a compound network is a combination of a network and a tree on top of it, where the nodes in the network are the leaves of the tree. Thus, the interior nodes of the tree encompass multiple network nodes.

Containment is often used for exploring such compound networks. In the sfdp example above, there was a specific approach to coarsening the network that created a single derived hierarchy. That hierarchy was used only to accelerate force-directed layout and was not shown directly to the user. In the GrouseFlocks system, users can investigate multiple possible hierarchies and they are shown explicitly. Figure 9.10(a) shows a network and Figure 9.10(b) shows a cluster hierarchy built on top of it.

* The term multilevel network is sometimes used as a synonym for compound network.   
Cluster hierarchies are discussed further in Section 7.5.2.

![](images/2266cd92c9829d2f0f651cf31289557c9104a1a1bd55b7490e65faa8eea3eb3e.jpg)  
(a)

![](images/53cdeeadefb4f44630796869769adb6a0ba3412368f6f5b52eafaad94bc0434c.jpg)  
(b)

![](images/f0f2f1ab1ee372914f59b58136b7f27939828dc8cffbd7902768cf9eb2cdf975.jpg)

Figure 9.10. GrouseFlocks uses containment to show graph hierarchy structure. (a) Original graph. (b) Cluster hierarchy built atop the graph, shown with a node– link layout. (c) Network encoded using connection, with hierarchy encoded using containment. From [Archambault et al. 08, Figure 3].

Figure 9.10(c) shows a combined view using of containment marks for the associated hierarchy and connection marks for the original network links.

<table><tr><td>System</td><td>GrouseFlocks</td></tr><tr><td>What: Data</td><td>Network.</td></tr><tr><td>What: Derived</td><td>Cluster hierarchy atop original network.</td></tr><tr><td>What: Encode</td><td>Connection marks for original network, containment marks for cluster hierarchy.</td></tr></table>