# Marks as I tems/Nodes

![](images/babd6e741e41a1ce4685aeaf1d3f33f1d06fec897a9cc5f189a0cf6f340fbf61.jpg)  
$\textcircled{ \div}$ Points

![](images/f857c3342b35cd500e9341c0a2e27b651618967f906bd65dd7618f610039f87f.jpg)  
Lines

![](images/7f30e9b3fd5a2d2adac9ea087c3f4d65da94205312d593727d5cd87fd73ecd88.jpg)  
Areas

![](images/d63fe2643bdc1e5dcadfbc33a40add3a9d42a38b0ebdc7804266bf60ca548706.jpg)