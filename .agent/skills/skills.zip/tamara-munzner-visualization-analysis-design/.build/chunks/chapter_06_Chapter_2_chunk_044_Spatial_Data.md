# Spatial Data

Shape

![](images/ddae0e0d16f7660d91d6b3508124b1a258b00212a2b3023015aa68af1cd14fe0.jpg)

![](images/5134287128150f451ff8c57c10da3ebf74c2fa7510b5ebcb11b840d4bb769346.jpg)  
Figure 3.1. Why people are using vis in terms of actions and targets.