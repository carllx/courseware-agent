# Visu al e n c o d ing / i n t e r a c ti o n idi o m

Justify design with respec t to alternatives

![](images/484f5f53a626b1a4d5950c39ff453d622408ebd56e16a8c074ff9fecf4284878.jpg)  
Figure 4.1. The four nested levels of vis design have different threats to validity at each level, and validation approaches should be chosen accordingly.