# 8.5.4 Feature Flow

The feature flow vis idioms rely on global computations across the entire vector field to explicitly locate all instances of specific structures of interest, such as critical points, vortices, and shock

Filtering is covered in Section 13.3.   
Layering is covered in Section 12.5.

* The name of texture arises from a set of data structures and algorithms in computer graphics that efficiently manipulate highresolution images without intermediate geometric representations; these operations are supported in hardware on modern machines.

* An alternative name for feature-based flow is topological flow vis.

waves.* The goal is to partition the field into subregions where the qualitative behavior is similar. The resulting derived data is then directly visually encoded with one of the previously described flow idioms, for a geometric representation or a glyph showing each feature. In contrast, the previous idioms are intended to help the user to infer the existence of these structures, but they are not necessarily shown directly. A major challenge of feature-based flow vis is the algorithmic problem of computationally locating these structures efficiently and correctly.